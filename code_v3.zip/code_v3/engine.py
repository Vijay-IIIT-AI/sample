# ------------------------------------------------------------------------------
# engine.py — Core chat pipeline: ChatInput, TokenManager, ToolExecutor, run_chat
# ------------------------------------------------------------------------------
from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Optional, Union

try:
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
    from langchain_openai import ChatOpenAI
except ImportError:
    class BaseMessage: pass          # type: ignore
    class HumanMessage(BaseMessage): pass  # type: ignore
    class AIMessage(BaseMessage): pass     # type: ignore
    class SystemMessage(BaseMessage): pass # type: ignore
    class ChatOpenAI: pass           # type: ignore

from .config import (
    Config,
    UserContext,
    DEFAULT_USER_CONTEXT,
    ToolSystemError,
    get_finalize_system,
    get_user_context_prompt,
)
from .utils import (
    log,
    get_llm,
    count_tokens,
    sift_tool_output,
    trim_history_by_tokens,
    is_trivial_input,
    safe_parse_json,
    run_safety_guardrail,
    run_query_resolver,
    decompose_intents,
    smart_truncate_input,
    chunk_and_summarize,
    detect_content_strategy,
)
from .tools import DummyTools


# ── ChatInput ───────────────────────────────────────────────────────────────────

@dataclass
class ChatInput:
    user_input: str
    chat_history: List[Dict[str, str]]
    model_config: Dict[str, Any]
    force_tool: Optional[Union[str, List[str]]] = None
    force_tool_args: Optional[Dict[str, Any]] = None
    tool_metadata: Optional[Dict[str, str]] = None
    trace_id: str = field(default_factory=lambda: f"tr-{uuid.uuid4().hex[:12]}")
    user_context: Optional[UserContext] = None
    long_input_strategy: str = "auto"  # "auto" | "truncate" | "summarize"

    # ──────────────────────────────────────────────────────────────────────────
    # IMPORTANT: The CALLER is responsible for managing chat_history persistence.
    # Store the *resolved_query* (not raw user_input) in history for the next
    # turn; otherwise multi-turn context will degrade.
    # ──────────────────────────────────────────────────────────────────────────

    @property
    def api_key(self) -> str:
        try:
            return (self.model_config or {}).get("api_key", "") or ""
        except Exception:
            return ""

    @property
    def model_name(self) -> str:
        try:
            return (self.model_config or {}).get("model_name", "gpt-4o") or "gpt-4o"
        except Exception:
            return "gpt-4o"

    @property
    def base_url(self) -> Optional[str]:
        try:
            return (self.model_config or {}).get("base_url", None)
        except Exception:
            return None

    @property
    def total_token_limit(self) -> int:
        """Total context window size (prompt + completion). Defaults to Config.TokenBudgets.TOTAL_CONTEXT."""
        try:
            value = (self.model_config or {}).get("total_token_limit", Config.TokenBudgets.TOTAL_CONTEXT)
            return int(value) if value else Config.TokenBudgets.TOTAL_CONTEXT
        except (ValueError, TypeError):
            return Config.TokenBudgets.TOTAL_CONTEXT

    @property
    def output_token_limit(self) -> int:
        """Max tokens the model may generate per response. Defaults to 4096."""
        try:
            value = (self.model_config or {}).get("output_token_limit", 4096)
            return int(value) if value else 4096
        except (ValueError, TypeError):
            return 4096


# ── TokenManager ────────────────────────────────────────────────────────────────

class TokenManager:
    def __init__(
        self,
        model_name: str,
        total_token_limit: Optional[int] = None,
        output_token_limit: Optional[int] = None,
    ):
        self.max = total_token_limit or Config.TokenBudgets.TOTAL_CONTEXT
        self.output_limit = output_token_limit or 4096
        # Reserve space for system prompt and model output; the rest goes to history/tool.
        self._system = Config.TokenBudgets.SYSTEM
        self._buffer = Config.TokenBudgets.BUFFER
        self._available = max(0, self.max - self._system - self._buffer - self.output_limit)

    def calculate_limits(self, has_tool: bool) -> Dict[str, int]:
        min_history = Config.Limits.MIN_HISTORY_BUDGET
        min_tool = Config.Limits.MIN_TOOL_BUDGET
        if has_tool:
            # Split available budget: 1/3 history, 2/3 tool
            history = max(min_history, self._available // 3)
            tool = max(min_tool, self._available - history)
            return {"history": history, "tool": tool, "system": self._system}
        return {"history": max(min_history, self._available), "tool": 0, "system": self._system}


# ── ToolExecutor ────────────────────────────────────────────────────────────────

class ToolExecutor:
    @staticmethod
    def execute(
        tool_name: Union[str, List[str]],
        args: Dict[str, Any],
        user_input: str = "",
        llm: Optional[ChatOpenAI] = None,
        tool_metadata: Optional[Dict[str, str]] = None,
        token_budget: int = 60000,
    ) -> str:
        # ORCHESTRATION: multiple tools → delegate to planner loop
        if isinstance(tool_name, list):
            log("EXEC", f"Orchestrating: {tool_name}")
            return ToolExecutor.orchestrate(tool_name, user_input, llm, tool_metadata, token_budget)

        # SINGLE TOOL
        log("EXEC", f"Running {tool_name} with {args}")
        try:
            if tool_name == "rag_query":
                q = args.get("query", user_input)
                # Decompose long queries into sub-intents
                queries = (
                    [i["text"] for i in decompose_intents(llm, q)]
                    if len(q.split()) > 5 and llm
                    else [q]
                )
                unique_queries = list(set(queries))
                num_queries = len(unique_queries)

                # Split budget evenly across sub-queries to prevent token overflow
                per_query_budget = max(Config.Limits.MIN_TOOL_BUDGET, token_budget // num_queries)
                log("RAG", f"Decomposed into {num_queries} queries, {per_query_budget} tokens each")

                results = []
                total_tokens_used = 0
                for sq in unique_queries:
                    # Stop if we've used most of the budget
                    if total_tokens_used >= token_budget - Config.Limits.MIN_TOOL_BUDGET:
                        log("RAG", f"Budget exhausted, skipping remaining queries")
                        results.append(f"--- Query: {sq} ---\n[Skipped: token budget reached]")
                        continue

                    sub_args = {**args, "query": sq}
                    res = DummyTools.rag_query(sub_args)

                    # Truncate THIS query's result to its budget
                    res_truncated = sift_tool_output(res, per_query_budget)
                    tokens_used = count_tokens(res_truncated)
                    total_tokens_used += tokens_used

                    results.append(f"--- Query: {sq} ---\n{res_truncated}")

                return "\n\n".join(results)

            elif tool_name == "doc_generator":
                return DummyTools.doc_generator(args)

            elif tool_name == "tool_confluence":
                return DummyTools.tool_confluence(args)

            elif tool_name == "web_search":
                return DummyTools.web_search(args)

            elif tool_name == "calculator":
                return DummyTools.calculator(args)

            elif tool_name == "sql_query":
                query = args.get("query", "")
                if "DROP" in query.upper() or "DELETE" in query.upper():
                    raise ToolSystemError("SQL Injection detected and blocked.")
                if args.get("simulate_error"):
                    raise ToolSystemError("Our database is temporarily offline. Please try again later.")
                return DummyTools.sql_query(args)

            return f"Error: Tool '{tool_name}' not found"

        except ToolSystemError:
            raise
        except Exception as e:
            log("SYSTEM_ERROR", str(e))
            raise ToolSystemError("I've encountered a technical glitch. Let's try again in a moment.")

    @staticmethod
    def orchestrate(
        allowed_tools: List[str],
        user_input: str,
        llm: Optional[ChatOpenAI],
        tool_metadata: Optional[Dict[str, str]] = None,
        token_budget: int = 60000,
    ) -> str:
        log("ORCH", "Starting Planner...")

        if llm is None:
            log("ORCH", "ERROR: No LLM provided for orchestration")
            return "Error: Orchestration requires an LLM instance."

        max_tools = Config.Limits.MAX_TOOLS_PER_CALL
        if len(allowed_tools) > max_tools:
            allowed_tools = allowed_tools[:max_tools]
            log("ORCH", f"WARNING: Max {max_tools} tools allowed. Truncating.")

        if not tool_metadata:
            log("ORCH", "WARNING: No tool_metadata provided. Planner will have no descriptions.")

        tool_count = max(1, len(allowed_tools)) if allowed_tools else 1
        min_budget = Config.Limits.MIN_TOOL_BUDGET
        per_tool_budget = max(min_budget, token_budget // tool_count)
        log("ORCH", f"Budget: {token_budget} total, {per_tool_budget} per tool")

        tool_descs = "\n".join(
            [f"- {t}: {tool_metadata.get(t, 'N/A') if tool_metadata else 'N/A'}" for t in allowed_tools]
        )
        system_prompt = f"""You are a planner.
            User Request: "{user_input}"
            Available Tools:
            {tool_descs}

            Goal: Sequence tool calls to answer the request.
            Output JSON: {{ "thought": "...", "call_tool": "tool_name" OR "DONE", "args": {{...}} }}
            """

        scratchpad = ""
        context: List[str] = []
        seen_calls: set = set()
        max_iterations = Config.Limits.PLANNER_MAX_ITERATIONS
        scratchpad_budget = Config.Limits.PLANNER_SCRATCHPAD_TOKENS

        for i in range(max_iterations):
            scratchpad_trimmed = sift_tool_output(scratchpad, scratchpad_budget)
            prompt = f"{system_prompt}\n\nHistory:\n{scratchpad_trimmed}\n\nNext Step:"
            try:
                resp = llm.invoke([HumanMessage(content=prompt)])
                plan = safe_parse_json(resp.content)
                if not plan:
                    log("ORCH", "Planner returned unparseable JSON, stopping.")
                    break

                tool = plan.get("call_tool")
                args = plan.get("args", {})
                thought = plan.get("thought", "")
                log("ORCH", f"Step {i + 1}: {thought} -> {tool}")

                if tool == "DONE":
                    break

                call_sig = f"{tool}:{json.dumps(args, sort_keys=True)}"
                if call_sig in seen_calls:
                    log("ORCH", "Duplicate tool call detected, stopping.")
                    break
                seen_calls.add(call_sig)

                if tool not in allowed_tools:
                    res = f"Error: Tool '{tool}' not in allowed list."
                else:
                    res = ToolExecutor.execute(tool, args, user_input, llm, token_budget=per_tool_budget)

                res_tokens = count_tokens(res)
                if res_tokens > per_tool_budget:
                    res = res[: per_tool_budget * 4] + "...(trimmed)"
                    log("ORCH", f"Tool {tool} output trimmed to {per_tool_budget} tokens")

                entry = f"Step {i + 1}: Called {tool} (Args: {args})\nResult: {res}\n"
                scratchpad += entry
                context.append(entry)

            except Exception as e:
                log("ORCH", f"Error: {e}")
                break

        return "\n".join(context)


# ── Main chat pipeline ───────────────────────────────────────────────────────────

async def run_chat(chat_input: ChatInput) -> AsyncGenerator[str, None]:
    """
    Main chat pipeline. Handles all errors gracefully - never crashes.
    """
    start = time.time()

    # Wrap entire function in try/except to catch any uncaught errors
    try:
        # Validate chat_input itself
        if chat_input is None:
            yield "Invalid request. Please try again."
            return

        # Ensure user_input is a string
        if not isinstance(chat_input.user_input, str):
            chat_input.user_input = str(chat_input.user_input) if chat_input.user_input else ""

        # Ensure chat_history is a list
        if not isinstance(chat_input.chat_history, list):
            chat_input.chat_history = []

        # 0. Input Validation
        if is_trivial_input(chat_input.user_input):
            yield "I didn't quite catch that — could you share a bit more detail?"
            return

        # 0.1. Validate history size (prevent memory attacks)
        if len(chat_input.chat_history) > Config.Limits.MAX_HISTORY_MESSAGES:
            log("HISTORY_TOO_LARGE", f"History exceeds {Config.Limits.MAX_HISTORY_MESSAGES} messages", {"trace_id": chat_input.trace_id})
            # Truncate history instead of rejecting
            chat_input.chat_history = chat_input.chat_history[-Config.Limits.MAX_HISTORY_MESSAGES:]
            log("HISTORY_TRUNCATED", f"Truncated to last {Config.Limits.MAX_HISTORY_MESSAGES} messages")

        # 0.3. Validate API key
        if not chat_input.api_key or not chat_input.api_key.strip():
            log("CONFIG_ERROR", "Missing API key", {"trace_id": chat_input.trace_id})
            yield "Configuration error: API key is not set. Please check your settings."
            return

        # 1. Setup LLM (cached)
        try:
            llm = get_llm(chat_input.model_name, chat_input.api_key, chat_input.base_url, chat_input.output_token_limit)
        except Exception as e:
            log("LLM_INIT_ERROR", f"Failed to initialize LLM: {e}", {"trace_id": chat_input.trace_id})
            yield "Failed to initialize the language model. Please check your configuration."
            return

        # 1.5. Handle large input based on strategy
        input_tokens = count_tokens(chat_input.user_input, chat_input.model_name)
        max_input_tokens = max(2000, (chat_input.total_token_limit - Config.TokenBudgets.SYSTEM - Config.TokenBudgets.BUFFER - chat_input.output_token_limit) // 2)

        if input_tokens > max_input_tokens:
            log("INPUT_LARGE", f"Input is {input_tokens} tokens, max allowed {max_input_tokens}", {"trace_id": chat_input.trace_id})

            # Determine strategy
            strategy = chat_input.long_input_strategy
            if strategy == "auto":
                # Use LLM to detect content type and choose strategy
                log("STRATEGY", "Auto-detecting content type...", {"trace_id": chat_input.trace_id})
                strategy = await asyncio.to_thread(detect_content_strategy, chat_input.user_input, llm)

            # Apply chosen strategy
            if strategy == "summarize":
                log("STRATEGY", "Using chunk & summarize strategy", {"trace_id": chat_input.trace_id})
                chat_input.user_input = await asyncio.to_thread(
                    chunk_and_summarize,
                    chat_input.user_input,
                    llm,
                    max_input_tokens,
                    chat_input.model_name
                )
            else:
                log("STRATEGY", "Using smart truncation strategy", {"trace_id": chat_input.trace_id})
                chat_input.user_input = smart_truncate_input(chat_input.user_input, max_input_tokens, chat_input.model_name)

        # 2. Safety (fail-closed)
        safety_check = await asyncio.to_thread(run_safety_guardrail, llm, chat_input.user_input)
        if not safety_check.get("safe", False):
            log("SAFETY", f"Blocked: {safety_check.get('reason')}")
            yield "I cannot fulfill this request due to safety or security policies."
            return

        # 3. Query resolution (only when there is history to resolve against)
        log("INPUT", f"User query: {chat_input.user_input}", {"trace_id": chat_input.trace_id})

        last_ans: Optional[str] = None
        for m in reversed(chat_input.chat_history):
            try:
                if m.get("role") == "assistant":
                    last_ans = m.get("content", "")
                    break
            except (TypeError, AttributeError):
                continue

        if last_ans:
            resolved_dict = await asyncio.to_thread(run_query_resolver, llm, chat_input.user_input, last_ans)
            resolved_query = resolved_dict.get("resolved_query", chat_input.user_input)
        else:
            resolved_query = chat_input.user_input
        log("RESOLVE", f"Resolved: {resolved_query}")

        # 4. Token budgets + optional tool execution
        tm = TokenManager(chat_input.model_name, chat_input.total_token_limit, chat_input.output_token_limit)
        has_tool = bool(chat_input.force_tool)
        limits = tm.calculate_limits(has_tool)

        tool_out = ""
        tool_error: Optional[str] = None
        tool_degraded = False
        tool_timeout = Config.Limits.TOOL_TIMEOUT_SECONDS

        try:
            if has_tool:
                tool_out = await asyncio.wait_for(
                    asyncio.to_thread(
                        ToolExecutor.execute,
                        chat_input.force_tool,
                        chat_input.force_tool_args or {},
                        resolved_query,
                        llm,
                        chat_input.tool_metadata,
                        limits["tool"],
                    ),
                    timeout=tool_timeout,
                )

                NULL_RESPONSES = ["[DOC] No relevant documents found.", "[]", "Error: Tool", "None"]
                if not tool_out.strip() or any(nr in tool_out for nr in NULL_RESPONSES):
                    log("GRACEFUL_DEGRADATION", "Tool returned empty/useless result.", {"trace_id": chat_input.trace_id})
                    tool_degraded = True
                    tool_error = f"Tool '{chat_input.force_tool}' returned no relevant results."
                    tool_out = ""
                # sift_tool_output already applied inside ToolExecutor.execute(); no second truncation needed.

        except asyncio.TimeoutError:
            log("TIMEOUT", f"Tool execution timed out > {tool_timeout}s", {"trace_id": chat_input.trace_id})
            tool_degraded = True
            tool_error = f"Tool '{chat_input.force_tool}' timed out after {tool_timeout}s."
            tool_out = ""
        except ToolSystemError as e:
            log("TOOL_ERROR", f"Tool failed: {e}", {"trace_id": chat_input.trace_id})
            tool_degraded = True
            tool_error = str(e)
            tool_out = ""

        # 5. Build message list
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        sys_msg = get_finalize_system(Config.Identity.APP_NAME, Config.Identity.DEVELOPER_NAME, current_time)

        current_user_ctx = chat_input.user_context or DEFAULT_USER_CONTEXT
        # Two separate SystemMessages keep structured JSON data and human-readable context cleanly apart.
        # Determine router confidence level
        if tool_degraded:
            router_confidence = "degraded"
            log("FALLBACK", f"Tool failed, falling back to LLM general knowledge. Error: {tool_error}", {"trace_id": chat_input.trace_id})
        elif has_tool and tool_out:
            router_confidence = "forced"
        else:
            router_confidence = "none"

        try:
            tool_payload: Dict[str, Any] = {
                "router_confidence": router_confidence,
                "tool_output": tool_out if (has_tool and tool_out) else None,
            }
            if tool_degraded and tool_error:
                tool_payload["tool_error"] = tool_error
                tool_payload["tool_attempted"] = str(chat_input.force_tool)
                tool_payload["original_query"] = resolved_query
                tool_payload["instruction"] = "Do NOT use general knowledge. Only report that the tool could not find results."
            tool_payload_msg = SystemMessage(content=json.dumps(tool_payload, ensure_ascii=False, default=str))
        except (TypeError, ValueError) as e:
            log("JSON_ERROR", f"Failed to serialize tool payload: {e}", {"trace_id": chat_input.trace_id})
            # Fallback: sanitize the output
            fallback_payload: Dict[str, Any] = {
                "router_confidence": router_confidence,
                "tool_output": str(tool_out)[:10000] if (has_tool and tool_out) else None,
            }
            if tool_degraded:
                fallback_payload["tool_error"] = tool_error
                fallback_payload["instruction"] = "Do NOT use general knowledge. Only report that the tool could not find results."
            tool_payload_msg = SystemMessage(content=json.dumps(fallback_payload))
        user_ctx_msg = SystemMessage(content=get_user_context_prompt(current_user_ctx.to_prompt_context()))

        hist_objs: List[BaseMessage] = []
        for h in chat_input.chat_history:
            try:
                role = h.get("role", "")
                content = h.get("content", "")
                if not isinstance(content, str):
                    content = str(content)
                if role == "user":
                    hist_objs.append(HumanMessage(content=content))
                elif role == "assistant":
                    hist_objs.append(AIMessage(content=content))
            except (KeyError, TypeError, AttributeError) as e:
                log("HISTORY_PARSE_ERROR", f"Skipping malformed history entry: {e}", {"trace_id": chat_input.trace_id})
                continue

        trimmed_hist = trim_history_by_tokens(hist_objs, chat_input.model_name, limits["history"])
        final_msgs = [sys_msg, tool_payload_msg, user_ctx_msg] + trimmed_hist + [HumanMessage(content=resolved_query)]

        # 6. Stream response
        log("GEN", "Streaming...")
        try:
            async for chunk in llm.astream(final_msgs):
                if chunk.content:
                    yield chunk.content
        except Exception as e:
            log("CHAT_ERROR", f"LLM Streaming failed: {e}", {"trace_id": chat_input.trace_id})
            yield "Something went wrong while generating the response. Please try again."

        # 7. Yield context metadata at the end (for UI to display sources)
        try:
            if has_tool and tool_out:
                context_metadata = {
                    "type": "context",
                    "tool_used": str(chat_input.force_tool),
                    "tool_output": tool_out,
                    "query_sent": resolved_query,
                }
                yield f"\n[[CONTEXT_END]]{json.dumps(context_metadata, ensure_ascii=False, default=str)}"
            elif tool_degraded:
                context_metadata = {
                    "type": "context",
                    "tool_used": str(chat_input.force_tool),
                    "tool_output": None,
                    "tool_error": tool_error,
                    "query_sent": resolved_query,
                }
                yield f"\n[[CONTEXT_END]]{json.dumps(context_metadata, ensure_ascii=False, default=str)}"
        except Exception as e:
            log("CONTEXT_META_ERROR", f"Failed to yield context metadata: {e}")

        log("GEN", f"Completed in {time.time() - start:.2f}s")

    except Exception as e:
        # Catch-all for any uncaught exceptions - system should NEVER crash
        log("FATAL_ERROR", f"Unexpected error in run_chat: {e}", {"trace_id": getattr(chat_input, 'trace_id', 'unknown')})
        yield "An unexpected error occurred. Please try again later."

# ------------------------------------------------------------------------------
# __init__.py — Public API for the code_v3 package
# ------------------------------------------------------------------------------
"""
code_v3 package
===============
Usage (from any file outside the package):

    from code_v3 import ChatInput, run_chat, UserContext

The four modules inside the package are:
  config.py  — Config constants, UserContext, prompt builders
  utils.py   — Logging, token helpers, LLM factory, classifiers
  tools.py   — DummyTools stubs (replace with real implementations)
  engine.py  — ChatInput, TokenManager, ToolExecutor, run_chat
"""

from .config import Config, UserContext, DEFAULT_USER_CONTEXT, ToolSystemError
from .utils import log, get_llm, count_tokens, sift_tool_output, trim_history_by_tokens, is_trivial_input, smart_truncate_input, chunk_and_summarize, detect_content_strategy
from .tools import DummyTools
from .engine import ChatInput, TokenManager, ToolExecutor, run_chat

__all__ = [
    # config
    "Config",
    "UserContext",
    "DEFAULT_USER_CONTEXT",
    "ToolSystemError",
    # utils
    "log",
    "get_llm",
    "count_tokens",
    "sift_tool_output",
    "trim_history_by_tokens",
    "is_trivial_input",
    "smart_truncate_input",
    "chunk_and_summarize",
    "detect_content_strategy",
    # tools
    "DummyTools",
    # engine
    "ChatInput",
    "TokenManager",
    "ToolExecutor",
    "run_chat",
]


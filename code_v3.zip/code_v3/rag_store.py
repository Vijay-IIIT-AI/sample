# ------------------------------------------------------------------------------
# rag_store.py — ChromaDB-backed RAG utility
#
# Functions
# ─────────────────────────────────────────────────────────────────────────────
#   chunk_text(text, chunk_size, overlap)  -> list[str]
#       Split text into overlapping windows of `chunk_size` words,
#       stepping by (chunk_size - overlap).
#
#   embed_and_store(file_id, file_name, text, chunk_size, overlap)
#       Chunks the text, embeds each chunk with SentenceTransformer,
#       upserts into the ChromaDB collection "rag_docs",
#       and updates rag_metadata.json on disk atomically.
#
#   retrieve(question, file_ids, top_k)  -> list[dict]
#       Embeds the question, queries ChromaDB for nearest neighbours,
#       optionally filters by a list of file_ids,
#       and returns chunks with full source metadata.
#
# Storage layout
# ─────────────────────────────────────────────────────────────────────────────
#   code_v3/chroma_db/          ← ChromaDB persistent store (temp, gitignore-able)
#   code_v3/rag_metadata.json   ← file_id → {file_name, chunk_ids[]} index
#
# Dependencies
# ─────────────────────────────────────────────────────────────────────────────
#   pip install chromadb sentence-transformers
# ------------------------------------------------------------------------------

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Paths ──────────────────────────────────────────────────────────────────────

_HERE = Path(__file__).parent
CHROMA_PATH   = _HERE / "chroma_db"
METADATA_PATH = _HERE / "rag_metadata.json"

# ── Lazy singletons ────────────────────────────────────────────────────────────

_collection   = None
_embedder     = None


def _get_embedder():
    """Load the sentence-transformer once (cached in module-level var)."""
    global _embedder
    if _embedder is None:
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer("all-MiniLM-L6-v2")
    return _embedder


def _get_collection():
    """Get (or create) the ChromaDB persistent collection (cached)."""
    global _collection
    if _collection is None:
        import chromadb
        client = chromadb.PersistentClient(path=str(CHROMA_PATH))
        _collection = client.get_or_create_collection(
            name="rag_docs",
            metadata={"hnsw:space": "cosine"},
        )
    return _collection


# ── Metadata helpers ───────────────────────────────────────────────────────────

def _load_metadata() -> Dict[str, Any]:
    """
    Load file metadata from disk.

    Schema:
    {
        "files": {
            "<file_id>": {
                "file_name": "...",
                "chunk_ids": ["<file_id>_chunk_0", ...]
            },
            ...
        }
    }
    """
    if METADATA_PATH.exists():
        with open(METADATA_PATH, "r", encoding="utf-8") as fh:
            return json.load(fh)
    return {"files": {}}


def _save_metadata(meta: Dict[str, Any]) -> None:
    """Write metadata atomically (write to .tmp then rename)."""
    tmp = METADATA_PATH.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2, ensure_ascii=False)
    tmp.replace(METADATA_PATH)


def get_all_file_ids() -> List[str]:
    """Return every file_id currently in the metadata store."""
    return list(_load_metadata().get("files", {}).keys())


def get_file_info(file_id: str) -> Optional[Dict[str, Any]]:
    """Return the metadata entry for a single file_id, or None if not found."""
    return _load_metadata().get("files", {}).get(file_id)


# ── Core API ───────────────────────────────────────────────────────────────────

def chunk_text(
    text: str,
    chunk_size: int = 150,
    overlap: int = 30,
) -> List[str]:
    """
    Split `text` into overlapping word-level windows.

    Args:
        text:       Raw input text.
        chunk_size: Approximate number of words per chunk.
        overlap:    Number of words shared between adjacent chunks.

    Returns:
        List of non-empty chunk strings.
    """
    # Normalise whitespace
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []

    words = text.split()
    if not words:
        return []

    step = max(1, chunk_size - overlap)
    chunks: List[str] = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i : i + chunk_size])
        chunks.append(chunk)
        if i + chunk_size >= len(words):
            break
        i += step

    return chunks


def embed_and_store(
    file_id: str,
    file_name: str,
    text: str,
    chunk_size: int = 150,
    overlap: int = 30,
) -> Dict[str, Any]:
    """
    Chunk `text`, embed each chunk, and upsert into ChromaDB.
    Updates rag_metadata.json on disk.

    Args:
        file_id:    Unique identifier for this file (e.g. "squad_normans").
        file_name:  Human-readable display name.
        text:       Full body text to embed.
        chunk_size: Words per chunk (default 150).
        overlap:    Word overlap between chunks (default 30).

    Returns:
        dict with keys: file_id, file_name, num_chunks, chunk_ids
    """
    embedder   = _get_embedder()
    collection = _get_collection()

    chunks = chunk_text(text, chunk_size=chunk_size, overlap=overlap)
    if not chunks:
        return {"file_id": file_id, "file_name": file_name, "num_chunks": 0, "chunk_ids": []}

    chunk_ids     = [f"{file_id}_chunk_{i}" for i in range(len(chunks))]
    embeddings    = embedder.encode(chunks, show_progress_bar=False).tolist()
    metadatas     = [
        {"file_id": file_id, "file_name": file_name, "chunk_index": i}
        for i in range(len(chunks))
    ]

    # Upsert so repeated ingest is idempotent
    collection.upsert(
        ids=chunk_ids,
        embeddings=embeddings,
        documents=chunks,
        metadatas=metadatas,
    )

    # Update the JSON metadata index
    meta = _load_metadata()
    meta["files"][file_id] = {
        "file_name":  file_name,
        "chunk_ids":  chunk_ids,
        "num_chunks": len(chunks),
        "ingested_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _save_metadata(meta)

    return {
        "file_id":    file_id,
        "file_name":  file_name,
        "num_chunks": len(chunks),
        "chunk_ids":  chunk_ids,
    }


def retrieve(
    question: str,
    file_ids: Optional[List[str]] = None,
    top_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Retrieve the most relevant chunks for `question`.

    Args:
        question:  Natural-language query.
        file_ids:  Optional list of file_ids to restrict the search.
                   If None or empty, all files are searched.
        top_k:     Maximum number of results to return.

    Returns:
        List of dicts, each with keys:
            chunk_id  – ChromaDB document ID
            file_id   – Source file identifier
            file_name – Human-readable source name
            text      – Chunk content
            score     – Cosine similarity (higher = more relevant)
    """
    if not question or not question.strip():
        return []

    embedder   = _get_embedder()
    collection = _get_collection()

    # Bail early if the collection is empty
    if collection.count() == 0:
        return []

    query_embedding = embedder.encode([question], show_progress_bar=False).tolist()

    # Build optional where-clause for file_id filtering
    where: Optional[Dict[str, Any]] = None
    if file_ids:
        clean_ids = [fid for fid in file_ids if fid]
        if len(clean_ids) == 1:
            where = {"file_id": {"$eq": clean_ids[0]}}
        elif len(clean_ids) > 1:
            where = {"file_id": {"$in": clean_ids}}

    query_kwargs: Dict[str, Any] = {
        "query_embeddings": query_embedding,
        "n_results": min(top_k, collection.count()),
        "include": ["documents", "metadatas", "distances"],
    }
    if where:
        query_kwargs["where"] = where

    results = collection.query(**query_kwargs)

    # Unpack ChromaDB response (batched, so index [0])
    ids       = results.get("ids",       [[]])[0]
    docs      = results.get("documents", [[]])[0]
    metas     = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]

    output: List[Dict[str, Any]] = []
    for chunk_id, doc, meta, dist in zip(ids, docs, metas, distances):
        # ChromaDB cosine distance → similarity  (1 − distance)
        score = round(1.0 - float(dist), 4)
        output.append({
            "chunk_id":  chunk_id,
            "file_id":   meta.get("file_id", ""),
            "file_name": meta.get("file_name", ""),
            "text":      doc,
            "score":     score,
        })

    # Sort by score descending (chromadb already does this, but be explicit)
    output.sort(key=lambda x: x["score"], reverse=True)
    return output

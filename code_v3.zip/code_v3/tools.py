# ------------------------------------------------------------------------------
# tools.py — Tool implementations (stubs for testing; replace with real logic)
#
# Each static method matches a tool_name string used in ToolExecutor.execute().
# To add a new tool:
#   1. Add a @staticmethod here.
#   2. Add a matching elif branch in ToolExecutor.execute() in engine.py.
# ------------------------------------------------------------------------------
from __future__ import annotations

from typing import Any, Dict

from .utils import log


class DummyTools:
    """
    IMPORTANT: Stub implementations for local testing only.
    Replace every method with a real implementation before deploying to production.
    calculator() uses eval() — safe here only because the expression is pre-validated.
    """

    @staticmethod
    def rag_query(args: Dict[str, Any]) -> str:
        """
        Real ChromaDB-backed RAG retrieval.

        Expected args:
            query     (str)           – Natural-language question (required).
            file_ids  (list[str])     – Restrict search to these file IDs (optional).
            top_k     (int)           – Max chunks to return (default 5).

        Returns:
            Formatted string with ranked chunks and source metadata, e.g.
            [Normans] (chunk 3, score 0.872)
            The Normans were people who gave their name to Normandy…

            ---

            [Normans] (chunk 1, score 0.841)
            …
        """
        try:
            args     = args or {}
            question = str(args.get("query", "") or "").strip()
            file_ids = args.get("file_ids") or None    # list[str] | None
            top_k    = int(args.get("top_k", 5) or 5)

            log("RAG_QUERY", f"question={question!r}  file_ids={file_ids}  top_k={top_k}")

            if not question:
                return "[RAG] No query provided."

            from .rag_store import retrieve
            results = retrieve(question, file_ids=file_ids, top_k=top_k)

            if not results:
                return "[RAG] No relevant documents found."

            blocks = []
            for r in results:
                header = f"[{r['file_name']}] (chunk {r['chunk_id'].rsplit('_', 2)[-1]}, score {r['score']:.3f})"
                blocks.append(f"{header}\n{r['text']}")

            return "\n\n---\n\n".join(blocks)

        except Exception as e:
            log("RAG_ERROR", f"RAG query failed: {e}")
            return "[RAG] Error processing query."

    @staticmethod
    def tool_confluence(args: Dict[str, Any]) -> str:
        try:
            return "[CONFLUENCE] Content from Confluence page."
        except Exception as e:
            log("CONFLUENCE_ERROR", f"Confluence query failed: {e}")
            return "[CONFLUENCE] Error fetching content."

    @staticmethod
    def doc_generator(args: Dict[str, Any]) -> str:
        try:
            args = args or {}
            filename = str(args.get("filename", "doc") or "doc")
            content = args.get("content", "") or ""
            content_len = len(str(content))
            return f"[DOC_GEN] Generated report: {filename}.pdf with content length {content_len}"
        except Exception as e:
            log("DOC_GEN_ERROR", f"Document generation failed: {e}")
            return "[DOC_GEN] Error generating document."

    @staticmethod
    def web_search(args: Dict[str, Any]) -> str:
        try:
            args = args or {}
            query = str(args.get("query", "") or "")
            log("DUMMY_WEB", f"Searching web for: {query}")
            return f"[WEB] Search results for '{query}': Found 3 relevant articles."
        except Exception as e:
            log("WEB_ERROR", f"Web search failed: {e}")
            return "[WEB] Error performing search."

    @staticmethod
    def calculator(args: Dict[str, Any]) -> str:
        try:
            args = args or {}
            expression = str(args.get("expression", "") or "")

            if not expression:
                return "Error: No expression provided"

            allowed_chars = "0123456789+-*/(). "
            if not all(c in allowed_chars for c in expression):
                return "Error: Invalid characters in expression"
            # Block exponentiation via repeated multiplication patterns that could cause DoS
            if "**" in expression:
                return "Error: Exponentiation not allowed"
            # Limit expression length to prevent abuse
            if len(expression) > 100:
                return "Error: Expression too long (max 100 characters)"
            # Limit nesting depth
            if expression.count("(") > 10:
                return "Error: Too many nested parentheses (max 10)"
            try:
                result = eval(expression)  # noqa: S307
                # Sanity check result size
                if isinstance(result, (int, float)) and abs(result) > 1e15:
                    return "Error: Result too large"
                return f"[CALC] {expression} = {result}"
            except Exception as e:
                return f"Error evaluating expression: {e}"
        except Exception as e:
            log("CALC_ERROR", f"Calculator failed: {e}")
            return "[CALC] Error in calculation."

    @staticmethod
    def sql_query(args: Dict[str, Any]) -> str:
        try:
            args = args or {}
            query = str(args.get("query", "") or "")
            return f"[SQL] Executed '{query}'. Result: 50 rows returned."
        except Exception as e:
            log("SQL_ERROR", f"SQL query failed: {e}")
            return "[SQL] Error executing query."

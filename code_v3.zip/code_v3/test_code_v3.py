# ------------------------------------------------------------------------------
# test_code_v3.py — Scenario-based integration test runner for the code_v3 package
#
# Run with:
#   python test_code_v3.py
#
# Requires OPENAI_API_KEY (or a compatible local endpoint) to make real LLM calls.
# Scenarios 1-3 use the local proxy; Scenarios 4-5 fall back to env vars.
# ------------------------------------------------------------------------------

import asyncio
import os
import sys
from unittest.mock import patch

# Ensure the AgenticCode root is on the path so "code_v3" is importable as a package.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from code_v3 import ChatInput, UserContext, run_chat, ToolExecutor

# ── Shared model config (local proxy) ──────────────────────────────────────────
LOCAL_MODEL_CONFIG = {
    "api_key": "Key",
    "model_name": "/models",
    "base_url": "http://localhost:8113/v1",
    "total_token_limit": 128000,
    "output_token_limit": 4096,
}

# ── Helper ──────────────────────────────────────────────────────────────────────
async def stream_and_print(label: str, chat_input: ChatInput) -> None:
    print(f"\n{'='*60}")
    print(f"  {label}")
    print(f"{'='*60}")
    print(f"User : {chat_input.user_input}")
    if chat_input.force_tool:
        print(f"Tool : {chat_input.force_tool}")
    print("--- RESPONSE ---")
    async for chunk in run_chat(chat_input):
        print(chunk, end="", flush=True)
    print("\n")


# ── Scenarios ───────────────────────────────────────────────────────────────────

async def scenario_1_rag_docgen():
    """RAG + doc generator orchestration."""
    inp = ChatInput(
        user_input="Find info on Project Alpha and generate a report.",
        chat_history=[],
        model_config=LOCAL_MODEL_CONFIG,
        force_tool=["rag_query", "doc_generator"],
        tool_metadata={
            "rag_query": "Search knowledge base.",
            "doc_generator": "Create PDF report.",
        },
    )
    await stream_and_print("SCENARIO 1: RAG + Doc Gen", inp)


async def scenario_2_web_calc():
    """Web search + calculator orchestration."""
    inp = ChatInput(
        user_input="Search for the latest stock price of AAPL and calculate 10% of it.",
        chat_history=[],
        model_config=LOCAL_MODEL_CONFIG,
        force_tool=["web_search", "calculator"],
        tool_metadata={
            "web_search": "Search the internet for real-time info.",
            "calculator": "Evaluate mathematical expressions.",
        },
    )
    await stream_and_print("SCENARIO 2: Web Search + Math", inp)


async def scenario_3_user_context():
    """Custom user context and multi-turn history."""
    inp = ChatInput(
        user_input="Who are you and who developed you? Also, what is my name?",
        chat_history=[
            {"role": "user", "content": "Hi there!"},
            {"role": "assistant", "content": "Hello! How can I help you today?"},
        ],
        model_config=LOCAL_MODEL_CONFIG,
        user_context=UserContext(
            username="Vijay",
            response_style="concise",
            language_preference="English",
            custom_instructions="Be extremely brief.",
            designation="Developer",
            nickname="VJ",
        ),
    )
    await stream_and_print("SCENARIO 3: User Context & Custom Model", inp)


async def scenario_4_forced_args():
    """Single tool with explicitly forced args (bypasses planner)."""
    inp = ChatInput(
        user_input="Calculate the area of a circle with radius 5.",
        chat_history=[],
        model_config={
            "api_key": os.environ.get("OPENAI_API_KEY", "mock-key"),
            "base_url": os.environ.get("OPENAI_BASE_URL", None),
        },
        force_tool="calculator",
        force_tool_args={"expression": "3.14159 * 5 * 5"},
        tool_metadata={"calculator": "Evaluate mathematical expressions."},
    )
    await stream_and_print("SCENARIO 4: Forced Tool Args", inp)


async def scenario_5_rag_complex_args():
    """RAG with complex JSON filter args."""
    inp = ChatInput(
        user_input="Get financial reports for Q1 2024 with high confidentiality.",
        chat_history=[],
        model_config={
            "api_key": os.environ.get("OPENAI_API_KEY", "mock-key"),
            "base_url": os.environ.get("OPENAI_BASE_URL", None),
        },
        force_tool="rag_query",
        force_tool_args={
            "query": "Financial Reports Q1 2024",
            "filters": {"category": "finance", "confidentiality": "high", "year": 2024},
        },
        tool_metadata={"rag_query": "Search knowledge base."},
    )
    await stream_and_print("SCENARIO 5: RAG with Complex Args", inp)


async def scenario_6_mock_decomposition():
    """Verify decompose_intents fires correctly (mocked for determinism)."""
    mock_intents = [
        {"text": "Summarize Project Alpha"},
        {"text": "explain Project Beta"},
    ]

    inp = ChatInput(
        user_input="Summarize Project Alpha and explain Project Beta.",
        chat_history=[],
        model_config=LOCAL_MODEL_CONFIG,
        force_tool="rag_query",
        force_tool_args={"query": "placeholder"},
    )

    print(f"\n{'='*60}")
    print("  SCENARIO 6: Mock Decomposition")
    print(f"{'='*60}")
    print(f"User : {inp.user_input}")
    print("--- RESPONSE ---")

    # Patch decompose_intents inside engine so the LLM is not called for decomposition.
    with patch("code_v3.engine.decompose_intents", return_value=mock_intents):
        async for chunk in run_chat(inp):
            print(chunk, end="", flush=True)
    print("\n")


async def scenario_7_graceful_fallback():
    """Test graceful fallback when tool returns no results."""
    inp = ChatInput(
        user_input="Tell me about Project Gamma and its architecture.",
        chat_history=[],
        model_config=LOCAL_MODEL_CONFIG,
        force_tool="rag_query",
        force_tool_args={"query": "Project Gamma"},  # This will return "No relevant documents"
        tool_metadata={"rag_query": "Search knowledge base."},
    )
    await stream_and_print("SCENARIO 7: Graceful Fallback (Empty Tool Result)", inp)


async def scenario_8_tool_error_fallback():
    """Test graceful fallback when tool throws an error."""
    inp = ChatInput(
        user_input="Get user data from the database.",
        chat_history=[],
        model_config=LOCAL_MODEL_CONFIG,
        force_tool="sql_query",
        force_tool_args={"query": "SELECT * FROM users", "simulate_error": True},
        tool_metadata={"sql_query": "Execute SQL queries."},
    )
    await stream_and_print("SCENARIO 8: Graceful Fallback (Tool Error)", inp)


# ── Main ────────────────────────────────────────────────────────────────────────

async def main():
    print(">>> RUNNING CODE V3 TEST SUITE <<<\n")

    if not os.environ.get("OPENAI_API_KEY"):
        print("WARNING: OPENAI_API_KEY not set. Real LLM calls will fail.\n")

    await scenario_1_rag_docgen()
    await scenario_2_web_calc()
    await scenario_3_user_context()
    await scenario_4_forced_args()
    await scenario_5_rag_complex_args()
    await scenario_6_mock_decomposition()
    await scenario_7_graceful_fallback()
    await scenario_8_tool_error_fallback()

    print(">>> ALL SCENARIOS COMPLETED <<<")


if __name__ == "__main__":
    asyncio.run(main())

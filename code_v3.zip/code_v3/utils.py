# ------------------------------------------------------------------------------
# utils.py — Logging, token helpers, LLM factory, and classifiers
# ------------------------------------------------------------------------------
from __future__ import annotations

import json
import logging
from functools import lru_cache
from typing import Any, Dict, List, Optional

import httpx

try:
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
except ImportError:
    class BaseMessage: pass          # type: ignore
    class HumanMessage(BaseMessage): pass  # type: ignore
    class AIMessage(BaseMessage): pass     # type: ignore
    class SystemMessage(BaseMessage): pass # type: ignore
    class ChatOpenAI: pass           # type: ignore

from .config import (
    Config,
    get_query_resolver_prompt,
    get_decompose_prompt,
    get_safety_guardrail_prompt,
)


# ── Logging ─────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("CodeV3")


def _sanitize_for_log(value: Any) -> Any:
    """Remove sensitive data from log values."""
    if isinstance(value, str):
        # Mask potential API keys, tokens, passwords
        sensitive_patterns = ["api_key", "apikey", "token", "password", "secret", "authorization"]
        lower_val = value.lower()
        for pattern in sensitive_patterns:
            if pattern in lower_val and len(value) > 20:
                return f"[REDACTED:{len(value)} chars]"
        # Truncate very long strings
        if len(value) > 500:
            return value[:500] + f"...[truncated {len(value) - 500} chars]"
    elif isinstance(value, dict):
        return {k: _sanitize_for_log(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [_sanitize_for_log(v) for v in value[:10]]  # Limit list length
    return value


def log(tag: str, message: str, context: Optional[Dict[str, Any]] = None) -> None:
    sanitized_ctx = _sanitize_for_log(context) if context else None
    ctx_str = f" | {json.dumps(sanitized_ctx)}" if sanitized_ctx else ""
    logger.info(f"[{tag}] {message}{ctx_str}")


# ── Token helpers ────────────────────────────────────────────────────────────────

def count_tokens(text: str, model_name: str = "gpt-4o") -> int:
    """Count tokens using tiktoken, falling back to a 4-chars/token approximation."""
    try:
        import tiktoken
        enc = tiktoken.encoding_for_model(model_name)
        return len(enc.encode(text))
    except Exception:
        return len(text) // 4


def trim_history_by_tokens(
    messages: List[BaseMessage],
    model_name: str,
    max_tokens: int,
) -> List[BaseMessage]:
    """Trim history while preserving Human/AI message pairs. Input must not contain SystemMessages."""
    if not messages:
        return []

    # Group into semantic pairs [Human, AI].
    # Isolated messages (e.g. consecutive user messages) are treated as single items.
    paired_history: List[List[BaseMessage]] = []
    i = 0
    while i < len(messages):
        current_msg = messages[i]
        if (
            i + 1 < len(messages)
            and isinstance(current_msg, HumanMessage)
            and isinstance(messages[i + 1], AIMessage)
        ):
            paired_history.append([current_msg, messages[i + 1]])
            i += 2
        else:
            paired_history.append([current_msg])
            i += 1

    # Trim from the end (keep most recent)
    kept_blocks: List[List[BaseMessage]] = []
    current_tokens = 0
    for block in reversed(paired_history):
        try:
            block_text = "".join(str(getattr(m, 'content', '') or '') for m in block)
            block_tokens = count_tokens(block_text, model_name)
            if current_tokens + block_tokens > max_tokens:
                break
            kept_blocks.insert(0, block)
            current_tokens += block_tokens
        except Exception as e:
            log("TRIM_ERROR", f"Error processing history block: {e}")
            continue

    final_messages = [msg for block in kept_blocks for msg in block]
    log("TRIM", f"Trimmed history to {len(final_messages)} messages ({current_tokens} tokens)")
    return final_messages


def sift_tool_output(content: str, token_budget: int) -> str:
    """Intelligently truncate tool output by lines to fit a token budget."""
    if not content:
        return ""

    char_limit = token_budget * 4
    if len(content) <= char_limit:
        return content

    lines = content.split("\n")
    sifted: List[str] = []
    current_chars = 0
    for line in lines:
        if current_chars + len(line) + 1 > char_limit:
            sifted.append(f"... (truncated {len(lines) - len(sifted)} lines)")
            break
        sifted.append(line)
        current_chars += len(line) + 1

    return "\n".join(sifted)


def is_trivial_input(text: str) -> bool:
    """Return True for empty or obviously garbage inputs."""
    stripped = text.strip()
    if len(stripped) < 2:
        return True
    if len(set(stripped)) < 3:   # e.g. "aaaaaaa"
        return True
    return False


def detect_content_strategy(text: str, llm: Any) -> str:
    """
    Use LLM to detect whether content should be truncated or summarized.
    Returns: "truncate" or "summarize"
    """
    if not text:
        return "truncate"

    if not llm:
        log("DETECT_ERROR", "No LLM provided, defaulting to truncate")
        return "truncate"

    # Take a sample from beginning, middle, and end for analysis
    text_len = len(text)
    sample_size = min(500, text_len // 3)  # Don't exceed text length
    if sample_size < 50:
        return "truncate"  # Text too short to analyze

    beginning = text[:sample_size]
    middle_start = max(0, text_len // 2 - sample_size // 2)
    middle = text[middle_start:middle_start + sample_size]
    end = text[-sample_size:] if text_len > sample_size else ""

    sample = f"""BEGINNING:
{beginning}

MIDDLE:
{middle}

END:
{end}"""

    prompt = f"""Analyze this content sample and decide the best processing strategy.

CONTENT SAMPLE:
{sample}

STRATEGIES:
1. "truncate" - Keep beginning and end, remove middle. Best for:
   - Code files (imports at start, recent code at end)
   - Log files (headers at start, recent logs at end)
   - Configuration files
   - Structured data (JSON, XML, etc.)

2. "summarize" - Summarize all sections. Best for:
   - Documents, reports, articles
   - Emails, conversations
   - Unstructured text where middle content is important
   - Research papers, books

Based on the content sample, which strategy is better?

Reply with ONLY one word: truncate OR summarize"""

    try:
        resp = llm.invoke([HumanMessage(content=prompt)])
        result = resp.content.strip().lower()

        if "summarize" in result:
            log("DETECT", "LLM detected: document/text → summarize strategy")
            return "summarize"
        else:
            log("DETECT", "LLM detected: code/structured → truncate strategy")
            return "truncate"
    except Exception as e:
        log("DETECT_ERROR", f"Strategy detection failed: {e}, defaulting to truncate")
        return "truncate"


def smart_truncate_input(text: str, max_tokens: int, model_name: str = "gpt-4o") -> str:
    """
    Intelligently truncate long input while preserving important context.
    Keeps beginning + end, truncates middle with a note.
    Works for both code and documents.
    """
    if not text:
        return ""

    current_tokens = count_tokens(text, model_name)
    if current_tokens <= 0:
        return text
    if current_tokens <= max_tokens:
        return text

    # Calculate how much to keep (40% beginning, 40% end, 20% buffer for note)
    chars_per_token = len(text) / max(1, current_tokens)  # Prevent division by zero
    target_chars = int(max_tokens * chars_per_token * 0.9)  # 90% to be safe

    beginning_chars = int(target_chars * 0.45)
    end_chars = int(target_chars * 0.45)

    beginning = text[:beginning_chars]
    end = text[-end_chars:]

    # Calculate what was truncated
    truncated_chars = len(text) - beginning_chars - end_chars
    truncated_tokens = current_tokens - max_tokens

    truncation_note = f"\n\n[... TRUNCATED: {truncated_chars} characters (~{truncated_tokens} tokens) removed from middle to fit context window ...]\n\n"

    result = beginning + truncation_note + end

    log("TRUNCATE", f"Input truncated: {current_tokens} -> ~{max_tokens} tokens (kept beginning + end)")
    return result


def chunk_and_summarize(
    text: str,
    llm: Any,
    max_output_tokens: int,
    model_name: str = "gpt-4o"
) -> str:
    """
    Split long text into chunks, summarize each, combine summaries.
    Use when full content understanding is needed (documents, reports).
    """
    if not text:
        return ""

    if not llm:
        log("CHUNK_ERROR", "No LLM provided for summarization, using truncation fallback")
        return smart_truncate_input(text, max_output_tokens, model_name)

    current_tokens = count_tokens(text, model_name)
    if current_tokens <= 0:
        return text
    if current_tokens <= max_output_tokens:
        return text

    # Split into chunks (each chunk ~4000 tokens to leave room for summary prompt)
    chunk_size_tokens = 4000
    chars_per_token = len(text) / max(1, current_tokens)  # Prevent division by zero
    chunk_size_chars = max(1000, int(chunk_size_tokens * chars_per_token))  # Minimum 1000 chars per chunk

    chunks = []
    for i in range(0, len(text), chunk_size_chars):
        chunk = text[i:i + chunk_size_chars]
        if chunk.strip():
            chunks.append(chunk)

    log("CHUNK", f"Split into {len(chunks)} chunks for summarization")

    # Summarize each chunk
    summaries = []
    for idx, chunk in enumerate(chunks):
        try:
            summary_prompt = f"""Summarize this content concisely, preserving key facts, numbers, and important details.

CONTENT (Part {idx + 1} of {len(chunks)}):
{chunk}

SUMMARY:"""
            resp = llm.invoke([HumanMessage(content=summary_prompt)])
            summary = resp.content.strip()
            summaries.append(f"[Section {idx + 1}] {summary}")
            log("CHUNK_SUMMARY", f"Summarized chunk {idx + 1}/{len(chunks)}")
        except Exception as e:
            log("CHUNK_ERROR", f"Failed to summarize chunk {idx + 1}: {e}")
            # Fallback: use truncated chunk
            summaries.append(f"[Section {idx + 1}] {chunk[:500]}...")

    combined = "\n\n".join(summaries)

    # If combined summaries still too long, recursively summarize
    combined_tokens = count_tokens(combined, model_name)
    if combined_tokens > max_output_tokens:
        log("CHUNK", f"Combined summaries ({combined_tokens} tokens) still too long, truncating")
        combined = smart_truncate_input(combined, max_output_tokens, model_name)

    return f"[SUMMARIZED FROM {len(chunks)} SECTIONS]\n\n{combined}"


def safe_parse_json(text: str) -> Optional[Dict[str, Any]]:
    try:
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        return json.loads(text)
    except Exception:
        return None


# ── LLM factory ─────────────────────────────────────────────────────────────────

@lru_cache(maxsize=10)
def get_llm(
    model_name: str,
    api_key: str,
    base_url: Optional[str] = None,
    output_token_limit: int = 4096,
) -> ChatOpenAI:
    """Return a cached ChatOpenAI client. Identical args reuse the same instance."""
    return ChatOpenAI(
        model=model_name,
        api_key=api_key,
        base_url=base_url,
        max_tokens=output_token_limit,
        streaming=True,
        http_async_client=httpx.AsyncClient(
            limits=httpx.Limits(
                max_connections=1000,
                max_keepalive_connections=200,
                keepalive_expiry=30,
            ),
            timeout=httpx.Timeout(15.0),
        ),
    )


# ── Classifiers ──────────────────────────────────────────────────────────────────

def _invoke_with_timeout(
    llm: ChatOpenAI,
    messages: List[BaseMessage],
    timeout: float,
    trace_id: Optional[str] = None
) -> Optional[Any]:
    """Invoke LLM with a timeout. Returns None on timeout or error."""
    import concurrent.futures

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(llm.invoke, messages)
            return future.result(timeout=timeout)
    except concurrent.futures.TimeoutError:
        log("TIMEOUT", f"LLM call timed out after {timeout}s")
        return None
    except Exception as e:
        log("LLM_ERROR", f"LLM call failed: {e}")
        return None


def run_safety_guardrail(llm: ChatOpenAI, text: str) -> Dict[str, Any]:
    """Run the safety guardrail. Fails closed — returns unsafe on any error."""
    try:
        prompt = get_safety_guardrail_prompt(text)
        timeout = Config.Limits.CLASSIFIER_TIMEOUT_SECONDS
        resp = _invoke_with_timeout(llm, [HumanMessage(content=prompt)], timeout)
        if resp is None:
            log("SAFETY_ERROR", "Guardrail check timed out")
            return {"safe": False, "reason": "Safety check timed out"}
        parsed = safe_parse_json(resp.content)
        if parsed:
            if parsed.get("safe") is True:
                return parsed
            return {"safe": False, "reason": parsed.get("reason", "Unsafe content detected")}
    except Exception as e:
        log("SAFETY_ERROR", f"Guardrail check failed: {e}")

    return {"safe": False, "reason": "Safety check failed or timed out"}


def run_query_resolver(llm: ChatOpenAI, query: str, last_answer: Optional[str]) -> Dict[str, Any]:
    """Resolve pronoun references in the query using the last assistant answer."""
    if not last_answer:
        return {"resolved_query": query}
    try:
        prompt = get_query_resolver_prompt(query, last_answer)
        timeout = Config.Limits.CLASSIFIER_TIMEOUT_SECONDS
        resp = _invoke_with_timeout(llm, [HumanMessage(content=prompt)], timeout)
        if resp is None:
            log("RESOLVER_TIMEOUT", "Query resolution timed out, using original query.")
            return {"resolved_query": query}
        parsed = safe_parse_json(resp.content)
        return parsed if parsed and "resolved_query" in parsed else {"resolved_query": query}
    except Exception as e:
        log("RESOLVER_ERROR", f"Query resolution failed ({e}), using original query.")
        return {"resolved_query": query}


def decompose_intents(llm: ChatOpenAI, query: str) -> List[Dict[str, str]]:
    """Ask the LLM to split a query into sub-intents. Falls back to the original query on failure."""
    try:
        if not llm:
            raise ValueError("No LLM provided")
        prompt = get_decompose_prompt(query)
        timeout = Config.Limits.CLASSIFIER_TIMEOUT_SECONDS
        resp = _invoke_with_timeout(llm, [HumanMessage(content=prompt)], timeout)
        if resp is None:
            log("DECOMPOSE_TIMEOUT", "Decomposition timed out, returning original query.")
            return [{"text": query}]
        parsed = safe_parse_json(resp.content)
        if parsed and "intents" in parsed:
            cleaned = [{"text": i.get("text", query)} for i in parsed["intents"]]
            log("DECOMPOSE", f"LLM Split '{query}' -> {[c['text'] for c in cleaned]}")
            return cleaned
    except Exception as e:
        log("DECOMPOSE_ERROR", f"LLM Decomposition failed ({e}), returning original query.")
    return [{"text": query}]

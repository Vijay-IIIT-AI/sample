# ------------------------------------------------------------------------------
# rag_ingest.py — One-shot dataset ingestor for the RAG store
#
# Downloads the SQuAD v1 validation split from HuggingFace and ingests it
# into the local ChromaDB store via rag_store.embed_and_store().
#
# Each unique SQuAD "title" becomes one logical "file":
#   file_id   = "squad_<url-safe title>"
#   file_name = <original title>
#
# Run (from project root):
#   python -m code_v3.rag_ingest
# or:
#   python code_v3/rag_ingest.py
#
# Dependencies (already installed):
#   chromadb, sentence-transformers, datasets
# ------------------------------------------------------------------------------

from __future__ import annotations

import re
import sys
from pathlib import Path

# Allow `python rag_ingest.py` without installing the package
sys.path.insert(0, str(Path(__file__).parent.parent))

from code_v3.rag_store import embed_and_store, METADATA_PATH, CHROMA_PATH


# ── Helpers ────────────────────────────────────────────────────────────────────

def _slugify(title: str) -> str:
    """Convert a title to a safe file_id slug."""
    slug = re.sub(r"[^\w\s-]", "", title.lower())
    slug = re.sub(r"[\s_-]+", "_", slug).strip("_")
    return slug[:80]  # cap length


def _group_by_title(dataset) -> dict[str, dict]:
    """
    Group SQuAD rows by title.
    Returns: { title: {"chunks": [passage_text, ...]} }
    """
    groups: dict[str, list[str]] = {}
    for row in dataset:
        title   = row["title"]
        context = row["context"]
        if title not in groups:
            groups[title] = []
        if context not in groups[title]:
            groups[title].append(context)
    return groups


# ── Main ingest ────────────────────────────────────────────────────────────────

def ingest(max_titles: int = 30) -> list[dict]:
    """
    Download SQuAD validation split and ingest up to `max_titles` titles.

    Args:
        max_titles: Limit to avoid very long first-run times (default 30).

    Returns:
        List of summary dicts from embed_and_store().
    """
    print("Loading SQuAD dataset from HuggingFace …")
    from datasets import load_dataset
    ds = load_dataset("rajpurkar/squad", split="validation", trust_remote_code=False)
    print(f"  → {len(ds):,} rows loaded")

    groups = _group_by_title(ds)
    titles = list(groups.keys())[:max_titles]
    print(f"  → {len(titles)} unique titles selected (max_titles={max_titles})")

    results = []
    for i, title in enumerate(titles, 1):
        file_id   = f"squad_{_slugify(title)}"
        file_name = title
        text      = "\n\n".join(groups[title])     # join all passages for this title

        print(f"  [{i:>2}/{len(titles)}] Ingesting: {file_name!r} …", end="", flush=True)
        info = embed_and_store(
            file_id   = file_id,
            file_name = file_name,
            text      = text,
            chunk_size= 150,
            overlap   = 30,
        )
        print(f"  {info['num_chunks']} chunks ✓")
        results.append(info)

    return results


def main():
    print("\n" + "=" * 60)
    print("  RAG Ingest — SQuAD → ChromaDB")
    print("=" * 60)
    print(f"  Chroma store : {CHROMA_PATH}")
    print(f"  Metadata file: {METADATA_PATH}")
    print("=" * 60 + "\n")

    summaries = ingest(max_titles=30)

    total_chunks = sum(s["num_chunks"] for s in summaries)
    print("\n" + "─" * 60)
    print(f"  Done! {len(summaries)} files · {total_chunks} total chunks ingested.")
    print("─" * 60)
    print("\nIngested file_ids:")
    for s in summaries:
        print(f"  {s['file_id']:50s}  ({s['num_chunks']} chunks)")
    print()


if __name__ == "__main__":
    main()

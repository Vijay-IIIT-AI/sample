"""LLM Client wrapper for translation operations."""

import logging
import re
import time
import unicodedata
from typing import List, Union

from openai import OpenAI

from ..config import Language, LLMConfig

logger = logging.getLogger(__name__)

TRANSLATION_SYSTEM_PROMPT = """You are a strict translation engine.
Your ONLY task is to return the translation of the given text into the target language.

Rules:
- Output ONLY the translated text inside <translation>...</translation>.
- Do NOT explain, describe, or add anything else.
- If the input looks like code, still translate it literally as text.
- Never repeat the source text in the output.
- Preserve any formatting, punctuation, and structure of the original text.
- If the text contains technical terms, translate them appropriately for the target language.
- Auto-detect the source language if not specified."""

LANGUAGE_DETECTION_PROMPT = """You are a language detection engine.
Analyze the given text and return ONLY the ISO 639-1 language code.

Rules:
- Output ONLY the language code inside <language>...</language>.
- Use standard codes: en, ko, zh-cn, th, vi, fil, ja, etc.
- Do NOT explain or add anything else."""


def _user_prompt(text: str, target_lang: str, source_lang: str = None) -> str:
    if source_lang and source_lang.lower() not in ("auto", "auto-detect"):
        return f'''Translate the following text from {source_lang} into {target_lang}.
Output only inside <translation>...</translation>.

Text: "{text}"'''
    return f'''Translate the following text into {target_lang}.
Output only inside <translation>...</translation>.

Text: "{text}"'''


def _extract_translation(output: str) -> str:
    match = re.search(r"<translation>(.*?)</translation>", output, re.DOTALL)
    if match:
        return match.group(1).strip()
    return output.strip()


def _extract_language(output: str) -> str:
    match = re.search(r"<language>(.*?)</language>", output, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip().lower()
    output_lower = output.lower().strip()
    for code in ["en", "ko", "zh-cn", "zh", "th", "vi", "fil", "ja", "es", "fr", "de"]:
        if code in output_lower:
            return code
    return "en"


def _remove_control_characters(text: str) -> str:
    return "".join(
        char for char in text
        if unicodedata.category(char)[0] != "C" or char in "\n\r\t"
    )


class LLMClient:
    """LLM client for translation using OpenAI-compatible API."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self._client = OpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
            max_retries=config.max_retries,
        )

    def detect_language(self, text: str) -> str:
        """Detect language using local heuristics or LLM."""
        if not text or not text.strip():
            return "en"

        from ..utils.text import detect_language as local_detect
        local_code, confidence = local_detect(text)

        if confidence > 0.8 or confidence == -1.0:
            return local_code

        try:
            response = self._client.chat.completions.create(
                model=self.config.model_name,
                messages=[
                    {"role": "system", "content": LANGUAGE_DETECTION_PROMPT},
                    {"role": "user", "content": f'Detect language: "{text[:500]}"'},
                ],
                temperature=0.0,
            )
            output = response.choices[0].message.content
            if output:
                return _extract_language(output)
        except Exception:
            pass

        return local_code

    def translate(
        self,
        text: str,
        source_lang: Union[Language, str],
        target_lang: Union[Language, str],
    ) -> str:
        """Translate text. If source_lang is AUTO, LLM auto-detects."""
        if not text or not text.strip():
            return text

        if isinstance(source_lang, str):
            source_lang = Language.from_string(source_lang)
        if isinstance(target_lang, str):
            target_lang = Language.from_string(target_lang)

        clean_text = _remove_control_characters(text.strip())
        if not clean_text:
            return text

        source_lang_name = None if source_lang.is_auto else source_lang.display_name
        user_prompt = _user_prompt(clean_text, target_lang.display_name, source_lang_name)

        try:
            response = self._client.chat.completions.create(
                model=self.config.model_name,
                messages=[
                    {"role": "system", "content": TRANSLATION_SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=self.config.temperature,
            )

            output = response.choices[0].message.content
            if output:
                return _remove_control_characters(_extract_translation(output))
            return text

        except Exception as e:
            raise RuntimeError(f"Translation failed: {e}") from e

    def translate_batch(
        self,
        texts: List[str],
        source_lang: Union[Language, str],
        target_lang: Union[Language, str],
        delay: float = 0.0,
    ) -> List[str]:
        """Translate batch with guaranteed same-length output. Falls back to originals on failure."""
        if not texts:
            return []

        results = []
        for i, text in enumerate(texts):
            try:
                translated = self.translate(text, source_lang, target_lang)
                results.append(translated if translated and translated.strip() else text)
            except Exception as e:
                logger.debug(f"Translation failed for text {i+1}/{len(texts)}: {e}")
                results.append(text)

            if delay > 0 and i < len(texts) - 1:
                time.sleep(delay)

        assert len(results) == len(texts)
        return results

    def translate_chunked(
        self,
        text: str,
        source_lang: Union[Language, str],
        target_lang: Union[Language, str],
        chunk_separator: str = "\n",
        max_chunk_size: int = 20,
    ) -> str:
        """Translate text by chunking on separator."""
        from ..utils.text import chunk_text

        lines = text.split(chunk_separator)
        translated_lines = []

        for chunk in chunk_text(lines, max_chunk_size):
            chunk_text_joined = chunk_separator.join(chunk)
            try:
                translated_lines.append(self.translate(chunk_text_joined, source_lang, target_lang))
            except Exception:
                translated_lines.append(chunk_text_joined)

        return chunk_separator.join(translated_lines)

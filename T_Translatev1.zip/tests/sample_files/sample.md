# Sample Markdown Document

## Introduction

This is a **sample markdown file** for testing the translation module.

## Features

Here are some features we support:

- Bold text: **important**
- Italic text: *emphasis*
- Links: [Visit our website](https://example.com)
- Code blocks

### Code Example

```python
def hello_world():
    print("Hello, World!")
```

## List of Items

1. First item with description
2. Second item with more details
3. Third item to complete the list

## Table Example

| Feature | Status | Notes |
|---------|--------|-------|
| Translation | Active | Working well |
| Formatting | Preserved | Layout intact |

## Conclusion

> This is a blockquote that should also be translated.

Thank you for using our translation service!

---

*Last updated: 2024*

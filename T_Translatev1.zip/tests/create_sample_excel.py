"""Create sample Excel file for testing."""
from openpyxl import Workbook

wb = Workbook()

# Sheet 1 - Products
ws1 = wb.active
ws1.title = "Products"
ws1.append(["ID", "Product Name", "Description", "Category"])
ws1.append([1, "Laptop Computer", "High performance laptop for professionals", "Electronics"])
ws1.append([2, "Office Chair", "Ergonomic chair with lumbar support", "Furniture"])
ws1.append([3, "Coffee Maker", "Automatic coffee brewing machine", "Appliances"])
ws1.append([4, "Wireless Mouse", "Bluetooth mouse with precision tracking", "Accessories"])
ws1.append([5, "Desk Lamp", "LED lamp with adjustable brightness", "Lighting"])

# Sheet 2 - Services
ws2 = wb.create_sheet("Services")
ws2.append(["Service ID", "Service Name", "Description", "Duration"])
ws2.append(["SVC001", "Consulting", "Business strategy consulting service", "2 hours"])
ws2.append(["SVC002", "Training", "Professional development training program", "4 hours"])
ws2.append(["SVC003", "Support", "Technical support and maintenance", "1 hour"])

# Sheet 3 - About
ws3 = wb.create_sheet("About")
ws3["A1"] = "Company Information"
ws3["A3"] = "Our company provides innovative solutions for businesses worldwide."
ws3["A4"] = "We are committed to delivering excellence in everything we do."
ws3["A6"] = "Contact us at info@example.com for more information."

wb.save("sample_files/sample.xlsx")
print("Created sample.xlsx successfully!")

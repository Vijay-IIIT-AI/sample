"""
Example implementation to test the translation module.

This script demonstrates how to use the translate module to translate
different file types from English to Korean (or any other language).

Usage:
    python test_translation.py

Requirements:
    - Install dependencies: pip install -r ../requirements.txt
    - Configure your LLM endpoint below
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from translate import translate_file, translate_text, LLMConfig, Language


# =============================================================================
# CONFIGURATION - UPDATE THESE VALUES
# =============================================================================
LLM_BASE_URL = "http://localhost:8000/v1"  # Your LLM API endpoint
LLM_API_KEY = "your-api-key-here"          # Your API key
LLM_MODEL_NAME = "your-model-name"         # Your model name



# Source and target languages
SOURCE_LANG = Language.ENGLISH
TARGET_LANG = Language.KOREAN  # Change to any: CHINESE, VIETNAMESE, FILIPINO, THAI

# Paths
SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "sample_files")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output_files")
FONTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "translate", "assets", "fonts")
MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "translate", "assets", "models")


def create_llm_config():
    """Create LLM configuration."""
    return LLMConfig(
        base_url=LLM_BASE_URL,
        api_key=LLM_API_KEY,
        model_name=LLM_MODEL_NAME,
        temperature=0.0,
        timeout=120.0,
    )


def test_text_translation():
    """Test direct text translation."""
    print("\n" + "="*60)
    print("Testing Direct Text Translation")
    print("="*60)

    config = create_llm_config()

    test_texts = [
        "Hello, how are you today?",
        "The weather is beautiful.",
        "Thank you for your help!",
    ]

    for text in test_texts:
        try:
            translated = translate_text(
                text=text,
                llm_config=config,
                source_lang=SOURCE_LANG,
                target_lang=TARGET_LANG,
            )
            print(f"\nOriginal: {text}")
            print(f"Translated: {translated}")
        except Exception as e:
            print(f"\nError translating '{text}': {e}")


def test_file_translation(file_name: str, **kwargs):
    """Test file translation."""
    input_path = os.path.join(SAMPLE_DIR, file_name)

    if not os.path.exists(input_path):
        print(f"  File not found: {input_path}")
        return None

    # Create output filename
    name, ext = os.path.splitext(file_name)
    output_name = f"{name}_{TARGET_LANG.code}{ext}"
    output_path = os.path.join(OUTPUT_DIR, output_name)

    print(f"\n  Input: {input_path}")
    print(f"  Output: {output_path}")

    config = create_llm_config()

    try:
        result = translate_file(
            input_path=input_path,
            output_path=output_path,
            llm_config=config,
            source_lang=SOURCE_LANG,
            target_lang=TARGET_LANG,
            fonts_dir=FONTS_DIR,
            models_dir=MODELS_DIR,
            **kwargs
        )

        if result.success:
            print(f"  Status: SUCCESS")
            print(f"  Stats: {result.stats}")
        else:
            print(f"  Status: FAILED")
            print(f"  Error: {result.error_message}")

        return result

    except Exception as e:
        print(f"  Exception: {e}")
        return None


def main():
    """Run all translation tests."""
    print("\n" + "="*60)
    print("TRANSLATION MODULE TEST SUITE")
    print("="*60)
    print(f"\nSource Language: {SOURCE_LANG.display_name}")
    print(f"Target Language: {TARGET_LANG.display_name}")
    print(f"LLM Endpoint: {LLM_BASE_URL}")

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"\nOutput directory: {OUTPUT_DIR}")

    # Test 1: Direct text translation
    print("\n" + "-"*60)
    print("TEST 1: Direct Text Translation")
    print("-"*60)
    test_text_translation()

    # Test 2: TXT file
    print("\n" + "-"*60)
    print("TEST 2: TXT File Translation")
    print("-"*60)
    test_file_translation("sample.txt")

    # Test 3: HTML file
    print("\n" + "-"*60)
    print("TEST 3: HTML File Translation")
    print("-"*60)
    test_file_translation("sample.html")

    # Test 4: Markdown file
    print("\n" + "-"*60)
    print("TEST 4: Markdown File Translation")
    print("-"*60)
    test_file_translation("sample.md")

    # Test 5: CSV file
    print("\n" + "-"*60)
    print("TEST 5: CSV File Translation")
    print("-"*60)
    test_file_translation("sample.csv")

    # Test 6: Excel file
    print("\n" + "-"*60)
    print("TEST 6: Excel File Translation")
    print("-"*60)
    test_file_translation("sample.xlsx")

    # Test 7: PDF file (if exists and dependencies installed)
    print("\n" + "-"*60)
    print("TEST 7: PDF File Translation")
    print("-"*60)
    if os.path.exists(os.path.join(SAMPLE_DIR, "sample.pdf")):
        test_file_translation("sample.pdf")
    else:
        print("  Skipped: sample.pdf not found")
        print("  (PDF requires additional dependencies: cv2, onnx, pymupdf)")

    print("\n" + "="*60)
    print("TEST SUITE COMPLETED")
    print("="*60)
    print(f"\nCheck output files in: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()

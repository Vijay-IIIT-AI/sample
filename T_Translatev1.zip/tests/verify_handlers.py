"""
Verify all handlers can be imported and are properly configured.
This script does NOT require an LLM connection.

Usage:
    python verify_handlers.py
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def verify_imports():
    """Verify all module imports work."""
    print("Verifying imports...")

    errors = []

    # Core modules
    try:
        from translate.config import LLMConfig, Language, TranslationResult, LANGUAGE_FONTS
        print("  [OK] translate.config")
    except Exception as e:
        errors.append(f"translate.config: {e}")
        print(f"  [FAIL] translate.config: {e}")

    try:
        from translate.llm.client import LLMClient
        print("  [OK] translate.llm.client")
    except Exception as e:
        errors.append(f"translate.llm.client: {e}")
        print(f"  [FAIL] translate.llm.client: {e}")

    try:
        from translate.utils.text import should_translate, chunk_text, is_url, is_symbolic, detect_language
        print("  [OK] translate.utils.text")
    except Exception as e:
        errors.append(f"translate.utils.text: {e}")
        print(f"  [FAIL] translate.utils.text: {e}")

    # Handlers
    handlers = [
        ("translate.handlers.txt", "TxtHandler"),
        ("translate.handlers.pptx", "PptxHandler"),
        ("translate.handlers.docx", "DocxHandler"),
        ("translate.handlers.html", "HTMLHandler"),
        ("translate.handlers.csv_handler", "CsvHandler"),
        ("translate.handlers.md", "MarkdownHandler"),
        ("translate.handlers.xlsx", "XlsxHandler"),
    ]

    for module_name, class_name in handlers:
        try:
            module = __import__(module_name, fromlist=[class_name])
            handler_class = getattr(module, class_name)
            exts = handler_class.supported_extensions()
            print(f"  [OK] {class_name}: {exts}")
        except Exception as e:
            errors.append(f"{class_name}: {e}")
            print(f"  [FAIL] {class_name}: {e}")

    # PDF handler (optional)
    try:
        from translate.handlers.pdf import PDFHandler
        exts = PDFHandler.supported_extensions()
        print(f"  [OK] PDFHandler: {exts}")
    except ImportError as e:
        print(f"  [SKIP] PDFHandler (optional dependencies): {e}")
    except Exception as e:
        errors.append(f"PDFHandler: {e}")
        print(f"  [FAIL] PDFHandler: {e}")

    return errors


def verify_languages():
    """Verify language configurations."""
    print("\nVerifying languages...")

    from translate.config import Language, LANGUAGE_FONTS

    for lang in Language:
        font = LANGUAGE_FONTS.get(lang, "NOT CONFIGURED")
        print(f"  {lang.display_name} ({lang.code}): {font}")


def verify_fonts():
    """Verify font files exist."""
    print("\nVerifying fonts...")

    fonts_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "translate", "assets", "fonts"
    )

    if not os.path.exists(fonts_dir):
        print(f"  [WARN] Fonts directory not found: {fonts_dir}")
        return

    fonts = os.listdir(fonts_dir)
    if not fonts:
        print("  [WARN] No fonts found in fonts directory")
    else:
        for font in fonts:
            size = os.path.getsize(os.path.join(fonts_dir, font))
            size_mb = size / (1024 * 1024)
            print(f"  [OK] {font} ({size_mb:.2f} MB)")


def verify_models():
    """Verify model files exist."""
    print("\nVerifying models...")

    models_dir = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "translate", "assets", "models"
    )

    if not os.path.exists(models_dir):
        print(f"  [WARN] Models directory not found: {models_dir}")
        return

    models = os.listdir(models_dir)
    if not models:
        print("  [WARN] No models found in models directory")
    else:
        for model in models:
            size = os.path.getsize(os.path.join(models_dir, model))
            size_mb = size / (1024 * 1024)
            print(f"  [OK] {model} ({size_mb:.2f} MB)")


def verify_sample_files():
    """Verify sample test files exist."""
    print("\nVerifying sample files...")

    sample_dir = os.path.join(os.path.dirname(__file__), "sample_files")

    if not os.path.exists(sample_dir):
        print(f"  [WARN] Sample directory not found: {sample_dir}")
        return

    expected_files = ["sample.txt", "sample.html", "sample.md", "sample.csv", "sample.xlsx"]

    for filename in expected_files:
        filepath = os.path.join(sample_dir, filename)
        if os.path.exists(filepath):
            print(f"  [OK] {filename}")
        else:
            print(f"  [MISSING] {filename}")


def main():
    print("="*60)
    print("TRANSLATION MODULE VERIFICATION")
    print("="*60)

    errors = verify_imports()
    verify_languages()
    verify_fonts()
    verify_models()
    verify_sample_files()

    print("\n" + "="*60)
    if errors:
        print(f"VERIFICATION COMPLETED WITH {len(errors)} ERROR(S)")
        print("\nErrors found:")
        for err in errors:
            print(f"  - {err}")
    else:
        print("VERIFICATION COMPLETED SUCCESSFULLY")
    print("="*60)

    return len(errors) == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

"""
Translation module for multiple file formats.

Example:
    from translate import translate_file, LLMConfig

    config = LLMConfig(base_url="http://llm/v1", api_key="key", model_name="model")
    result = translate_file("doc.pdf", "doc_ko.pdf", config, target_lang="ko")
"""

import os
from typing import Optional, Union

from .config import Language, LANGUAGE_FONTS, LLMConfig, TranslateConfig, TranslationResult
from .llm import LLMClient
from .handlers import (
    BaseHandler, DocxHandler, PDFHandler, PptxHandler, TxtHandler,
    HTMLHandler, CsvHandler, MarkdownHandler, XlsxHandler,
    get_handler_class, get_supported_extensions, is_supported,
)

__version__ = "1.0.0"

__all__ = [
    "translate_file", "translate_text",
    "LLMConfig", "TranslateConfig", "Language", "LANGUAGE_FONTS", "TranslationResult",
    "LLMClient",
    "BaseHandler", "TxtHandler", "PptxHandler", "DocxHandler", "PDFHandler",
    "HTMLHandler", "CsvHandler", "MarkdownHandler", "XlsxHandler",
    "get_handler_class", "get_supported_extensions", "is_supported",
]


def translate_file(
    input_path: str,
    output_path: str,
    llm_config: LLMConfig,
    target_lang: Union[str, Language],
    source_lang: Optional[Union[str, Language]] = None,
    fonts_dir: Optional[str] = None,
    models_dir: Optional[str] = None,
    **handler_kwargs,
) -> TranslationResult:
    """Translate a file. Auto-detects file type and source language."""
    if not os.path.exists(input_path):
        return TranslationResult.failure_result(
            f"Input file not found: {input_path}",
            input_path=input_path, output_path=output_path)

    _, ext = os.path.splitext(input_path)
    handler_class = get_handler_class(ext.lower())
    if handler_class is None:
        return TranslationResult.failure_result(
            f"Unsupported file type: {ext}. Supported: {', '.join(get_supported_extensions())}",
            input_path=input_path, output_path=output_path)

    if source_lang is None:
        source_lang = Language.AUTO
    elif isinstance(source_lang, str):
        source_lang = Language.from_string(source_lang)

    if isinstance(target_lang, str):
        target_lang = Language.from_string(target_lang)

    llm_client = LLMClient(llm_config)
    config = TranslateConfig(
        llm=llm_config, source_lang=source_lang, target_lang=target_lang,
        fonts_dir=fonts_dir, models_dir=models_dir)

    handler = handler_class(
        llm_client=llm_client, target_lang=target_lang,
        source_lang=source_lang, config=config)

    return handler.translate(input_path, output_path, **handler_kwargs)


def translate_text(
    text: str,
    llm_config: LLMConfig,
    target_lang: Union[str, Language],
    source_lang: Optional[Union[str, Language]] = None,
) -> str:
    """Translate text. Auto-detects source language if not specified."""
    if source_lang is None:
        source_lang = Language.AUTO
    elif isinstance(source_lang, str):
        source_lang = Language.from_string(source_lang)

    if isinstance(target_lang, str):
        target_lang = Language.from_string(target_lang)

    return LLMClient(llm_config).translate(text, source_lang, target_lang)

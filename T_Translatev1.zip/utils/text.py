"""Text utility functions for the translate package."""

import re
import unicodedata
from typing import Generator, List, Tuple


def is_symbolic(text: str) -> bool:
    """
    Check if text is primarily symbolic/mathematical and should not be translated.

    A text is considered symbolic if:
    - More than 70% of characters are non-alphabetic
    - It matches patterns for mathematical notation

    Args:
        text: The text to check

    Returns:
        True if the text is primarily symbolic
    """
    if not text or not text.strip():
        return True

    text = text.strip()

    # Check for pure mathematical/symbolic notation patterns
    math_patterns = [
        r"^[\d\s\+\-\*\/\=\<\>\(\)\[\]\{\}\.\,\;\:\!\?\%\^\&\|\\]+$",  # Math operators
        r"^[A-Za-z][\d\s\+\-\*\/\=]+$",  # Variable with operators (like "x + 2")
        r"^\$.*\$$",  # LaTeX math mode
        r"^\\[a-zA-Z]+",  # LaTeX commands
    ]

    for pattern in math_patterns:
        if re.match(pattern, text):
            return True

    # Count alphabetic vs non-alphabetic characters
    alpha_count = sum(1 for c in text if c.isalpha())
    total_count = len(text.replace(" ", ""))  # Exclude spaces from count

    if total_count == 0:
        return True

    alpha_ratio = alpha_count / total_count

    # If less than 30% alphabetic, consider it symbolic
    return alpha_ratio < 0.3


def is_url(text: str) -> bool:
    """
    Check if text is a URL.

    Args:
        text: The text to check

    Returns:
        True if the text is a URL
    """
    if not text:
        return False

    text = text.strip()

    # Check for common URL patterns
    url_patterns = [
        r"^https?://",  # HTTP/HTTPS
        r"^www\.",  # www prefix
        r"^ftp://",  # FTP
        r"^file://",  # File protocol
        r"^mailto:",  # Email links
    ]

    for pattern in url_patterns:
        if re.match(pattern, text, re.IGNORECASE):
            return True

    return False


def chunk_text(
    lines: List[str],
    chunk_size: int = 20,
) -> Generator[List[str], None, None]:
    """
    Generate chunks of lines for batch processing.

    Args:
        lines: List of text lines to chunk
        chunk_size: Maximum number of lines per chunk

    Yields:
        Lists of lines, each with at most chunk_size items
    """
    for i in range(0, len(lines), chunk_size):
        yield lines[i : i + chunk_size]


def extract_translation(output: str) -> str:
    """
    Extract translation from XML-tagged LLM response.

    Looks for content within <translation>...</translation> tags.
    Falls back to the raw output if tags are not found.

    Args:
        output: The LLM response text

    Returns:
        The extracted translation text
    """
    if not output:
        return ""

    # Try to extract from translation tags
    match = re.search(r"<translation>(.*?)</translation>", output, re.DOTALL)
    if match:
        return match.group(1).strip()

    # Fallback: return cleaned output
    return output.strip()


def remove_control_characters(text: str) -> str:
    """
    Remove Unicode control characters from text.

    Preserves common whitespace characters (newline, carriage return, tab).

    Args:
        text: The text to clean

    Returns:
        Text with control characters removed
    """
    if not text:
        return text

    return "".join(
        char
        for char in text
        if unicodedata.category(char)[0] != "C" or char in "\n\r\t"
    )


def should_translate(text: str) -> bool:
    """
    Determine if text should be translated.

    Text should NOT be translated if:
    - It's empty or whitespace only
    - It's a URL
    - It's primarily symbolic/mathematical

    Args:
        text: The text to check

    Returns:
        True if the text should be translated
    """
    if not text or not text.strip():
        return False

    if is_url(text):
        return False

    if is_symbolic(text):
        return False

    return True


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace while preserving newlines."""
    if not text:
        return text
    lines = text.split("\n")
    return "\n".join(" ".join(line.split()) for line in lines)


def detect_language(text: str, fallback: str = "en") -> Tuple[str, float]:
    """Detect language using langdetect or character heuristics."""
    if not text or len(text.strip()) < 3:
        return fallback, 0.0

    clean_text = text.strip()[:1000]

    try:
        from langdetect import detect_langs
        results = detect_langs(clean_text)
        if results:
            top = results[0]
            code_map = {"zh-cn": "zh-cn", "zh-tw": "zh-cn", "ko": "ko",
                       "th": "th", "vi": "vi", "tl": "fil", "en": "en"}
            return code_map.get(top.lang, top.lang), top.prob
    except Exception:
        pass

    return _detect_language_heuristic(clean_text, fallback)


def _detect_language_heuristic(text: str, fallback: str) -> Tuple[str, float]:
    """Detect language using character-based heuristics."""
    counts = {"cjk": 0, "hangul": 0, "thai": 0, "viet": 0, "latin": 0}
    viet_chars = set("àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ")
    viet_chars.update(c.upper() for c in list(viet_chars))

    for char in text:
        code = ord(char)
        if 0x4E00 <= code <= 0x9FFF:
            counts["cjk"] += 1
        elif 0xAC00 <= code <= 0xD7AF or 0x1100 <= code <= 0x11FF:
            counts["hangul"] += 1
        elif 0x0E00 <= code <= 0x0E7F:
            counts["thai"] += 1
        elif char in viet_chars:
            counts["viet"] += 1
        elif char.isalpha():
            counts["latin"] += 1

    total = sum(counts.values())
    if total == 0:
        return fallback, -1.0

    if counts["hangul"] > total * 0.3:
        return "ko", -1.0
    if counts["thai"] > total * 0.3:
        return "th", -1.0
    if counts["cjk"] > total * 0.3:
        return "zh-cn", -1.0
    if counts["viet"] > total * 0.1:
        return "vi", -1.0

    return "en", -1.0


def extract_text_sample(texts: List[str], max_chars: int = 500) -> str:
    """Extract a representative text sample for language detection."""
    sample, total_len = [], 0
    for text in texts:
        if not text or not text.strip():
            continue
        clean = text.strip()
        if total_len + len(clean) > max_chars:
            remaining = max_chars - total_len
            if remaining > 20:
                sample.append(clean[:remaining])
            break
        sample.append(clean)
        total_len += len(clean) + 1
    return " ".join(sample)

"""Excel handler for XLSX file translation with layout preservation."""

import logging
import os
import re
import tempfile
from typing import List, Optional, Tuple, Any, Set

from openpyxl import load_workbook
from openpyxl.cell.cell import Cell, MergedCell
from openpyxl.utils import get_column_letter

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


def _get_protected_cells(ws) -> Set[str]:
    """Get cells that should NOT be modified (pivots, charts, tables, merged)."""
    protected = set()

    # Pivot table ranges
    try:
        if hasattr(ws, '_pivots') and ws._pivots:
            for pivot in ws._pivots:
                try:
                    if hasattr(pivot, 'cache') and pivot.cache:
                        src = getattr(pivot.cache, 'cacheSource', None)
                        if src and hasattr(src, 'worksheetSource') and src.worksheetSource:
                            ref = src.worksheetSource.ref
                            if ref:
                                protected.update(_expand_range(ref))
                except Exception:
                    pass
    except Exception:
        pass

    # Chart data ranges
    try:
        if hasattr(ws, '_charts') and ws._charts:
            for chart in ws._charts:
                try:
                    for series in getattr(chart, 'series', []):
                        for attr in ['val', 'cat']:
                            if hasattr(series, attr) and getattr(series, attr):
                                ref = getattr(getattr(series, attr), 'numRef', None) or \
                                      getattr(getattr(series, attr), 'strRef', None)
                                if ref and hasattr(ref, 'f'):
                                    protected.update(_parse_chart_ref(ref.f))
                except Exception:
                    pass
    except Exception:
        pass

    # Table ranges
    try:
        if hasattr(ws, 'tables') and ws.tables:
            for table_name in ws.tables:
                try:
                    table = ws.tables[table_name]
                    if hasattr(table, 'ref') and table.ref:
                        protected.update(_expand_range(table.ref))
                except Exception:
                    pass
    except Exception:
        pass

    # Merged cells (skip non-top-left)
    try:
        for merged_range in ws.merged_cells.ranges:
            cells_in_range = list(merged_range.cells)
            for cell_coord in cells_in_range[1:]:
                protected.add(f"{get_column_letter(cell_coord[1])}{cell_coord[0]}")
    except Exception:
        pass

    return protected


def _expand_range(ref: str) -> Set[str]:
    """Expand range like 'A1:C10' into cell coordinates."""
    from openpyxl.utils import range_boundaries
    cells = set()
    try:
        if '!' in ref:
            ref = ref.split('!')[-1]
        min_col, min_row, max_col, max_row = range_boundaries(ref)
        for row in range(min_row, max_row + 1):
            for col in range(min_col, max_col + 1):
                cells.add(f"{get_column_letter(col)}{row}")
    except Exception:
        pass
    return cells


def _parse_chart_ref(formula: str) -> Set[str]:
    """Parse chart reference formula into cell coordinates."""
    cells = set()
    try:
        if '!' in formula:
            formula = formula.split('!')[-1]
        formula = formula.replace('$', '')
        if ':' in formula:
            cells.update(_expand_range(formula))
        else:
            cells.add(formula)
    except Exception:
        pass
    return cells


def _is_translatable_value(value: Any) -> bool:
    """Check if cell value should be translated."""
    try:
        if value is None or not isinstance(value, str) or not value.strip():
            return False
        if value.startswith('='):
            return False
        if re.match(r'^[\d\s,.\-+%$€£¥₩eE]+$', value) and any(c.isdigit() for c in value):
            return False
        if len(value.strip()) < 2:
            return False
        return should_translate(value.strip())
    except Exception:
        return False


def _safe_get_value(cell: Cell) -> Optional[str]:
    try:
        value = cell.value
        return value if isinstance(value, str) else None
    except Exception:
        return None


def _safe_set_value(cell: Cell, value: str) -> bool:
    try:
        cell.value = value
        return True
    except Exception as e:
        logger.warning(f"Failed to set cell value: {e}")
        return False


@register_handler
class XlsxHandler(BaseHandler):
    """
    Excel handler with full layout preservation.

    Preserves: formulas, numbers, pivots, charts, tables, merged cells, styles, images.
    """

    @classmethod
    def supported_extensions(cls) -> List[str]:
        return [".xlsx"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 50,
        sheets: Optional[List[str]] = None,
        skip_hidden: bool = True,
        max_rows_per_batch: int = 1000,
        progress_callback: Optional[callable] = None,
    ) -> TranslationResult:
        stats = {
            "total_sheets": 0, "processed_sheets": 0, "total_cells": 0,
            "translated_cells": 0, "skipped_cells": 0, "error_cells": 0,
        }

        try:
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path, output_path=output_path)

            try:
                wb = load_workbook(input_path)
            except Exception as e:
                return TranslationResult.failure_result(
                    f"Failed to open Excel file: {e}",
                    input_path=input_path, output_path=output_path)

            stats["total_sheets"] = len(wb.sheetnames)

            for sheet_idx, sheet_name in enumerate(wb.sheetnames):
                try:
                    if sheets is not None and sheet_name not in sheets:
                        continue

                    ws = wb[sheet_name]

                    try:
                        if skip_hidden and ws.sheet_state == 'hidden':
                            continue
                    except Exception:
                        pass

                    if progress_callback:
                        progress_callback(sheet_idx, len(wb.sheetnames), f"Processing: {sheet_name}")

                    protected_cells = _get_protected_cells(ws)
                    if protected_cells:
                        logger.info(f"Sheet {sheet_name}: {len(protected_cells)} protected cells")

                    sheet_stats = self._process_sheet(
                        ws, chunk_size, max_rows_per_batch, progress_callback, protected_cells)

                    stats["total_cells"] += sheet_stats["total"]
                    stats["translated_cells"] += sheet_stats["translated"]
                    stats["skipped_cells"] += sheet_stats["skipped"]
                    stats["error_cells"] += sheet_stats["errors"]
                    stats["processed_sheets"] += 1

                except Exception as e:
                    logger.error(f"Error processing sheet {sheet_name}: {e}")
                    continue

            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            temp_fd, temp_path = tempfile.mkstemp(suffix='.xlsx', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                wb.save(temp_path)
                wb.close()
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)
            except Exception as e:
                try:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                    wb.close()
                except Exception:
                    pass
                return TranslationResult.failure_result(
                    f"Failed to save Excel file: {e}",
                    input_path=input_path, output_path=output_path)

            return TranslationResult.success_result(
                input_path=input_path, output_path=output_path,
                source_lang=self.source_lang, target_lang=self.target_lang, stats=stats)

        except Exception as e:
            logger.exception(f"XLSX translation error: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path, output_path=output_path)

    def _process_sheet(
        self, ws, chunk_size: int, max_rows_per_batch: int,
        progress_callback: Optional[callable], protected_cells: Optional[Set[str]] = None,
    ) -> dict:
        stats = {"total": 0, "translated": 0, "skipped": 0, "errors": 0, "protected": 0}
        protected_cells = protected_cells or set()
        cells_batch, cell_refs_batch = [], []

        try:
            max_row = ws.max_row or 1
            max_col = ws.max_column or 1
        except Exception:
            max_row, max_col = 1000000, 100

        row_count = 0
        for row in ws.iter_rows(min_row=1, max_row=max_row, max_col=max_col):
            row_count += 1
            for cell in row:
                try:
                    if isinstance(cell, MergedCell):
                        continue

                    value = _safe_get_value(cell)
                    if value is None:
                        continue

                    stats["total"] += 1
                    cell_coord = f"{get_column_letter(cell.column)}{cell.row}"

                    if cell_coord in protected_cells:
                        stats["protected"] += 1
                        stats["skipped"] += 1
                        continue

                    if _is_translatable_value(value):
                        cells_batch.append(value.strip())
                        cell_refs_batch.append(cell)
                    else:
                        stats["skipped"] += 1

                except Exception as e:
                    logger.debug(f"Error reading cell: {e}")
                    stats["errors"] += 1

            if len(cells_batch) >= chunk_size or row_count % max_rows_per_batch == 0:
                if cells_batch:
                    translated, errors = self._translate_and_update_batch(cells_batch, cell_refs_batch)
                    stats["translated"] += translated
                    stats["errors"] += errors
                    cells_batch, cell_refs_batch = [], []

        if cells_batch:
            translated, errors = self._translate_and_update_batch(cells_batch, cell_refs_batch)
            stats["translated"] += translated
            stats["errors"] += errors

        return stats

    def _translate_and_update_batch(self, texts: List[str], cells: List[Cell]) -> Tuple[int, int]:
        translated_count, error_count = 0, 0

        try:
            all_translated = []
            for chunk in chunk_text(texts, 20):
                try:
                    all_translated.extend(self._translate_texts(chunk))
                except Exception as e:
                    logger.warning(f"Translation API error: {e}")
                    all_translated.extend(chunk)

            for cell, original, translated in zip(cells, texts, all_translated):
                try:
                    full_original = _safe_get_value(cell)
                    if full_original:
                        leading = len(full_original) - len(full_original.lstrip())
                        trailing = len(full_original) - len(full_original.rstrip())
                        if trailing > 0:
                            new_value = full_original[:leading] + translated + full_original[-trailing:]
                        else:
                            new_value = full_original[:leading] + translated

                        if _safe_set_value(cell, new_value):
                            translated_count += 1
                        else:
                            error_count += 1
                    else:
                        error_count += 1
                except Exception as e:
                    logger.debug(f"Error updating cell: {e}")
                    error_count += 1

        except Exception as e:
            logger.error(f"Batch translation error: {e}")
            error_count += len(texts)

        return translated_count, error_count

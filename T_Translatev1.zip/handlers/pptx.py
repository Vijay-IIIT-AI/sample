"""PowerPoint handler with full layout preservation."""

import logging
import os
import tempfile
from typing import List, Optional, Tuple, Any

from pptx import Presentation
from pptx.util import Pt

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


@register_handler
class PptxHandler(BaseHandler):
    """PowerPoint handler with full layout preservation (tables, groups, notes, images, animations)."""

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".pptx"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        max_slides: Optional[int] = None,
        chunk_size: int = 20,
    ) -> TranslationResult:
        """
        Translate a PowerPoint file.

        Extracts text from slides and tables, translates in chunks,
        and writes back while preserving formatting.

        Args:
            input_path: Path to the input PPTX file
            output_path: Path for the output PPTX file
            max_slides: Optional limit on number of slides to process
            chunk_size: Number of text items per translation chunk

        Returns:
            TranslationResult with success status
        """
        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Load presentation
            prs = Presentation(input_path)

            # Collect texts and their locations
            texts, locations = self._collect_texts(prs, max_slides)

            if not texts:
                # No text to translate, just save the file
                prs.save(output_path)
                return TranslationResult.success_result(
                    input_path=input_path,
                    output_path=output_path,
                    source_lang=self.source_lang,
                    target_lang=self.target_lang,
                    stats={"total_texts": 0, "translated_texts": 0},
                )

            # Translate texts in chunks
            translated_texts = []
            for chunk in chunk_text(texts, chunk_size):
                try:
                    chunk_translated = self._translate_texts(chunk)
                    # Validate alignment
                    if len(chunk_translated) != len(chunk):
                        logger.warning(
                            f"Translation count mismatch: expected {len(chunk)}, "
                            f"got {len(chunk_translated)}. Using originals."
                        )
                        chunk_translated = list(chunk)
                    translated_texts.extend(chunk_translated)
                except Exception as e:
                    logger.warning(f"Translation chunk error: {e}")
                    translated_texts.extend(chunk)

            # Write translations back to presentation
            self._write_translations(prs, translated_texts, locations)

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write
            temp_fd, temp_path = tempfile.mkstemp(suffix='.pptx', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                prs.save(temp_path)
                # Atomic rename
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)
            except Exception as e:
                # Clean up temp file on error
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats={
                    "total_texts": len(texts),
                    "translated_texts": len(translated_texts),
                    "slides_processed": max_slides or len(prs.slides),
                },
            )

        except Exception as e:
            logger.exception(f"PPTX translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def _collect_texts(
        self,
        prs: Presentation,
        max_slides: Optional[int] = None,
    ) -> Tuple[List[str], List[Any]]:
        """
        Collect all translatable texts from the presentation.

        Args:
            prs: The Presentation object
            max_slides: Optional limit on slides to process

        Returns:
            Tuple of (texts list, locations list)
            Each location is a direct reference to the Paragraph object
        """
        from pptx.enum.shapes import MSO_SHAPE_TYPE
        
        texts = []
        locations = []

        slides = list(prs.slides)
        if max_slides:
            slides = slides[:max_slides]

        def iter_shapes(shapes_collection):
            """Recursively unroll all shapes, drilling into Groups."""
            for shape in shapes_collection:
                if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                    yield from iter_shapes(shape.shapes)
                else:
                    yield shape

        def iter_paragraphs(shape):
            """Extract paragraphs out of varying Shape architectures natively."""
            # Handle text frames
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    yield paragraph
            
            # Handle tables
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text_frame:
                            for paragraph in cell.text_frame.paragraphs:
                                yield paragraph

        for slide in slides:
            # Process main shapes
            for shape in iter_shapes(slide.shapes):
                for paragraph in iter_paragraphs(shape):
                    text = "".join(run.text for run in paragraph.runs)
                    if text.strip() and should_translate(text.strip()):
                        texts.append(text.strip())
                        locations.append(paragraph)
                        
            # Process Speaker Notes natively if present
            if slide.has_notes_slide:
                notes_slide = slide.notes_slide
                for shape in iter_shapes(notes_slide.shapes):
                    for paragraph in iter_paragraphs(shape):
                        text = "".join(run.text for run in paragraph.runs)
                        if text.strip() and should_translate(text.strip()):
                            texts.append(text.strip())
                            locations.append(paragraph)

        return texts, locations

    def _write_translations(
        self,
        prs: Presentation,
        translated_texts: List[str],
        locations: List[Any],
    ) -> None:
        """
        Write translated texts back to the presentation.

        Args:
            prs: The Presentation object
            translated_texts: List of translated texts
            locations: List of Paragraph objects natively generated by _collect_texts
        """
        for text, paragraph in zip(translated_texts, locations):
            try:
                self._replace_paragraph_text(paragraph, text)
            except Exception:
                # Maintain original structure if writing triggers fault
                continue

    def _replace_paragraph_text(self, paragraph, new_text: str) -> None:
        """
        Replace text in a paragraph while preserving formatting.

        Clears all runs except the first, then sets the new text.
        Proactively reduces font size if translations significantly increase length.

        Args:
            paragraph: The paragraph object
            new_text: The new text to set
        """
        if not paragraph.runs:
            # Add a run if a paragraph structurally has zero initially
            run = paragraph.add_run()
            run.text = new_text
            return

        # Calculate length ratio to check for text overflow ("German problem")
        original_text = "".join(run.text for run in paragraph.runs)
        
        # Preserve first run's formatting, clear others
        first_run = paragraph.runs[0]
        for run in paragraph.runs:
            run.text = ""

        # Set new text in first run
        first_run.text = new_text

        # If text is significantly longer (>20%), natively reduce font size slightly
        if original_text and len(new_text) > len(original_text) * 1.2:
            if first_run.font and first_run.font.size:
                from pptx.util import Pt
                current_size = first_run.font.size.pt
                new_size = max(current_size * 0.85, 8.0)  # Don't shrink below 8pt
                first_run.font.size = Pt(new_size)

"""CSV handler with streaming, auto delimiter/encoding detection, and smart cell filtering."""

import csv
import logging
import os
import re
import tempfile
from typing import List, Optional, Tuple, Set

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


# Patterns for content that should NOT be translated
SKIP_PATTERNS = [
    re.compile(r'^\d+$'),                          # Pure numbers
    re.compile(r'^[A-Z0-9_-]+$'),                  # Product codes, IDs
    re.compile(r'^[A-Z]{2,5}-\d+$'),               # Order IDs like ORD-1234
    re.compile(r'^\d{4}-\d{2}-\d{2}'),             # Dates YYYY-MM-DD
    re.compile(r'^\d{2}/\d{2}/\d{4}'),             # Dates DD/MM/YYYY
    re.compile(r'^[\w.-]+@[\w.-]+\.\w+$'),         # Emails
    re.compile(r'^https?://'),                      # URLs
    re.compile(r'^www\.'),                          # URLs without protocol
    re.compile(r'^[+]?\d[\d\s()-]{6,}$'),          # Phone numbers
    re.compile(r'^#[0-9A-Fa-f]{6}$'),              # Hex colors
    re.compile(r'^\$[\d,.]+$'),                    # Currency
    re.compile(r'^[\d,.]+%$'),                     # Percentages
    re.compile(r'^[A-Z0-9]{8,}$'),                 # Long codes/hashes
    re.compile(r'^\d+\.\d+\.\d+'),                 # Version numbers
    re.compile(r'^[\w.-]+\.(com|org|net|io)$'),   # Domain names
]


def _should_skip_cell(value: str) -> bool:
    """Check if cell value should be skipped (not translated)."""
    if not value or not isinstance(value, str):
        return True

    stripped = value.strip()
    if not stripped:
        return True

    # Skip very short values
    if len(stripped) < 2:
        return True

    # Check against skip patterns
    for pattern in SKIP_PATTERNS:
        if pattern.match(stripped):
            return True

    return False


def _is_translatable_cell(value: str) -> bool:
    """Check if a cell value should be translated."""
    if _should_skip_cell(value):
        return False
    return should_translate(value.strip())


def _detect_encoding(file_path: str) -> str:
    """Detect file encoding by trying multiple encodings."""
    encodings = ['utf-8', 'utf-8-sig', 'utf-16', 'latin-1', 'cp1252', 'iso-8859-1']

    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                # Try to read first few KB
                f.read(8192)
            return encoding
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception:
            continue

    return 'utf-8'  # Default fallback


def _detect_delimiter(file_path: str, encoding: str) -> str:
    """Detect CSV delimiter with multiple fallback strategies."""
    common_delimiters = [',', ';', '\t', '|', ':']

    try:
        with open(file_path, 'r', encoding=encoding, errors='replace') as f:
            sample = f.read(16384)  # Read more for better detection

        # Strategy 1: Try csv.Sniffer
        try:
            sniffer = csv.Sniffer()
            dialect = sniffer.sniff(sample, delimiters=''.join(common_delimiters))
            return dialect.delimiter
        except csv.Error:
            pass

        # Strategy 2: Count occurrences of common delimiters
        lines = sample.split('\n')[:10]  # First 10 lines
        if lines:
            delimiter_counts = {}
            for delim in common_delimiters:
                counts = [line.count(delim) for line in lines if line.strip()]
                if counts:
                    # Check if counts are consistent (same number per line)
                    avg_count = sum(counts) / len(counts)
                    variance = sum((c - avg_count) ** 2 for c in counts) / len(counts)
                    if avg_count > 0 and variance < 1:  # Low variance = consistent
                        delimiter_counts[delim] = avg_count

            if delimiter_counts:
                # Return delimiter with highest consistent count
                return max(delimiter_counts, key=delimiter_counts.get)

    except Exception as e:
        logger.debug(f"Delimiter detection error: {e}")

    return ','  # Default to comma


def _count_rows(file_path: str, encoding: str) -> int:
    """Count total rows in file for progress tracking."""
    try:
        with open(file_path, 'r', encoding=encoding, errors='replace') as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def _split_long_text(text: str, max_length: int = 2000) -> List[str]:
    """Split long text into chunks at sentence boundaries."""
    if len(text) <= max_length:
        return [text]

    chunks = []
    current_chunk = ""

    # Try to split at sentence boundaries
    sentences = re.split(r'(?<=[.!?])\s+', text)

    for sentence in sentences:
        if len(current_chunk) + len(sentence) <= max_length:
            current_chunk += (" " if current_chunk else "") + sentence
        else:
            if current_chunk:
                chunks.append(current_chunk)
            # If single sentence is too long, force split
            if len(sentence) > max_length:
                for i in range(0, len(sentence), max_length):
                    chunks.append(sentence[i:i+max_length])
                current_chunk = ""
            else:
                current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


@register_handler
class CsvHandler(BaseHandler):
    """
    Handler for CSV (.csv) files.

    Production-ready with:
    - Robust encoding and delimiter detection
    - Streaming for millions of rows
    - Smart cell filtering
    - Translation alignment safety
    - Atomic writes
    """

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".csv"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 50,
        skip_rows: int = 0,
        columns: Optional[List[int]] = None,
        delimiter: Optional[str] = None,
        quotechar: str = '"',
        encoding: Optional[str] = None,
        batch_rows: int = 500,
        max_cell_length: int = 2000,
        progress_callback: Optional[callable] = None,
    ) -> TranslationResult:
        """
        Translate a CSV file with streaming support.

        Args:
            input_path: Path to the input CSV file
            output_path: Path for the output CSV file
            chunk_size: Number of cells per translation API batch
            skip_rows: Number of header/metadata rows to skip
            columns: List of column indices to translate (0-indexed), None for all
            delimiter: CSV delimiter (auto-detected if None)
            quotechar: CSV quote character
            encoding: File encoding (auto-detected if None)
            batch_rows: Rows to collect before translating
            max_cell_length: Max characters per cell before splitting
            progress_callback: Optional callback(current_row, total_rows, message)

        Returns:
            TranslationResult with success status
        """
        stats = {
            "total_rows": 0,
            "total_cells": 0,
            "translated_cells": 0,
            "skipped_cells": 0,
            "error_cells": 0,
            "error_rows": 0,
        }

        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Detect encoding if not specified
            detected_encoding = encoding or _detect_encoding(input_path)
            logger.info(f"Using encoding: {detected_encoding}")

            # Detect delimiter if not specified
            detected_delimiter = delimiter or _detect_delimiter(input_path, detected_encoding)
            logger.info(f"Using delimiter: {repr(detected_delimiter)}")

            # Count total rows for progress
            total_row_count = _count_rows(input_path, detected_encoding)

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write
            temp_fd, temp_path = tempfile.mkstemp(suffix='.csv', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                self._process_csv_file(
                    input_path=input_path,
                    temp_path=temp_path,
                    encoding=detected_encoding,
                    delimiter=detected_delimiter,
                    quotechar=quotechar,
                    skip_rows=skip_rows,
                    columns=columns,
                    chunk_size=chunk_size,
                    batch_rows=batch_rows,
                    max_cell_length=max_cell_length,
                    total_row_count=total_row_count,
                    progress_callback=progress_callback,
                    stats=stats,
                )

                # Atomic rename
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)

            except Exception as e:
                # Clean up temp file on error
                try:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                except Exception:
                    pass
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats=stats,
            )

        except Exception as e:
            logger.exception(f"CSV translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def _process_csv_file(
        self,
        input_path: str,
        temp_path: str,
        encoding: str,
        delimiter: str,
        quotechar: str,
        skip_rows: int,
        columns: Optional[List[int]],
        chunk_size: int,
        batch_rows: int,
        max_cell_length: int,
        total_row_count: int,
        progress_callback: Optional[callable],
        stats: dict,
    ) -> None:
        """Process CSV file with streaming."""

        with open(input_path, "r", encoding=encoding, newline="", errors='replace') as infile, \
             open(temp_path, "w", encoding="utf-8", newline="") as outfile:

            reader = csv.reader(infile, delimiter=delimiter, quotechar=quotechar)
            # Use QUOTE_ALL for safety - prevents issues if translation adds special chars
            writer = csv.writer(
                outfile,
                delimiter=delimiter,
                quotechar=quotechar,
                quoting=csv.QUOTE_ALL
            )

            row_buffer = []
            # (row_idx_in_buffer, col_idx, original_text, is_split, split_idx)
            cell_info_buffer = []

            for row_num, row in enumerate(reader):
                try:
                    stats["total_rows"] += 1

                    # Skip header/metadata rows
                    if row_num < skip_rows:
                        writer.writerow(row)
                        continue

                    # Copy row for modification
                    row_copy = list(row)
                    row_buffer.append(row_copy)
                    row_idx_in_buffer = len(row_buffer) - 1

                    # Process each cell
                    for col_idx, cell in enumerate(row):
                        try:
                            # Check if column should be translated
                            if columns is not None and col_idx not in columns:
                                stats["skipped_cells"] += 1
                                continue

                            stats["total_cells"] += 1

                            if _is_translatable_cell(cell):
                                # Handle long cells by splitting
                                cell_text = cell.strip()
                                if len(cell_text) > max_cell_length:
                                    chunks = _split_long_text(cell_text, max_cell_length)
                                    for split_idx, chunk in enumerate(chunks):
                                        cell_info_buffer.append((
                                            row_idx_in_buffer,
                                            col_idx,
                                            chunk,
                                            True,  # is_split
                                            split_idx,
                                            len(chunks)  # total_splits
                                        ))
                                else:
                                    cell_info_buffer.append((
                                        row_idx_in_buffer,
                                        col_idx,
                                        cell_text,
                                        False,  # is_split
                                        0,
                                        1
                                    ))
                            else:
                                stats["skipped_cells"] += 1

                        except Exception as e:
                            logger.debug(f"Error processing cell [{row_num}][{col_idx}]: {e}")
                            stats["error_cells"] += 1

                    # Process batch when full
                    if len(row_buffer) >= batch_rows:
                        self._process_and_write_batch(
                            row_buffer, cell_info_buffer, writer, chunk_size, stats
                        )
                        row_buffer = []
                        cell_info_buffer = []

                        # Progress callback
                        if progress_callback and total_row_count > 0:
                            progress_callback(
                                stats["total_rows"],
                                total_row_count,
                                f"Processed {stats['total_rows']}/{total_row_count} rows"
                            )

                except Exception as e:
                    logger.warning(f"Error processing row {row_num}: {e}")
                    stats["error_rows"] += 1
                    # Write original row on error
                    try:
                        writer.writerow(row)
                    except Exception:
                        pass

            # Process remaining rows
            if row_buffer:
                self._process_and_write_batch(
                    row_buffer, cell_info_buffer, writer, chunk_size, stats
                )

    def _process_and_write_batch(
        self,
        row_buffer: List[List[str]],
        cell_info_buffer: List[Tuple],
        writer,
        chunk_size: int,
        stats: dict,
    ) -> None:
        """Process a batch of rows and write to output."""
        try:
            if cell_info_buffer:
                # Extract texts to translate
                texts = [info[2] for info in cell_info_buffer]

                # Translate in API chunks
                translated_texts = []
                for chunk in chunk_text(texts, chunk_size):
                    try:
                        chunk_translated = self._translate_texts(chunk)

                        # SAFETY CHECK: Verify count matches
                        if len(chunk_translated) != len(chunk):
                            logger.warning(
                                f"Translation count mismatch: expected {len(chunk)}, "
                                f"got {len(chunk_translated)}. Using originals."
                            )
                            chunk_translated = list(chunk)

                        translated_texts.extend(chunk_translated)

                    except Exception as e:
                        logger.warning(f"Translation API error: {e}")
                        translated_texts.extend(chunk)  # Keep original

                # Group translations by (row_idx, col_idx) for split cells
                cell_translations = {}
                for info, translated in zip(cell_info_buffer, translated_texts):
                    row_idx, col_idx, original, is_split, split_idx, total_splits = info
                    key = (row_idx, col_idx)

                    if key not in cell_translations:
                        cell_translations[key] = {
                            'parts': [None] * total_splits,
                            'original_cell': row_buffer[row_idx][col_idx]
                        }

                    cell_translations[key]['parts'][split_idx] = translated

                # Apply translations to cells
                for (row_idx, col_idx), data in cell_translations.items():
                    try:
                        original_cell = data['original_cell']
                        
                        # Reconstruct full translation from parts
                        if None in data['parts']:
                            logger.warning(f"Incomplete translation parts for cell. Falling back to original.")
                            translated = original_cell.strip()
                        else:
                            translated = ' '.join(data['parts'])

                        # Preserve whitespace from original
                        leading, trailing = self._get_whitespace(original_cell)

                        row_buffer[row_idx][col_idx] = leading + translated + trailing
                        stats["translated_cells"] += 1

                    except Exception as e:
                        logger.debug(f"Error updating cell: {e}")
                        stats["error_cells"] += 1

            # Write all rows
            for row in row_buffer:
                try:
                    writer.writerow(row)
                except Exception as e:
                    logger.warning(f"Error writing row: {e}")
                    stats["error_rows"] += 1

        except Exception as e:
            logger.error(f"Batch processing error: {e}")
            # Write original rows on catastrophic error
            for row in row_buffer:
                try:
                    writer.writerow(row)
                except Exception:
                    pass

    def _get_whitespace(self, text: str) -> Tuple[str, str]:
        """Extract leading and trailing whitespace using regex."""
        if not text:
            return '', ''

        leading_match = re.match(r'^(\s*)', text)
        trailing_match = re.search(r'(\s*)$', text)

        leading = leading_match.group(1) if leading_match else ''
        trailing = trailing_match.group(1) if trailing_match else ''

        return leading, trailing

"""
Handler registry and factory for file type handlers.

Provides automatic handler discovery based on file extension.
"""

from typing import Dict, List, Optional, Type

from .base import BaseHandler

# Handler registry - maps file extensions to handler classes
_HANDLER_REGISTRY: Dict[str, Type[BaseHandler]] = {}


def register_handler(handler_class: Type[BaseHandler]) -> Type[BaseHandler]:
    """
    Register a handler class for its supported extensions.

    Can be used as a decorator:
        @register_handler
        class MyHandler(BaseHandler):
            ...

    Args:
        handler_class: The handler class to register

    Returns:
        The handler class (for decorator use)
    """
    for ext in handler_class.supported_extensions():
        _HANDLER_REGISTRY[ext.lower().lstrip(".")] = handler_class
    return handler_class


def get_handler_class(extension: str) -> Optional[Type[BaseHandler]]:
    """
    Get the handler class for a file extension.

    Args:
        extension: File extension (with or without leading dot)

    Returns:
        The handler class, or None if not found
    """
    ext = extension.lower().lstrip(".")
    return _HANDLER_REGISTRY.get(ext)


def get_supported_extensions() -> List[str]:
    """
    Get list of all supported file extensions.

    Returns:
        List of extension strings (without dots)
    """
    return list(_HANDLER_REGISTRY.keys())


def is_supported(extension: str) -> bool:
    """
    Check if a file extension is supported.

    Args:
        extension: File extension (with or without leading dot)

    Returns:
        True if the extension is supported
    """
    return get_handler_class(extension) is not None


# Import handlers to trigger registration
# These imports must be at the bottom to avoid circular imports
from .txt import TxtHandler
from .pptx import PptxHandler
from .docx import DocxHandler
from .html import HTMLHandler
from .csv_handler import CsvHandler
from .md import MarkdownHandler
from .xlsx import XlsxHandler

# PDF handler has heavy dependencies (cv2, onnx, pymupdf) - make it optional
PDFHandler = None
try:
    from .pdf import PDFHandler
except ImportError as e:
    import logging
    logging.getLogger(__name__).warning(
        f"PDF handler not available - missing dependencies: {e}. "
        "Install with: pip install opencv-python onnxruntime pymupdf pdfminer.six"
    )

__all__ = [
    "BaseHandler",
    "TxtHandler",
    "PptxHandler",
    "DocxHandler",
    "PDFHandler",
    "HTMLHandler",
    "CsvHandler",
    "MarkdownHandler",
    "XlsxHandler",
    "register_handler",
    "get_handler_class",
    "get_supported_extensions",
    "is_supported",
]

"""
PDF converter for translation.

Provides TranslateConverter class that processes PDF content
and applies translations while preserving layout.
"""

import concurrent.futures
import re
import unicodedata
from enum import Enum
from string import Template
from typing import Dict, Optional

import numpy as np
from pdfminer.converter import PDFConverter
from pdfminer.layout import LTChar, LTFigure, LTLine, LTPage
from pdfminer.pdffont import PDFCIDFont, PDFUnicodeNotDefined
from pdfminer.pdfinterp import PDFGraphicState, PDFResourceManager
from pdfminer.utils import apply_matrix_pt, mult_matrix
from pymupdf import Font
from tenacity import retry, wait_fixed


class OpType(Enum):
    """PDF operation types."""
    TEXT = "text"
    LINE = "line"


class PDFConverterEx(PDFConverter):
    """Extended PDF converter with custom character rendering."""

    def __init__(self, rsrcmgr: PDFResourceManager) -> None:
        PDFConverter.__init__(self, rsrcmgr, None, "utf-8", 1, None)

    def begin_page(self, page, ctm) -> None:
        """Begin processing a page - override to replace cropbox."""
        (x0, y0, x1, y1) = page.cropbox
        (x0, y0) = apply_matrix_pt(ctm, (x0, y0))
        (x1, y1) = apply_matrix_pt(ctm, (x1, y1))
        mediabox = (0, 0, abs(x0 - x1), abs(y0 - y1))
        self.cur_item = LTPage(page.pageno, mediabox)

    def end_page(self, page):
        """End page processing - override to return instruction stream."""
        return self.receive_layout(self.cur_item)

    def begin_figure(self, name, bbox, matrix) -> None:
        """Begin figure - override to set pageid."""
        self._stack.append(self.cur_item)
        self.cur_item = LTFigure(name, bbox, mult_matrix(matrix, self.ctm))
        self.cur_item.pageid = self._stack[-1].pageid

    def end_figure(self, _: str) -> None:
        """End figure - override to return instruction stream."""
        fig = self.cur_item
        assert isinstance(self.cur_item, LTFigure), str(type(self.cur_item))
        self.cur_item = self._stack.pop()
        self.cur_item.add(fig)
        return self.receive_layout(fig)

    def render_image(self, name, stream):
        """Preserve images by returning empty string."""
        return ""

    def render_char(
        self,
        matrix,
        font,
        fontsize: float,
        scaling: float,
        rise: float,
        cid: int,
        ncs,
        graphicstate: PDFGraphicState,
    ) -> float:
        """Render character - override to set cid and font."""
        try:
            text = font.to_unichr(cid)
            assert isinstance(text, str), str(type(text))
        except PDFUnicodeNotDefined:
            text = self.handle_undefined_char(font, cid)

        textwidth = font.char_width(cid)
        textdisp = font.char_disp(cid)
        item = LTChar(
            matrix,
            font,
            fontsize,
            scaling,
            rise,
            text,
            textwidth,
            textdisp,
            ncs,
            graphicstate,
        )
        self.cur_item.add(item)
        item.cid = cid  # Store original character encoding
        item.font = font  # Store original character font
        return item.adv


class Paragraph:
    """Represents a paragraph in the PDF document."""

    def __init__(self, y, x, x0, x1, y0, y1, size, brk, ncolor=None):
        self.y: float = y  # Initial vertical coordinate
        self.x: float = x  # Initial horizontal coordinate
        self.x0: float = x0  # Left boundary
        self.x1: float = x1  # Right boundary
        self.y0: float = y0  # Top boundary
        self.y1: float = y1  # Bottom boundary
        self.size: float = size  # Font size
        self.brk: bool = brk  # Line break marker
        self.ncolor = ncolor  # Color information


class TranslateConverter(PDFConverterEx):
    """
    PDF converter that translates text content.

    Processes PDF pages, extracts text, translates using the provided
    translator, and generates new PDF content with translated text.
    """

    def __init__(
        self,
        rsrcmgr,
        vfont: str = None,
        vchar: str = None,
        thread: int = 0,
        layout={},
        lang_in: str = "",
        lang_out: str = "",
        service: str = "",
        noto_name: str = "",
        noto: Font = None,
        envs: Dict = None,
        prompt: Template = None,
        llm_client=None,
    ) -> None:
        super().__init__(rsrcmgr)
        self.vfont = vfont
        self.vchar = vchar
        self.thread = thread
        self.layout = layout
        self.noto_name = noto_name
        self.noto = noto
        self.lang_in = lang_in
        self.lang_out = lang_out
        self.llm_client = llm_client

    def receive_layout(self, ltpage: LTPage):
        """
        Process page layout and generate translated content.

        This is the main method that:
        1. Parses the original document
        2. Translates paragraph text
        3. Generates new PDF content
        """
        # Paragraph stacks
        sstk: list[str] = []  # Paragraph text stack
        pstk: list[Paragraph] = []  # Paragraph attribute stack
        vbkt: int = 0  # Paragraph formula bracket count

        # Formula group
        vstk: list[LTChar] = []  # Formula symbol group
        vlstk: list[LTLine] = []  # Formula line group
        vfix: float = 0  # Formula vertical offset

        # Formula group stack
        var: list[list[LTChar]] = []  # Formula symbol group stack
        varl: list[list[LTLine]] = []  # Formula line group stack
        varf: list[float] = []  # Formula vertical offset stack
        vlen: list[float] = []  # Formula width stack

        # Global
        lstk: list[LTLine] = []  # Global line stack
        xt: LTChar = None  # Previous character
        xt_cls: int = -1  # Previous character's paragraph class
        vmax: float = ltpage.width / 4  # Maximum inline formula width
        ops: str = ""  # Rendering result

        def vflag(font: str, char: str) -> bool:
            """Check if character belongs to formula based on font/char."""
            if isinstance(font, bytes):
                try:
                    font = font.decode('utf-8')
                except UnicodeDecodeError:
                    font = ""
            font = font.split("+")[-1]

            if re.match(r"\(cid:", char):
                return True

            # Font name rule-based determination
            if self.vfont:
                if re.match(self.vfont, font):
                    return True
            else:
                if re.match(
                    r"(CM[^R]|MS.M|XY|MT|BL|RM|EU|LA|RS|LINE|LCIRCLE|TeX-|rsfs|txsy|wasy|stmary|.*Mono|.*Code|.*Ital|.*Sym|.*Math)",
                    font,
                ):
                    return True

            # Character set rule-based determination
            if self.vchar:
                if re.match(self.vchar, char):
                    return True
            else:
                if (
                    char
                    and char != " "
                    and (
                        unicodedata.category(char[0])
                        in ["Lm", "Mn", "Sk", "Sm", "Zl", "Zp", "Zs"]
                        or ord(char[0]) in range(0x370, 0x400)  # Greek letters
                    )
                ):
                    return True

            return False

        # A. Original document parsing
        for child in ltpage:
            if isinstance(child, LTChar):
                cur_v = False
                layout = self.layout[ltpage.pageid]
                h, w = layout.shape

                # Read current character's class in layout
                cx, cy = np.clip(int(child.x0), 0, w - 1), np.clip(int(child.y0), 0, h - 1)
                cls = layout[cy, cx]

                # Anchor bullet position
                if child.get_text() == "":
                    cls = 0

                # Determine if current character belongs to formula
                if (
                    cls == 0  # Reserved area
                    or (
                        cls == xt_cls
                        and len(sstk[-1].strip()) > 1
                        and child.size < pstk[-1].size * 0.79
                    )  # Subscript
                    or vflag(child.fontname, child.get_text())  # Formula font
                    or (child.matrix[0] == 0 and child.matrix[3] == 0)  # Vertical font
                ):
                    cur_v = True

                # Check bracket groups
                if not cur_v:
                    if vstk and child.get_text() == "(":
                        cur_v = True
                        vbkt += 1
                    if vbkt and child.get_text() == ")":
                        cur_v = True
                        vbkt -= 1

                # Determine if current formula ends
                if (
                    not cur_v
                    or cls != xt_cls
                    or (sstk[-1] != "" and abs(child.x0 - xt.x0) > vmax)
                ):
                    if vstk:
                        if (
                            not cur_v
                            and cls == xt_cls
                            and child.x0 > max([vch.x0 for vch in vstk])
                        ):
                            vfix = vstk[0].y0 - child.y0

                        if sstk[-1] == "":
                            xt_cls = -1

                        sstk[-1] += f"{{v{len(var)}}}"
                        var.append(vstk)
                        varl.append(vlstk)
                        varf.append(vfix)
                        vstk = []
                        vlstk = []
                        vfix = 0

                # Handle text/formula
                if not vstk:
                    if cls == xt_cls:
                        if child.x0 > xt.x1 + 1:
                            sstk[-1] += " "
                        elif child.x1 < xt.x0:
                            sstk[-1] += " "
                            pstk[-1].brk = True
                    else:
                        sstk.append("")
                        ncolor = getattr(child.graphicstate, 'ncolor', None)
                        if ncolor is None:
                            scolor = getattr(child.graphicstate, 'scolor', None)
                            if scolor and hasattr(scolor, 'resolve'):
                                try:
                                    resolved_color = scolor.resolve()
                                    if isinstance(resolved_color, (tuple, list)) and len(resolved_color) >= 3:
                                        ncolor = resolved_color[:3]
                                except Exception:
                                    pass
                        if ncolor is None:
                            ncolor = (0.0, 0.0, 0.0)
                        pstk.append(
                            Paragraph(
                                child.y0, child.x0, child.x0, child.x0,
                                child.y0, child.y1, child.size, False, ncolor
                            )
                        )

                if not cur_v:
                    if (
                        child.size > pstk[-1].size
                        or len(sstk[-1].strip()) == 1
                    ) and child.get_text() != " ":
                        pstk[-1].y -= child.size - pstk[-1].size
                        pstk[-1].size = child.size
                    sstk[-1] += child.get_text()
                else:
                    if (
                        not vstk
                        and cls == xt_cls
                        and child.x0 > xt.x0
                    ):
                        vfix = child.y0 - xt.y0
                    vstk.append(child)

                # Update paragraph boundaries
                pstk[-1].x0 = min(pstk[-1].x0, child.x0)
                pstk[-1].x1 = max(pstk[-1].x1, child.x1)
                pstk[-1].y0 = min(pstk[-1].y0, child.y0)
                pstk[-1].y1 = max(pstk[-1].y1, child.y1)

                # Update previous character
                xt = child
                xt_cls = cls

            elif isinstance(child, LTFigure):
                pass

            elif isinstance(child, LTLine):
                layout = self.layout[ltpage.pageid]
                h, w = layout.shape
                cx, cy = np.clip(int(child.x0), 0, w - 1), np.clip(int(child.y0), 0, h - 1)
                cls = layout[cy, cx]
                if vstk and cls == xt_cls:
                    vlstk.append(child)
                else:
                    lstk.append(child)

        # Handle ending
        if vstk:
            sstk[-1] += f"{{v{len(var)}}}"
            var.append(vstk)
            varl.append(vlstk)
            varf.append(vfix)

        for id, v in enumerate(var):
            l = max([vch.x1 for vch in v]) - v[0].x0
            vlen.append(l)

        # B. Paragraph translation
        @retry(wait=wait_fixed(1))
        def worker(s: str) -> str:
            """Translate a single paragraph."""
            if not s.strip() or re.match(r"^\{v\d+\}$", s):
                return s
            try:
                if self.llm_client:
                    new = self.llm_client.translate(s, self.lang_in, self.lang_out)
                    return new if new else s
                return s
            except Exception:
                return s

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.thread) as executor:
            news = list(executor.map(worker, sstk))

        # C. Document Layout
        def raw_string(fcur: str, cstk: str) -> str:
            """Encode string for PDF output."""
            if fcur == self.noto_name:
                return "".join(["%04x" % self.noto.has_glyph(ord(c)) for c in cstk])
            elif hasattr(self, 'fontmap') and self.fontmap and fcur in self.fontmap:
                if isinstance(self.fontmap[fcur], PDFCIDFont):
                    return "".join(["%04x" % ord(c) for c in cstk])
                else:
                    return "".join(["%02x" % ord(c) for c in cstk])
            else:
                # Fallback for missing font - use hex encoding
                return "".join(["%04x" % ord(c) for c in cstk])

        # Line height map for different languages
        LANG_LINEHEIGHT_MAP = {
            "en": 1.2, "english": 1.2,
            "ko": 1.2, "korean": 1.2,
            "zh-cn": 1.4, "zh": 1.4, "chinese": 1.4,
            "vi": 1.2, "vietnamese": 1.2,
            "fil": 1.2, "filipino": 1.2,
            "th": 1.3, "thai": 1.3,
        }
        default_line_height = LANG_LINEHEIGHT_MAP.get(self.lang_out.lower(), 1.1)

        ops_list = []

        def gen_op_txt(font, size, x, y, rtxt, ncolor=None):
            """Generate PDF text operation."""
            if ncolor and isinstance(ncolor, (tuple, list)) and len(ncolor) >= 3:
                r, g, b = ncolor[:3]
                r = max(0.0, min(1.0, float(r)))
                g = max(0.0, min(1.0, float(g)))
                b = max(0.0, min(1.0, float(b)))
                color_ops = f"{r:f} {g:f} {b:f} rg "
            else:
                color_ops = "0 0 0 rg "
            return f"BT {color_ops}/{font} {size:f} Tf 1 0 0 1 {x:f} {y:f} Tm [<{rtxt}>] TJ ET "

        def gen_op_line(x, y, xlen, ylen, linewidth):
            """Generate PDF line operation."""
            return f"ET q 1 0 0 1 {x:f} {y:f} cm [] 0 d 0 J {linewidth:f} w 0 0 m {xlen:f} {ylen:f} l S Q BT "

        for id, new in enumerate(news):
            x: float = pstk[id].x
            y: float = pstk[id].y
            x0: float = pstk[id].x0
            x1: float = pstk[id].x1
            height: float = pstk[id].y1 - pstk[id].y0
            size: float = pstk[id].size
            brk: bool = pstk[id].brk
            ncolor = pstk[id].ncolor
            cstk: str = ""
            fcur: str = None
            lidx = 0
            tx = x
            fcur_ = fcur
            ptr = 0

            ops_vals: list[dict] = []

            while ptr < len(new):
                vy_regex = re.match(r"\{\s*v([\d\s]+)\}", new[ptr:], re.IGNORECASE)
                mod = 0

                if vy_regex:
                    ptr += len(vy_regex.group(0))
                    try:
                        vid = int(vy_regex.group(1).replace(" ", ""))
                        adv = vlen[vid]
                    except Exception:
                        continue

                    if (
                        var[vid][-1].get_text()
                        and unicodedata.category(var[vid][-1].get_text()[0]) in ["Lm", "Mn", "Sk"]
                    ):
                        mod = var[vid][-1].width
                else:
                    ch = new[ptr]
                    fcur_ = None

                    try:
                        if fcur_ is None and self.fontmap["tiro"].to_unichr(ord(ch)) == ch:
                            fcur_ = "tiro"
                    except Exception:
                        pass

                    if fcur_ is None:
                        fcur_ = self.noto_name

                    if fcur_ == self.noto_name:
                        adv = self.noto.char_lengths(ch, size)[0]
                    else:
                        adv = self.fontmap[fcur_].char_width(ord(ch)) * size

                    ptr += 1

                # Output text buffer
                if fcur_ != fcur or vy_regex or x + adv > x1 + 0.1 * size:
                    if cstk:
                        ops_vals.append({
                            "type": OpType.TEXT,
                            "font": fcur,
                            "size": size,
                            "x": tx,
                            "dy": 0,
                            "rtxt": raw_string(fcur, cstk),
                            "lidx": lidx,
                            "ncolor": ncolor,
                        })
                        cstk = ""

                if brk and x + adv > x1 + 0.1 * size:
                    x = x0
                    lidx += 1

                if vy_regex:
                    fix = 0
                    if fcur is not None:
                        fix = varf[vid]

                    for vch in var[vid]:
                        vc = chr(vch.cid)
                        ops_vals.append({
                            "type": OpType.TEXT,
                            "font": self.fontid[vch.font],
                            "size": vch.size,
                            "x": x + vch.x0 - var[vid][0].x0,
                            "dy": fix + vch.y0 - var[vid][0].y0,
                            "rtxt": raw_string(self.fontid[vch.font], vc),
                            "lidx": lidx,
                            "ncolor": getattr(vch.graphicstate, 'ncolor', None),
                        })

                    for l in varl[vid]:
                        if l.linewidth < 5:
                            ops_vals.append({
                                "type": OpType.LINE,
                                "x": l.pts[0][0] + x - var[vid][0].x0,
                                "dy": l.pts[0][1] + fix - var[vid][0].y0,
                                "linewidth": l.linewidth,
                                "xlen": l.pts[1][0] - l.pts[0][0],
                                "ylen": l.pts[1][1] - l.pts[0][1],
                                "lidx": lidx,
                            })
                else:
                    if not cstk:
                        tx = x
                        if x == x0 and ch == " ":
                            adv = 0
                        else:
                            cstk += ch
                    else:
                        cstk += ch

                adv -= mod
                fcur = fcur_
                x += adv

            # Handle ending
            if cstk:
                ops_vals.append({
                    "type": OpType.TEXT,
                    "font": fcur,
                    "size": size,
                    "x": tx,
                    "dy": 0,
                    "rtxt": raw_string(fcur, cstk),
                    "lidx": lidx,
                    "ncolor": ncolor,
                })

            line_height = default_line_height
            while (lidx + 1) * size * line_height > height and line_height >= 1:
                line_height -= 0.05

            for vals in ops_vals:
                if vals["type"] == OpType.TEXT:
                    ops_list.append(
                        gen_op_txt(
                            vals["font"],
                            vals["size"],
                            vals["x"],
                            vals["dy"] + y - vals["lidx"] * size * line_height,
                            vals["rtxt"],
                            vals.get("ncolor"),
                        )
                    )
                elif vals["type"] == OpType.LINE:
                    ops_list.append(
                        gen_op_line(
                            vals["x"],
                            vals["dy"] + y - vals["lidx"] * size * line_height,
                            vals["xlen"],
                            vals["ylen"],
                            vals["linewidth"],
                        )
                    )

        # Layout global lines
        for l in lstk:
            if l.linewidth < 5:
                ops_list.append(
                    gen_op_line(
                        l.pts[0][0],
                        l.pts[0][1],
                        l.pts[1][0] - l.pts[0][0],
                        l.pts[1][1] - l.pts[0][1],
                        l.linewidth,
                    )
                )

        ops = f"BT {''.join(ops_list)}ET "
        return ops

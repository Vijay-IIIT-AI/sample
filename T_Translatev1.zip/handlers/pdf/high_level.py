"""
High-level PDF translation functions.

Provides the main translate() function for PDF files.
"""

import asyncio
import io
import os
import re
import sys
import tempfile
from asyncio import CancelledError
from pathlib import Path
from string import Template
from typing import Any, BinaryIO, Dict, List, Optional

import numpy as np
import tqdm
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfexceptions import PDFValueError
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from pymupdf import Document, Font

from .converter import TranslateConverter
from .doclayout import OnnxModel
from .pdfinterp import PDFPageInterpreterEx


NOTO_NAME = "noto"

# Language codes that use Noto font (Latin-based languages)
NOTO_LANGUAGES = ["en", "english", "vi", "vietnamese", "fil", "filipino", "th", "thai"]


def check_files(files: List[str]) -> List[str]:
    """Check which files don't exist."""
    files = [f for f in files if not f.startswith("http://")]
    files = [f for f in files if not f.startswith("https://")]
    missing_files = [file for file in files if not os.path.exists(file)]
    return missing_files


def translate_patch(
    inf: BinaryIO,
    pages: Optional[List[int]] = None,
    vfont: str = "",
    vchar: str = "",
    thread: int = 0,
    doc_zh: Document = None,
    lang_in: str = "",
    lang_out: str = "",
    service: str = "",
    noto_name: str = "",
    noto: Font = None,
    callback: object = None,
    cancellation_event: asyncio.Event = None,
    model: OnnxModel = None,
    envs: Dict = None,
    prompt: Template = None,
    llm_client=None,
    **kwarg: Any,
) -> Dict:
    """Process PDF pages and generate translation patches."""
    rsrcmgr = PDFResourceManager()
    layout = {}
    device = TranslateConverter(
        rsrcmgr,
        vfont,
        vchar,
        thread,
        layout,
        lang_in,
        lang_out,
        service,
        noto_name,
        noto,
        envs,
        prompt,
        llm_client=llm_client,
    )

    obj_patch = {}
    interpreter = PDFPageInterpreterEx(rsrcmgr, device, obj_patch)

    if pages:
        total_pages = len(pages)
    else:
        total_pages = doc_zh.page_count

    parser = PDFParser(inf)
    doc = PDFDocument(parser)

    with tqdm.tqdm(total=total_pages) as progress:
        for pageno, page in enumerate(PDFPage.create_pages(doc)):
            if cancellation_event and cancellation_event.is_set():
                raise CancelledError("task cancelled")

            if pages and (pageno not in pages):
                continue

            progress.update()
            if callback:
                callback(progress)

            page.pageno = pageno
            pix = doc_zh[page.pageno].get_pixmap()
            image = np.frombuffer(pix.samples, np.uint8).reshape(
                pix.height, pix.width, 3
            )[:, :, ::-1]

            page_layout = model.predict(image, imgsz=int(pix.height / 32) * 32)[0]

            # Create layout mask
            box = np.ones((pix.height, pix.width))
            h, w = box.shape
            vcls = ["abandon", "figure", "table", "isolate_formula", "formula_caption"]

            for i, d in enumerate(page_layout.boxes):
                if page_layout.names[int(d.cls)] not in vcls:
                    x0, y0, x1, y1 = d.xyxy.squeeze()
                    x0, y0, x1, y1 = (
                        np.clip(int(x0 - 1), 0, w - 1),
                        np.clip(int(h - y1 - 1), 0, h - 1),
                        np.clip(int(x1 + 1), 0, w - 1),
                        np.clip(int(h - y0 + 1), 0, h - 1),
                    )
                    box[y0:y1, x0:x1] = i + 2

            for i, d in enumerate(page_layout.boxes):
                if page_layout.names[int(d.cls)] in vcls:
                    x0, y0, x1, y1 = d.xyxy.squeeze()
                    x0, y0, x1, y1 = (
                        np.clip(int(x0 - 1), 0, w - 1),
                        np.clip(int(h - y1 - 1), 0, h - 1),
                        np.clip(int(x1 + 1), 0, w - 1),
                        np.clip(int(h - y0 + 1), 0, h - 1),
                    )
                    box[y0:y1, x0:x1] = 0

            layout[page.pageno] = box

            # Create new xref for page
            page.page_xref = doc_zh.get_new_xref()
            doc_zh.update_object(page.page_xref, "<<>>")
            doc_zh.update_stream(page.page_xref, b"")
            doc_zh[page.pageno].set_contents(page.page_xref)
            interpreter.process_page(page)

    device.close()
    return obj_patch


def translate_stream(
    stream: bytes,
    pages: Optional[List[int]] = None,
    lang_in: str = "",
    lang_out: str = "",
    service: str = "",
    thread: int = 0,
    vfont: str = "",
    vchar: str = "",
    callback: object = None,
    cancellation_event: asyncio.Event = None,
    model: OnnxModel = None,
    envs: Dict = None,
    prompt: Template = None,
    skip_subset_fonts: bool = False,
    llm_client=None,
    fonts_dir: Optional[str] = None,
    **kwarg: Any,
):
    """Translate a PDF stream."""
    font_list = [("tiro", None)]

    font_path = download_remote_fonts(lang_out.lower(), fonts_dir=fonts_dir)
    noto_name = NOTO_NAME
    noto = Font(noto_name, font_path)
    font_list.append((noto_name, font_path))

    doc_en = Document(stream=stream)
    stream_io = io.BytesIO()
    doc_en.save(stream_io)
    stream_io.seek(0)
    doc_zh = Document(stream=stream_io)
    page_count = doc_zh.page_count

    font_id = {}
    for page in doc_zh:
        for font in font_list:
            font_id[font[0]] = page.insert_font(font[0], font[1])

    xreflen = doc_zh.xref_length()
    for xref in range(1, xreflen):
        for label in ["Resources/", ""]:
            try:
                font_res = doc_zh.xref_get_key(xref, f"{label}Font")
                target_key_prefix = f"{label}Font/"

                if font_res[0] == "xref":
                    resource_xref_id = re.search(r"(\d+) 0 R", font_res[1]).group(1)
                    xref = int(resource_xref_id)
                    font_res = ("dict", doc_zh.xref_object(xref))
                    target_key_prefix = ""

                if font_res[0] == "dict":
                    for font in font_list:
                        target_key = f"{target_key_prefix}{font[0]}"
                        font_exist = doc_zh.xref_get_key(xref, target_key)
                        if font_exist[0] == "null":
                            doc_zh.xref_set_key(
                                xref,
                                target_key,
                                f"{font_id[font[0]]} 0 R",
                            )
            except Exception:
                pass

    fp = io.BytesIO()
    doc_zh.save(fp)

    obj_patch: dict = translate_patch(fp, **locals())

    for obj_id, ops_new in obj_patch.items():
        doc_zh.update_stream(obj_id, ops_new.encode())

    doc_en.insert_file(doc_zh)
    for id in range(page_count):
        doc_en.move_page(page_count + id, id * 2 + 1)

    if not skip_subset_fonts:
        try:
            doc_zh.subset_fonts(fallback=True)
            doc_en.subset_fonts(fallback=True)
        except Exception:
            pass

    return (
        doc_zh.write(deflate=True, garbage=3, use_objstms=1),
        doc_en.write(deflate=True, garbage=3, use_objstms=1),
    )


def convert_to_pdfa(input_path: str, output_path: str) -> None:
    """Convert PDF to PDF/A format."""
    from pikepdf import Dictionary, Name, Pdf

    pdf = Pdf.open(input_path)

    metadata = {
        "pdfa_part": "2",
        "pdfa_conformance": "B",
        "title": pdf.docinfo.get("/Title", ""),
        "author": pdf.docinfo.get("/Author", ""),
        "creator": "Translate Module",
    }

    with pdf.open_metadata() as meta:
        meta.load_from_docinfo(pdf.docinfo)
        meta["pdfaid:part"] = metadata["pdfa_part"]
        meta["pdfaid:conformance"] = metadata["pdfa_conformance"]

    output_intent = Dictionary({
        "/Type": Name("/OutputIntent"),
        "/S": Name("/GTS_PDFA1"),
        "/OutputConditionIdentifier": "sRGB IEC61966-2.1",
        "/RegistryName": "http://www.color.org",
        "/Info": "sRGB IEC61966-2.1",
    })

    if "/OutputIntents" not in pdf.Root:
        pdf.Root.OutputIntents = [output_intent]
    else:
        pdf.Root.OutputIntents.append(output_intent)

    pdf.save(output_path, linearize=True)
    pdf.close()


def translate(
    files: List[str],
    output: str = "",
    pages: Optional[List[int]] = None,
    lang_in: str = "",
    lang_out: str = "",
    service: str = "",
    thread: int = 0,
    vfont: str = "",
    vchar: str = "",
    callback: object = None,
    compatible: bool = True,
    cancellation_event: asyncio.Event = None,
    model: OnnxModel = None,
    envs: Dict = None,
    prompt: Template = None,
    skip_subset_fonts: bool = True,
    llm_client=None,
    fonts_dir: Optional[str] = None,
    **kwarg: Any,
) -> List[tuple]:
    """
    Translate PDF files.

    Args:
        files: List of PDF file paths to translate
        output: Output directory
        pages: Optional list of page numbers (0-indexed)
        lang_in: Source language code
        lang_out: Target language code
        service: Translation service name
        thread: Number of threads
        vfont: Custom formula font pattern
        vchar: Custom formula character pattern
        callback: Progress callback
        compatible: Whether to convert to PDF/A first
        cancellation_event: Event for cancellation
        model: Document layout model
        envs: Environment variables
        prompt: Prompt template
        skip_subset_fonts: Whether to skip font subsetting
        llm_client: LLM client for translation
        fonts_dir: Directory containing fonts

    Returns:
        List of (mono_path, dual_path) tuples
    """
    if not files:
        raise PDFValueError("No files to process.")

    missing_files = check_files(files)
    if missing_files:
        raise PDFValueError(f"Files do not exist: {missing_files}")

    result_files = []

    for file in files:
        filename = os.path.splitext(os.path.basename(file))[0]

        # Convert to PDF/A if compatible mode
        if compatible:
            with tempfile.NamedTemporaryFile(suffix="-pdfa.pdf", delete=False) as tmp_pdfa:
                convert_to_pdfa(file, tmp_pdfa.name)
                with open(tmp_pdfa.name, "rb") as doc_raw:
                    s_raw = doc_raw.read()
                os.unlink(tmp_pdfa.name)
        else:
            with open(file, "rb") as doc_raw:
                s_raw = doc_raw.read()

        if not s_raw:
            raise RuntimeError(f"Failed to read input file: {file}")

        # Clean up temp file if needed
        temp_dir = Path(tempfile.gettempdir())
        file_path = Path(file)
        try:
            if file_path.exists() and file_path.resolve().is_relative_to(temp_dir.resolve()):
                file_path.unlink(missing_ok=True)
        except Exception:
            pass

        s_mono, s_dual = translate_stream(
            s_raw,
            pages=pages,
            lang_in=lang_in,
            lang_out=lang_out,
            service=service,
            thread=thread,
            vfont=vfont,
            vchar=vchar,
            callback=callback,
            cancellation_event=cancellation_event,
            model=model,
            envs=envs,
            prompt=prompt,
            skip_subset_fonts=skip_subset_fonts,
            llm_client=llm_client,
            fonts_dir=fonts_dir,
        )

        file_mono = Path(output) / f"{filename}-mono.pdf"
        file_dual = Path(output) / f"{filename}-dual.pdf"

        # Use atomic writes - write to temp files first, then rename
        # This prevents corruption if the process crashes during write
        temp_mono = None
        temp_dual = None

        try:
            # Write mono PDF atomically
            temp_mono_fd, temp_mono = tempfile.mkstemp(suffix='.pdf', dir=output)
            os.close(temp_mono_fd)
            with open(temp_mono, "wb") as doc_mono:
                doc_mono.write(s_mono)

            # Write dual PDF atomically
            temp_dual_fd, temp_dual = tempfile.mkstemp(suffix='.pdf', dir=output)
            os.close(temp_dual_fd)
            with open(temp_dual, "wb") as doc_dual:
                doc_dual.write(s_dual)

            # Atomic renames - both succeed or neither does
            if file_mono.exists():
                file_mono.unlink()
            os.rename(temp_mono, file_mono)
            temp_mono = None  # Clear so cleanup doesn't delete

            if file_dual.exists():
                file_dual.unlink()
            os.rename(temp_dual, file_dual)
            temp_dual = None  # Clear so cleanup doesn't delete

        except Exception as e:
            # Clean up temp files on error
            if temp_mono and os.path.exists(temp_mono):
                try:
                    os.remove(temp_mono)
                except Exception:
                    pass
            if temp_dual and os.path.exists(temp_dual):
                try:
                    os.remove(temp_dual)
                except Exception:
                    pass
            raise RuntimeError(f"Failed to save translated PDF: {e}")

        result_files.append((str(file_mono), str(file_dual)))

    return result_files


def download_remote_fonts(lang: str, fonts_dir: Optional[str] = None) -> str:
    """
    Get font path for a language.

    Args:
        lang: Language code (empty string or "auto" will use default multilingual font)
        fonts_dir: Optional directory containing fonts

    Returns:
        Path to the font file
    """
    lang = lang.lower() if lang else ""

    # Language to font mapping (primary and fallback names)
    LANG_FONT_MAP = {
        # Auto/Unknown - use GoNotoKurrent which supports many languages
        "": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "auto": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        # Latin-based languages - Noto Sans
        "en": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "english": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "vi": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "vietnamese": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "fil": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        "filipino": ["GoNotoKurrent-Regular.ttf", "NotoSans-Regular.ttf"],
        # Thai - NotoSansThai
        "th": ["NotoSansThai-Regular.ttf", "GoNotoKurrent-Regular.ttf"],
        "thai": ["NotoSansThai-Regular.ttf", "GoNotoKurrent-Regular.ttf"],
        # Korean - Source Han Serif
        "ko": ["SourceHanSerifKR-Regular.otf", "SourceHanSerifK-Regular.otf"],
        "korean": ["SourceHanSerifKR-Regular.otf", "SourceHanSerifK-Regular.otf"],
        # Chinese - Source Han Serif
        "zh-cn": ["SourceHanSerifCN-Regular.otf", "SourceHanSerifSC-Regular.otf"],
        "zh": ["SourceHanSerifCN-Regular.otf", "SourceHanSerifSC-Regular.otf"],
        "chinese": ["SourceHanSerifCN-Regular.otf", "SourceHanSerifSC-Regular.otf"],
    }

    font_names = LANG_FONT_MAP.get(lang, ["GoNotoKurrent-Regular.ttf"])

    # Try configured fonts directory first
    if fonts_dir:
        p = Path(fonts_dir)
        if p.is_dir():
            for font_name in font_names:
                candidate = p / font_name
                if candidate.exists():
                    return candidate.as_posix()

    # Try package assets directory (relative to this file)
    package_fonts_dir = Path(__file__).parent.parent.parent / "assets" / "fonts"
    if package_fonts_dir.is_dir():
        for font_name in font_names:
            candidate = package_fonts_dir / font_name
            if candidate.exists():
                return candidate.as_posix()

    # Try babeldoc library as fallback
    try:
        from babeldoc.assets.assets import get_font_and_metadata
        font_path, _ = get_font_and_metadata(font_names[0])
        return font_path.as_posix()
    except ImportError:
        pass

    raise FileNotFoundError(
        f"Could not find font {font_names[0]} for language '{lang}'. "
        f"Please provide fonts_dir or place fonts in {package_fonts_dir}"
    )

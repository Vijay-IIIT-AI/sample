"""
Document layout detection using ONNX model.

Provides YOLO-based document layout detection for identifying
text regions, figures, tables, and formulas in PDF pages.
"""

import abc
import ast
import os
from typing import List, Optional

import cv2
import numpy as np

try:
    import onnx
    import onnxruntime
except ImportError as e:
    if "DLL load failed" in str(e):
        raise OSError(
            "Microsoft Visual C++ Redistributable is not installed. "
            "Download it at https://aka.ms/vs/17/release/vc_redist.x64.exe"
        ) from e
    raise


class DocLayoutModel(abc.ABC):
    """Abstract base class for document layout models."""

    @staticmethod
    def load_onnx(models_dir: Optional[str] = None) -> "OnnxModel":
        """Load an ONNX model for document layout detection."""
        return OnnxModel.from_pretrained(models_dir=models_dir)

    @staticmethod
    def load_available(models_dir: Optional[str] = None) -> "OnnxModel":
        """Load the best available model."""
        return DocLayoutModel.load_onnx(models_dir=models_dir)

    @property
    @abc.abstractmethod
    def stride(self) -> int:
        """Stride of the model input."""
        pass

    @abc.abstractmethod
    def predict(self, image, imgsz: int = 1024, **kwargs) -> List:
        """
        Predict the layout of a document page.

        Args:
            image: The image of the document page.
            imgsz: Resize the image to this size. Must be a multiple of the stride.
            **kwargs: Additional arguments.

        Returns:
            List of YoloResult objects.
        """
        pass


class YoloResult:
    """Helper class to store detection results from ONNX model."""

    def __init__(self, boxes, names):
        self.boxes = [YoloBox(data=d) for d in boxes]
        self.boxes.sort(key=lambda x: x.conf, reverse=True)
        self.names = names


class YoloBox:
    """Helper class to store detection box from ONNX model."""

    def __init__(self, data):
        self.xyxy = data[:4]
        self.conf = data[-2]
        self.cls = data[-1]


class OnnxModel(DocLayoutModel):
    """ONNX-based document layout detection model."""

    def __init__(self, model_path: str):
        """
        Initialize the ONNX model.

        Args:
            model_path: Path to the ONNX model file.
        """
        self.model_path = model_path

        model = onnx.load(model_path)
        metadata = {d.key: d.value for d in model.metadata_props}
        self._stride = ast.literal_eval(metadata["stride"])
        self._names = ast.literal_eval(metadata["names"])

        self.model = onnxruntime.InferenceSession(model.SerializeToString())

    @staticmethod
    def from_pretrained(models_dir: Optional[str] = None) -> "OnnxModel":
        """
        Load a pretrained ONNX model.

        Args:
            models_dir: Optional directory containing the ONNX model.

        Returns:
            OnnxModel instance.
        """
        from pathlib import Path

        # Try configured models directory first
        if models_dir and os.path.isdir(models_dir):
            for name in os.listdir(models_dir):
                if name.lower().endswith(".onnx"):
                    return OnnxModel(os.path.join(models_dir, name))

        # Try package assets directory (relative to this file)
        package_models_dir = Path(__file__).parent.parent.parent / "assets" / "models"
        if package_models_dir.is_dir():
            for name in os.listdir(package_models_dir):
                if name.lower().endswith(".onnx"):
                    return OnnxModel(str(package_models_dir / name))

        # Fallback to babeldoc library
        try:
            from babeldoc.assets.assets import get_doclayout_onnx_model_path
            pth = get_doclayout_onnx_model_path()
            return OnnxModel(pth)
        except ImportError:
            raise FileNotFoundError(
                f"Could not find ONNX model. Please provide models_dir or place model in {package_models_dir}"
            )

    @property
    def stride(self) -> int:
        """Get the model stride."""
        return self._stride

    def resize_and_pad_image(self, image, new_shape):
        """
        Resize and pad the image to the specified size.

        Parameters:
            image: Input image
            new_shape: Target size (integer or (height, width) tuple)

        Returns:
            Processed image
        """
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        h, w = image.shape[:2]
        new_h, new_w = new_shape

        # Calculate scaling ratio
        r = min(new_h / h, new_w / w)
        resized_h, resized_w = int(round(h * r)), int(round(w * r))

        # Resize image
        image = cv2.resize(
            image, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR
        )

        # Calculate padding size and align to stride multiple
        pad_w = (new_w - resized_w) % self.stride
        pad_h = (new_h - resized_h) % self.stride
        top, bottom = pad_h // 2, pad_h - pad_h // 2
        left, right = pad_w // 2, pad_w - pad_w // 2

        # Add padding
        image = cv2.copyMakeBorder(
            image, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114)
        )

        return image

    def scale_boxes(self, img1_shape, boxes, img0_shape):
        """
        Rescale bounding boxes from img1 shape to img0 shape.

        Args:
            img1_shape: Shape of the image boxes are from (height, width).
            boxes: Bounding boxes in format (x1, y1, x2, y2).
            img0_shape: Target image shape (height, width).

        Returns:
            Scaled bounding boxes.
        """
        # Calculate scaling ratio
        gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])

        # Calculate padding size
        pad_x = round((img1_shape[1] - img0_shape[1] * gain) / 2 - 0.1)
        pad_y = round((img1_shape[0] - img0_shape[0] * gain) / 2 - 0.1)

        # Remove padding and scale boxes
        boxes[..., :4] = (boxes[..., :4] - [pad_x, pad_y, pad_x, pad_y]) / gain
        return boxes

    def predict(self, image, imgsz: int = 1024, **kwargs) -> List[YoloResult]:
        """
        Predict document layout from image.

        Args:
            image: Input image (numpy array).
            imgsz: Target image size for inference.

        Returns:
            List containing a YoloResult with detected boxes.
        """
        # Preprocess input image
        orig_h, orig_w = image.shape[:2]
        pix = self.resize_and_pad_image(image, new_shape=imgsz)
        pix = np.transpose(pix, (2, 0, 1))  # CHW
        pix = np.expand_dims(pix, axis=0)  # BCHW
        pix = pix.astype(np.float32) / 255.0  # Normalize to [0, 1]
        new_h, new_w = pix.shape[2:]

        # Run inference
        preds = self.model.run(None, {"images": pix})[0]

        # Postprocess predictions
        preds = preds[preds[..., 4] > 0.25]
        preds[..., :4] = self.scale_boxes(
            (new_h, new_w), preds[..., :4], (orig_h, orig_w)
        )

        return [YoloResult(boxes=preds, names=self._names)]


class ModelInstance:
    """Singleton holder for model instance."""
    value: Optional[OnnxModel] = None

"""PDF handler module for PDF file translation."""

from .handler import PDFHandler

__all__ = ["PDFHandler"]

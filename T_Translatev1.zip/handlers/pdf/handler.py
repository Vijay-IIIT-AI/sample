"""PDF handler using AI layout detection for layout-preserving translation."""

import os
from typing import List, Optional

from ...config import Language, TranslateConfig, TranslationResult
from .. import register_handler
from ..base import BaseHandler
from . import high_level
from .doclayout import OnnxModel


@register_handler
class PDFHandler(BaseHandler):
    """PDF handler using AI layout detection. Preserves figures, tables, formulas. Outputs mono + dual PDFs."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._model: Optional[OnnxModel] = None

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".pdf"]

    def _get_model(self) -> OnnxModel:
        """Lazy load the ONNX document layout model."""
        if self._model is None:
            models_dir = None
            if self.config and self.config.models_dir:
                models_dir = self.config.models_dir
            self._model = OnnxModel.from_pretrained(models_dir=models_dir)
        return self._model

    def translate(
        self,
        input_path: str,
        output_path: str,
        pages: Optional[List[int]] = None,
        thread: int = 4,
        compatible: bool = True,
        skip_subset_fonts: bool = True,
    ) -> TranslationResult:
        """
        Translate a PDF file.

        Args:
            input_path: Path to the input PDF file
            output_path: Path for the output PDF file (mono version)
            pages: Optional list of page numbers to translate (1-indexed)
            thread: Number of threads for parallel translation
            compatible: Whether to convert to PDF/A format first
            skip_subset_fonts: Whether to skip font subsetting

        Returns:
            TranslationResult with success status
        """
        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Determine output directory
            output_dir = os.path.dirname(output_path) or "."
            os.makedirs(output_dir, exist_ok=True)

            # Convert 1-indexed pages to 0-indexed
            pages_0indexed = None
            if pages:
                pages_0indexed = [p - 1 for p in pages]

            # Get fonts directory from config
            fonts_dir = None
            if self.config and self.config.fonts_dir:
                fonts_dir = self.config.fonts_dir

            # Load model
            model = self._get_model()

            # Get language codes
            # For AUTO source language, we pass empty string and let LLM auto-detect
            lang_in = "" if self.source_lang.is_auto else self.source_lang.code
            lang_out = self.target_lang.code

            # Perform translation
            result_files = high_level.translate(
                files=[input_path],
                output=output_dir,
                pages=pages_0indexed,
                lang_in=lang_in,
                lang_out=lang_out,
                service="custom",
                thread=thread,
                compatible=compatible,
                model=model,
                llm_client=self.llm_client,
                fonts_dir=fonts_dir,
                skip_subset_fonts=skip_subset_fonts,
            )

            if result_files:
                mono_path, dual_path = result_files[0]
                return TranslationResult.success_result(
                    input_path=input_path,
                    output_path=mono_path,
                    source_lang=self.source_lang,
                    target_lang=self.target_lang,
                    stats={
                        "mono_pdf": mono_path,
                        "dual_pdf": dual_path,
                    },
                )
            else:
                return TranslationResult.failure_result(
                    "No output files generated",
                    input_path=input_path,
                    output_path=output_path,
                )

        except Exception as e:
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

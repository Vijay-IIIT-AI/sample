"""HTML handler with placeholder-based inline tag preservation."""

import html
import logging
import os
import re
import tempfile
from typing import List, Optional, Set, Tuple, Dict, Any

from bs4 import BeautifulSoup, NavigableString, Comment, Doctype, CData
from bs4.element import Tag

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


@register_handler
class HTMLHandler(BaseHandler):
    """HTML handler with inline tag preservation via placeholders. Skips scripts, styles, code blocks."""

    # Tags whose content should NOT be translated
    SKIP_TAGS: Set[str] = frozenset({
        'script', 'style', 'code', 'pre', 'kbd', 'samp', 'var',
        'svg', 'math', 'canvas', 'noscript', 'template',
        'textarea', 'input', 'select', 'option', 'button',
        'iframe', 'object', 'embed', 'applet',
        '[document]',
    })

    # Inline tags that should be preserved with placeholders
    INLINE_TAGS: Set[str] = frozenset({
        'a', 'abbr', 'acronym', 'b', 'bdo', 'big', 'br', 'cite',
        'code', 'dfn', 'em', 'font', 'i', 'img', 'kbd', 'label',
        'mark', 'q', 's', 'samp', 'small', 'span', 'strike',
        'strong', 'sub', 'sup', 'tt', 'u', 'var', 'wbr',
    })

    # Block-level tags to translate together
    BLOCK_TAGS: Set[str] = frozenset({
        'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'li', 'td', 'th', 'dt', 'dd',
        'figcaption', 'caption', 'blockquote', 'label',
        'div', 'section', 'article', 'aside', 'nav',
        'main', 'header', 'footer', 'address',
    })

    # Attributes that should be translated
    TRANSLATABLE_ATTRIBUTES: Set[str] = frozenset({
        'alt', 'title', 'placeholder', 'aria-label', 'aria-description',
        'aria-placeholder', 'aria-valuetext', 'label', 'summary', 'abbr',
    })

    # Attribute values that should NOT be translated
    SKIP_ATTR_PATTERNS = [
        re.compile(r'^https?://'),
        re.compile(r'^mailto:'),
        re.compile(r'^tel:'),
        re.compile(r'^data:'),
        re.compile(r'^javascript:'),
        re.compile(r'^#'),
        re.compile(r'^\d+$'),
    ]

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".html", ".htm"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 20,
        translate_attributes: bool = True,
        parser: str = "html.parser",
        progress_callback: Optional[callable] = None,
    ) -> TranslationResult:
        """
        Translate an HTML file preserving all formatting.

        Args:
            input_path: Path to the input HTML file
            output_path: Path for the output HTML file
            chunk_size: Number of text items per translation batch
            translate_attributes: Whether to translate alt, title, etc.
            parser: BeautifulSoup parser
            progress_callback: Optional callback(current, total, message)

        Returns:
            TranslationResult with success status
        """
        stats = {
            "total_blocks": 0,
            "translated_blocks": 0,
            "total_attributes": 0,
            "translated_attributes": 0,
            "skipped": 0,
            "errors": 0,
        }

        try:
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Read file
            html_content, encoding = self._read_html_file(input_path)
            if html_content is None:
                return TranslationResult.failure_result(
                    "Failed to read HTML file",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Parse HTML
            try:
                soup = BeautifulSoup(html_content, parser)
            except Exception as e:
                logger.warning(f"Parser {parser} failed: {e}")
                soup = BeautifulSoup(html_content, "html.parser")

            # Translate blocks with inline formatting preservation
            self._translate_with_placeholders(soup, chunk_size, progress_callback, stats)

            # Translate attributes
            if translate_attributes:
                self._translate_attributes(soup, chunk_size, stats)

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write - prevents corruption on crash
            temp_fd, temp_path = tempfile.mkstemp(suffix='.html', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                # Write to temp file first
                with open(temp_path, "w", encoding="utf-8") as f:
                    f.write(str(soup))

                # Atomic rename - either succeeds completely or fails
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)

            except Exception as e:
                # Clean up temp file on error
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats=stats,
            )

        except Exception as e:
            logger.exception(f"HTML translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def _read_html_file(self, file_path: str) -> Tuple[Optional[str], str]:
        """Read HTML file with encoding detection."""
        encodings = ['utf-8', 'utf-8-sig', 'utf-16', 'latin-1', 'cp1252', 'iso-8859-1']

        for encoding in encodings:
            try:
                with open(file_path, "r", encoding=encoding) as f:
                    content = f.read()
                return content, encoding
            except (UnicodeDecodeError, UnicodeError):
                continue

        return None, 'utf-8'

    def _should_skip_element(self, element) -> bool:
        """Check if element should be skipped."""
        if element is None:
            return True

        if isinstance(element, (Comment, Doctype, CData)):
            return True

        for parent in element.parents:
            if parent.name and parent.name.lower() in self.SKIP_TAGS:
                return True

        return False

    def _is_translatable_text(self, text: str) -> bool:
        """Check if text should be translated."""
        if not text:
            return False

        stripped = text.strip()
        if not stripped or len(stripped) < 2:
            return False

        # Check for actual text content (any language)
        # Allow CJK, Korean, Arabic, Hebrew, etc.
        if re.match(r'^[\s\d\W]*$', stripped):
            # Check if it contains any letter from any language
            if not re.search(r'[\w\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff'
                           r'\uac00-\ud7af\u0600-\u06ff\u0590-\u05ff]', stripped):
                return False

        return should_translate(stripped)

    def _extract_with_placeholders(self, element: Tag) -> Tuple[str, Dict[str, Tag]]:
        """
        Extract text from element, replacing inline tags with placeholders.

        Example:
            <p>Hello <b>world</b> today</p>
            →
            text: "Hello <PH_0>world</PH_0> today"
            placeholders: {"PH_0": <b> tag}
        """
        placeholders = {}
        placeholder_counter = [0]

        def process_node(node) -> str:
            if isinstance(node, NavigableString):
                if isinstance(node, (Comment, CData)):
                    return ''
                return html.unescape(str(node))

            elif isinstance(node, Tag):
                tag_name = node.name.lower() if node.name else ''

                # Skip tags - return empty
                if tag_name in self.SKIP_TAGS:
                    return ''

                # Inline tags - use placeholders
                if tag_name in self.INLINE_TAGS:
                    ph_id = f"PH_{placeholder_counter[0]}"
                    placeholder_counter[0] += 1
                    placeholders[ph_id] = node

                    # Get inner content
                    inner = ''.join(process_node(child) for child in node.children)

                    # Self-closing tags (br, img, etc.)
                    if not inner and tag_name in {'br', 'hr', 'img', 'wbr'}:
                        return f"<{ph_id}/>"

                    return f"<{ph_id}>{inner}</{ph_id}>"

                # Other tags - just process children
                return ''.join(process_node(child) for child in node.children)

            return ''

        text = ''.join(process_node(child) for child in element.children)
        return text, placeholders

    def _restore_placeholders(
        self,
        translated_text: str,
        placeholders: Dict[str, Tag],
        soup: BeautifulSoup,
    ) -> List:
        """
        Restore original inline tags from placeholders in translated text.

        Returns list of NavigableString and Tag objects.
        """
        result = []
        current_pos = 0

        # Pattern to match placeholders: <PH_N>, </PH_N>, <PH_N/> (case insensitive)
        pattern = re.compile(r'<(/?)(PH_\d+)(/?)>', re.IGNORECASE)

        for match in pattern.finditer(translated_text):
            # Add text before placeholder
            if match.start() > current_pos:
                text_before = translated_text[current_pos:match.start()]
                if text_before:
                    result.append(NavigableString(text_before))

            is_closing = match.group(1) == '/'
            ph_id = match.group(2)
            is_self_closing = match.group(3) == '/'

            # Normalize placeholder ID to uppercase for matching
            ph_id_upper = ph_id.upper()
            if ph_id_upper in placeholders:
                original_tag = placeholders[ph_id_upper]

                if is_self_closing:
                    # Self-closing placeholder - create copy of original tag
                    new_tag = soup.new_tag(original_tag.name, **original_tag.attrs)
                    result.append(new_tag)
                elif not is_closing:
                    # Opening tag - will be matched with content and closing tag
                    # Find matching closing tag (case insensitive)
                    close_pattern_upper = f"</{ph_id_upper}>"
                    close_pattern_lower = f"</{ph_id.lower()}>"
                    close_pattern_orig = f"</{ph_id}>"

                    # Try all case variants
                    close_pos = -1
                    close_len = 0
                    for cp in [close_pattern_orig, close_pattern_upper, close_pattern_lower]:
                        pos = translated_text.lower().find(cp.lower(), match.end())
                        if pos != -1:
                            close_pos = pos
                            close_len = len(cp)
                            break

                    if close_pos != -1:
                        # Extract inner content
                        inner_text = translated_text[match.end():close_pos]

                        # Create new tag with original attributes
                        new_tag = soup.new_tag(original_tag.name, **original_tag.attrs)

                        # Recursively process inner content
                        inner_nodes = self._restore_placeholders(inner_text, placeholders, soup)
                        for node in inner_nodes:
                            new_tag.append(node)

                        result.append(new_tag)

                        # Skip past closing tag
                        current_pos = close_pos + close_len
                        continue

            current_pos = match.end()

        # Add remaining text
        if current_pos < len(translated_text):
            remaining = translated_text[current_pos:]
            if remaining:
                result.append(NavigableString(remaining))

        return result

    def _translate_with_placeholders(
        self,
        soup: BeautifulSoup,
        chunk_size: int,
        progress_callback: Optional[callable],
        stats: dict,
    ) -> None:
        """
        Translate HTML using placeholder-based inline tag preservation.
        """
        processed_elements = set()
        blocks_to_translate = []

        # Find all block-level elements
        for tag_name in self.BLOCK_TAGS:
            for element in soup.find_all(tag_name):
                if id(element) in processed_elements:
                    continue

                if self._should_skip_element(element):
                    stats["skipped"] += 1
                    continue

                # Check for nested block elements - skip if this contains other blocks
                has_nested_blocks = any(
                    child.name and child.name.lower() in self.BLOCK_TAGS
                    for child in element.find_all(True)
                )

                if has_nested_blocks:
                    # Will process child blocks instead
                    continue

                # Extract text with placeholders
                text_with_ph, placeholders = self._extract_with_placeholders(element)

                # Check if there's translatable content
                text_only = re.sub(r'</?PH_\d+/?>', '', text_with_ph)
                if text_only.strip() and self._is_translatable_text(text_only):
                    blocks_to_translate.append({
                        'element': element,
                        'text': text_with_ph.strip(),
                        'placeholders': placeholders,
                    })
                    processed_elements.add(id(element))
                    stats["total_blocks"] += 1
                else:
                    stats["skipped"] += 1

        # Also handle orphan text nodes not in blocks
        for text_node in soup.find_all(string=True):
            if isinstance(text_node, (Comment, CData, Doctype)):
                continue

            parent = text_node.parent
            if parent and id(parent) in processed_elements:
                continue

            if self._should_skip_element(text_node):
                continue

            # Check if parent is a block we already processed
            parent_is_block = parent and parent.name and parent.name.lower() in self.BLOCK_TAGS
            if parent_is_block and id(parent) in processed_elements:
                continue

            text = str(text_node)
            if self._is_translatable_text(text):
                blocks_to_translate.append({
                    'element': text_node,
                    'text': html.unescape(text.strip()),
                    'placeholders': {},
                    'is_text_node': True,
                })
                stats["total_blocks"] += 1

        # Translate all blocks
        if blocks_to_translate:
            texts = [b['text'] for b in blocks_to_translate]
            translated_texts = self._translate_in_chunks(texts, chunk_size, progress_callback, stats)

            # Verify alignment
            if len(translated_texts) != len(blocks_to_translate):
                logger.warning(
                    f"Translation count mismatch: expected {len(blocks_to_translate)}, "
                    f"got {len(translated_texts)}. Using originals for unmatched."
                )
                # Pad with originals
                while len(translated_texts) < len(blocks_to_translate):
                    translated_texts.append(blocks_to_translate[len(translated_texts)]['text'])

            # Apply translations
            for block, translated in zip(blocks_to_translate, translated_texts):
                try:
                    if block.get('is_text_node'):
                        # Simple text node
                        original = str(block['element'])
                        leading = self._get_leading_whitespace(original)
                        trailing = self._get_trailing_whitespace(original)
                        block['element'].replace_with(
                            NavigableString(leading + html.escape(translated, quote=False) + trailing)
                        )
                    else:
                        # Block element with placeholders
                        element = block['element']
                        placeholders = block['placeholders']

                        # Restore inline tags from placeholders
                        new_nodes = self._restore_placeholders(translated, placeholders, soup)

                        # Clear element and add new content
                        element.clear()
                        for node in new_nodes:
                            element.append(node)

                    stats["translated_blocks"] += 1

                except Exception as e:
                    logger.debug(f"Error applying translation: {e}")
                    stats["errors"] += 1

    def _translate_attributes(
        self,
        soup: BeautifulSoup,
        chunk_size: int,
        stats: dict,
    ) -> None:
        """Translate attributes, skipping URLs and other non-translatable values."""
        attr_info = []

        for element in soup.find_all(True):
            if self._should_skip_element(element):
                continue

            for attr_name in self.TRANSLATABLE_ATTRIBUTES:
                if element.has_attr(attr_name):
                    attr_value = element.get(attr_name)
                    if isinstance(attr_value, str):
                        # Skip URLs and other patterns
                        should_skip = any(
                            p.match(attr_value) for p in self.SKIP_ATTR_PATTERNS
                        )
                        if not should_skip and self._is_translatable_text(attr_value):
                            attr_info.append((element, attr_name, attr_value.strip()))
                            stats["total_attributes"] += 1

        if attr_info:
            texts = [info[2] for info in attr_info]
            translated = []

            for chunk in chunk_text(texts, chunk_size):
                try:
                    chunk_trans = self._translate_texts(chunk)
                    if len(chunk_trans) != len(chunk):
                        logger.warning("Attribute translation count mismatch")
                        chunk_trans = list(chunk)
                    translated.extend(chunk_trans)
                except Exception as e:
                    logger.warning(f"Attribute translation error: {e}")
                    translated.extend(chunk)

            for (element, attr_name, _), trans_value in zip(attr_info, translated):
                try:
                    element[attr_name] = trans_value
                    stats["translated_attributes"] += 1
                except Exception as e:
                    logger.debug(f"Error setting attribute: {e}")
                    stats["errors"] += 1

    def _translate_in_chunks(
        self,
        texts: List[str],
        chunk_size: int,
        progress_callback: Optional[callable],
        stats: dict,
    ) -> List[str]:
        """Translate texts in chunks with alignment validation."""
        translated = []
        total_chunks = (len(texts) + chunk_size - 1) // chunk_size
        current_chunk = 0

        for chunk in chunk_text(texts, chunk_size):
            current_chunk += 1
            try:
                if progress_callback:
                    progress_callback(current_chunk, total_chunks, f"Chunk {current_chunk}/{total_chunks}")

                chunk_trans = self._translate_texts(chunk)

                # Alignment check
                if len(chunk_trans) != len(chunk):
                    logger.warning(f"Chunk translation mismatch: {len(chunk)} → {len(chunk_trans)}")
                    chunk_trans = list(chunk)
                    stats["errors"] += len(chunk)

                translated.extend(chunk_trans)

            except Exception as e:
                logger.warning(f"Translation error: {e}")
                translated.extend(chunk)
                stats["errors"] += len(chunk)

        return translated

    def _get_leading_whitespace(self, text: str) -> str:
        match = re.match(r'^(\s*)', text)
        return match.group(1) if match else ''

    def _get_trailing_whitespace(self, text: str) -> str:
        match = re.search(r'(\s*)$', text)
        return match.group(1) if match else ''

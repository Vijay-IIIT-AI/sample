"""Markdown handler using AST for lossless translation. Preserves code blocks, links, images."""

import logging
import os
import re
import tempfile
from typing import List, Optional, Tuple

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


@register_handler
class MarkdownHandler(BaseHandler):
    """
    Handler for Markdown (.md, .markdown) files.

    Production-ready with:
    - Complete syntax preservation
    - Robust error handling
    - Memory-efficient processing
    """

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".md", ".markdown"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 20,
        preserve_code_blocks: bool = True,
        progress_callback: Optional[callable] = None,
    ) -> TranslationResult:
        """
        Translate a Markdown file.

        Parses Markdown, preserves syntax elements, translates text content,
        and reconstructs the document.

        Args:
            input_path: Path to the input Markdown file
            output_path: Path for the output Markdown file
            chunk_size: Number of text items per translation batch
            preserve_code_blocks: Whether to preserve code blocks (default True)
            progress_callback: Optional callback(current, total, message)

        Returns:
            TranslationResult with success status
        """
        stats = {
            "total_lines": 0,
            "translated_lines": 0,
            "skipped_lines": 0,
            "error_lines": 0,
        }

        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Read input file with fallback encoding
            content = None
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    with open(input_path, "r", encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue

            if content is None:
                return TranslationResult.failure_result(
                    "Failed to read Markdown file with any encoding",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Translate the content
            translated_content, line_stats = self._translate_markdown_safe(
                content, chunk_size, progress_callback
            )

            stats.update(line_stats)

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write - prevents corruption on crash
            temp_fd, temp_path = tempfile.mkstemp(suffix='.md', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                # Write to temp file first
                with open(temp_path, "w", encoding="utf-8") as f:
                    f.write(translated_content)

                # Atomic rename - either succeeds completely or fails
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)

            except Exception as e:
                # Clean up temp file on error
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats=stats,
            )

        except Exception as e:
            logger.exception(f"Markdown translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def _translate_markdown_safe(
        self,
        content: str,
        chunk_size: int,
        progress_callback: Optional[callable],
    ) -> Tuple[str, dict]:
        """
        Translates a Markdown file losslessly using an Abstract Syntax Tree (AST).
        Requires the `marko` library.
        """
        stats = {
            "total_lines": len(content.splitlines()),
            "translated_lines": 0,
            "skipped_lines": 0,
            "error_lines": 0,
        }
        
        try:
            import marko
            from marko.md_renderer import MarkdownRenderer
            import marko.block as block
            import marko.inline as inline
            
            # If marko plugins like "math" are used in the future, handle them dynamically
            # For now, we manually ignore elements that inherently shouldn't translate
        except ImportError:
            logger.error("AST translation failed: `marko` library is not installed.")
            raise
            
        try:
            parser = marko.Markdown()
            ast = parser.parse(content)

            text_nodes = []
            
            def collect_texts(node):
                if isinstance(node, (block.CodeBlock, block.FencedCode, block.HTMLBlock,
                                     inline.CodeSpan, inline.InlineHTML)):
                    return
                
                # Collect RawText strings
                if isinstance(node, inline.RawText):
                    text_nodes.append((node, "children"))
                
                # Collect titles from links and images
                if isinstance(node, (inline.Link, inline.Image)):
                    if hasattr(node, "title") and isinstance(node.title, str) and node.title:
                        text_nodes.append((node, "title"))
                        
                # Recursively parse children natively preventing empty-child skips
                if hasattr(node, "children"):
                    children = node.children
                    if isinstance(children, list):
                        for child in children:
                            collect_texts(child)
                    elif not isinstance(children, str):
                        collect_texts(children)

            collect_texts(ast)
            
            def is_pure_math(text: str) -> bool:
                """Return True if the text consists entirely of a LaTeX math block."""
                return bool(re.match(r'^\s*\$\$?[\s\S]+?\$\$?\s*$', text))
            
            # Filter nodes once
            filtered_nodes = []
            for node, attr in text_nodes:
                val = getattr(node, attr, "")
                if isinstance(val, str) and str(val).strip():
                    if not is_pure_math(val) and should_translate(val):
                        filtered_nodes.append((node, attr))
                    
            texts_to_translate = [getattr(node, attr) for node, attr in filtered_nodes]
            
            if texts_to_translate:
                translated_texts = []
                total_chunks = (len(texts_to_translate) + chunk_size - 1) // chunk_size
                current_chunk = 0

                for chunk in chunk_text(texts_to_translate, chunk_size):
                    current_chunk += 1
                    if progress_callback:
                        progress_callback(
                            current_chunk, total_chunks,
                            f"Translating chunk {current_chunk}/{total_chunks}"
                        )
                    try:
                        translated_texts.extend(self._translate_texts(chunk))
                        stats["translated_lines"] += len(chunk)
                    except Exception as e:
                        logger.warning(f"Translation error: {e}")
                        translated_texts.extend(chunk)
                        stats["error_lines"] += len(chunk)
                        
                # Overwrite original AST nodes safely mapped one-to-one
                if len(translated_texts) == len(filtered_nodes):
                    for i, (node, attr) in enumerate(filtered_nodes):
                        setattr(node, attr, translated_texts[i])
                else:
                    logger.error(f"Translation length mismatch! Expected {len(filtered_nodes)}, got {len(translated_texts)}. Retaining original text formatting.")
                    # We continue without replacement as a fail-safe

            renderer = MarkdownRenderer()
            result = renderer.render(ast)
            
            return result, stats
            
        except Exception as e:
            logger.exception(f"AST Markdown processing error: {e}")
            return content, stats

"""Base handler abstract class for file type handlers."""

import logging
from abc import ABC, abstractmethod
from typing import List, Optional

from ..config import Language, TranslateConfig, TranslationResult
from ..llm import LLMClient

logger = logging.getLogger(__name__)


class BaseHandler(ABC):
    """Abstract base class for file type handlers."""

    def __init__(
        self,
        llm_client: LLMClient,
        target_lang: Language,
        source_lang: Optional[Language] = None,
        config: Optional[TranslateConfig] = None,
    ):
        self.llm_client = llm_client
        self.source_lang = source_lang if source_lang is not None else Language.AUTO
        self.target_lang = target_lang
        self.config = config

    @abstractmethod
    def translate(self, input_path: str, output_path: str) -> TranslationResult:
        pass

    @classmethod
    @abstractmethod
    def supported_extensions(cls) -> List[str]:
        pass

    def _translate_text(self, text: str) -> str:
        return self.llm_client.translate(text, self.source_lang, self.target_lang)

    def _translate_texts(self, texts: List[str], delay: float = 0.0) -> List[str]:
        """Translate texts with guaranteed same-length output. Falls back to originals on failure."""
        if not texts:
            return []

        try:
            result = self.llm_client.translate_batch(
                texts, self.source_lang, self.target_lang, delay=delay
            )
            if len(result) != len(texts):
                logger.warning(f"Translation mismatch: expected {len(texts)}, got {len(result)}")
                return list(texts)
            return result
        except Exception as e:
            logger.warning(f"Translation batch failed: {e}")
            return list(texts)

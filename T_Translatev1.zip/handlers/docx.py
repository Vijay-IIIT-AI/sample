"""Word document handler with full layout preservation."""

import logging
import os
import tempfile
from typing import List, Tuple

from docx import Document
from docx.text.paragraph import Paragraph

from ..config import TranslationResult
from ..utils.text import chunk_text, should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)


@register_handler
class DocxHandler(BaseHandler):
    """Word handler with full layout preservation (tables, headers, footers, images, styles)."""

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".docx"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 20,
    ) -> TranslationResult:
        """
        Translate a Word document.

        Extracts text from paragraphs and tables, translates in chunks,
        and writes back while preserving formatting.

        Args:
            input_path: Path to the input DOCX file
            output_path: Path for the output DOCX file
            chunk_size: Number of text items per translation chunk

        Returns:
            TranslationResult with success status
        """
        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            # Load document
            doc = Document(input_path)

            # Collect texts and their locations
            texts, locations = self._collect_texts(doc)

            if not texts:
                # No text to translate, just save the file
                doc.save(output_path)
                return TranslationResult.success_result(
                    input_path=input_path,
                    output_path=output_path,
                    source_lang=self.source_lang,
                    target_lang=self.target_lang,
                    stats={"total_texts": 0, "translated_texts": 0},
                )

            # Translate texts in chunks
            translated_texts = []
            for chunk in chunk_text(texts, chunk_size):
                try:
                    chunk_translated = self._translate_texts(chunk)
                    # Validate alignment
                    if len(chunk_translated) != len(chunk):
                        logger.warning(
                            f"Translation count mismatch: expected {len(chunk)}, "
                            f"got {len(chunk_translated)}. Using originals."
                        )
                        chunk_translated = list(chunk)
                    translated_texts.extend(chunk_translated)
                except Exception as e:
                    logger.warning(f"Translation chunk error: {e}")
                    translated_texts.extend(chunk)

            # Write translations back to document
            self._write_translations(doc, translated_texts, locations)

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write
            temp_fd, temp_path = tempfile.mkstemp(suffix='.docx', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                doc.save(temp_path)
                # Atomic rename
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)
            except Exception as e:
                # Clean up temp file on error
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats={
                    "total_texts": len(texts),
                    "translated_texts": len(translated_texts),
                },
            )

        except Exception as e:
            logger.exception(f"DOCX translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def _collect_texts(self, doc: Document) -> Tuple[List[str], List[Paragraph]]:
        """
        Collect all translatable texts from the document.
        
        Uses a recursive generator to ensure nested tables, headers, and body elements
        are thoroughly evaluated for translatable paragraphs.
        
        Args:
            doc: The Document object

        Returns:
            Tuple of (texts list, locations list)
            Each location is a direct reference to the Paragraph object.
        """
        texts = []
        locations = []
        
        def iter_paragraphs(element):
            # Extract immediate paragraphs if the object possesses them
            if hasattr(element, 'paragraphs'):
                for para in element.paragraphs:
                    yield para
            # Traverse nested tables if they exist inside this object
            if hasattr(element, 'tables'):
                for table in element.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            yield from iter_paragraphs(cell)

        # Build list of raw elements to scan
        elements_to_scan = [doc]
        for section in doc.sections:
            try:
                if section.header and section.header.is_linked_to_previous is False:
                    elements_to_scan.append(section.header)
            except Exception:
                pass  # Header not accessible
            try:
                if section.footer and section.footer.is_linked_to_previous is False:
                    elements_to_scan.append(section.footer)
            except Exception:
                pass  # Footer not accessible

        # Collect text and store pure Paragraph object references
        for element in elements_to_scan:
            for paragraph in iter_paragraphs(element):
                text = paragraph.text
                if text.strip() and should_translate(text.strip()):
                    texts.append(text.strip())
                    locations.append(paragraph)

        return texts, locations

    def _write_translations(
        self,
        doc: Document,
        translated_texts: List[str],
        locations: List[Paragraph],
    ) -> None:
        """
        Write translated texts back to the document natively using object references.

        Args:
            doc: The Document object
            translated_texts: List of translated texts
            locations: List of Paragraphs referencing exact elements in the AST
        """
        for text, paragraph in zip(translated_texts, locations):
            try:
                self._replace_paragraph_text(paragraph, text)
            except Exception:
                # Maintain original text safely if the structure somehow rejects assignment
                continue

    def _replace_paragraph_text(self, paragraph: Paragraph, new_text: str) -> None:
        """
        Replace text in a paragraph while preserving formatting.

        Clears all runs except the first, then sets the new text.

        Args:
            paragraph: The paragraph object
            new_text: The new text to set
        """
        if not paragraph.runs:
            # No runs, just set the text directly
            paragraph.text = new_text
            return

        # Preserve first run's formatting
        first_run = paragraph.runs[0]

        # Clear all runs
        for run in paragraph.runs:
            run.text = ""

        # Set new text in first run
        first_run.text = new_text

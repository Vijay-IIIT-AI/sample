"""Text file handler for plain text translation with streaming and atomic writes."""

import logging
import os
import tempfile
from typing import List, Optional

from ..config import TranslationResult
from ..utils.text import should_translate
from . import register_handler
from .base import BaseHandler

logger = logging.getLogger(__name__)

def _detect_encoding(file_path: str) -> str:
    """Detect file encoding by trying multiple encodings."""
    encodings = ['utf-8', 'utf-8-sig', 'utf-16', 'latin-1', 'cp1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                f.read(8192)
            return encoding
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception:
            continue
    return 'utf-8'

@register_handler
class TxtHandler(BaseHandler):
    """Handler for plain text (.txt) files."""

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """Return supported file extensions."""
        return [".txt", ".text"]

    def translate(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 20,
        encoding: Optional[str] = None,
    ) -> TranslationResult:
        """
        Translate a text file using a streaming batch translation approach.

        Groups lines into chunks and translates each chunk as a batch
        for improved performance and minimal memory footprint.
        
        Args:
            input_path: Path to the input text file
            output_path: Path for the output text file
            chunk_size: Number of lines per chunk
            encoding: Optional file encoding

        Returns:
            TranslationResult with success status
        """
        stats = {
            "total_lines": 0,
            "translated_lines": 0,
            "skipped_lines": 0,
            "error_lines": 0,
        }

        try:
            # Validate input file exists
            if not os.path.exists(input_path):
                return TranslationResult.failure_result(
                    f"Input file not found: {input_path}",
                    input_path=input_path,
                    output_path=output_path,
                )

            detected_encoding = encoding or _detect_encoding(input_path)
            logger.info(f"Using encoding: {detected_encoding} for TXT")

            # Ensure output directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            # Use temporary file for atomic write
            temp_fd, temp_path = tempfile.mkstemp(suffix='.txt', dir=output_dir or '.')
            os.close(temp_fd)

            try:
                with open(input_path, "r", encoding=detected_encoding, errors='replace') as infile, \
                     open(temp_path, "w", encoding="utf-8") as outfile:
                     
                    chunk_buffer = []

                    def process_buffer(buffer):
                        if not buffer:
                            return
                        texts_to_translate = []
                        indices = []  # Use list to maintain order
                        for i, line in enumerate(buffer):
                            stripped = line.strip()
                            if stripped and should_translate(stripped):
                                texts_to_translate.append(stripped)
                                indices.append(i)
                            else:
                                stats["skipped_lines"] += 1

                        if texts_to_translate:
                            try:
                                translated = self._translate_texts(texts_to_translate)
                                # Safety check against API length mismatch
                                if len(translated) != len(texts_to_translate):
                                    logger.warning(
                                        f"Translation count mismatch: expected {len(texts_to_translate)}, "
                                        f"got {len(translated)}. Using originals."
                                    )
                                    translated = list(texts_to_translate)

                                # Build index set for O(1) lookup
                                indices_set = set(indices)
                                trans_idx = 0
                                for i, line in enumerate(buffer):
                                    if i in indices_set:
                                        # Preserve original line ending
                                        ending = "\n" if line.endswith("\n") else ""
                                        outfile.write(translated[trans_idx] + ending)
                                        trans_idx += 1
                                        stats["translated_lines"] += 1
                                    else:
                                        outfile.write(line)
                            except Exception as e:
                                logger.warning(f"Translation API error: {e}")
                                # Write original buffer on API fail
                                for line in buffer:
                                    outfile.write(line)
                                stats["error_lines"] += len(texts_to_translate)
                        else:
                            # No translation needed for this buffer
                            for line in buffer:
                                outfile.write(line)
                                
                    # Stream over lines naturally via file iterator
                    for line in infile:
                        stats["total_lines"] += 1
                        chunk_buffer.append(line)
                        if len(chunk_buffer) >= chunk_size:
                            process_buffer(chunk_buffer)
                            chunk_buffer = []
                            
                    # Process remaining trailing lines
                    if chunk_buffer:
                        process_buffer(chunk_buffer)

                # Atomic file operation - prevents corruption on crash
                if os.path.exists(output_path):
                    os.remove(output_path)
                os.rename(temp_path, output_path)
                
            except Exception as e:
                # Cleanup loose temporary file
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise

            return TranslationResult.success_result(
                input_path=input_path,
                output_path=output_path,
                source_lang=self.source_lang,
                target_lang=self.target_lang,
                stats=stats,
            )

        except Exception as e:
            logger.exception(f"TXT translation failed: {e}")
            return TranslationResult.failure_result(
                f"Translation failed: {str(e)}",
                input_path=input_path,
                output_path=output_path,
            )

    def translate_chunked(
        self,
        input_path: str,
        output_path: str,
        chunk_size: int = 20,
    ) -> TranslationResult:
        """
        Translate a text file using chunked batch translation.
        Maintained as an alias wrapper for backward compatibility.
        """
        return self.translate(input_path, output_path, chunk_size=chunk_size)

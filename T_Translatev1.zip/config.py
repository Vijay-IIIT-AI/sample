"""
Configuration module for the translate package.

Contains LLMConfig, TranslateConfig, Language enum, and font mappings.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
import os


class Language(Enum):
    """Supported languages for translation."""

    AUTO = ("auto", "Auto-Detect")
    ENGLISH = ("en", "English")
    KOREAN = ("ko", "Korean")
    CHINESE = ("zh-cn", "Chinese")
    FILIPINO = ("fil", "Filipino")
    THAI = ("th", "Thai")
    VIETNAMESE = ("vi", "Vietnamese")

    def __init__(self, code: str, display_name: str):
        self.code = code
        self.display_name = display_name

    @property
    def is_auto(self) -> bool:
        return self == Language.AUTO

    @classmethod
    def from_code(cls, code: str) -> "Language":
        code_lower = code.lower().strip()
        for lang in cls:
            if lang.code == code_lower:
                return lang
        aliases = {
            "auto": cls.AUTO, "automatic": cls.AUTO, "detect": cls.AUTO,
            "english": cls.ENGLISH, "korean": cls.KOREAN,
            "chinese": cls.CHINESE, "zh": cls.CHINESE, "mandarin": cls.CHINESE,
            "filipino": cls.FILIPINO, "tagalog": cls.FILIPINO,
            "thai": cls.THAI, "vietnamese": cls.VIETNAMESE, "viet": cls.VIETNAMESE,
        }
        if code_lower in aliases:
            return aliases[code_lower]
        raise ValueError(f"Unknown language code: {code}")

    @classmethod
    def from_string(cls, value: str) -> "Language":
        if isinstance(value, Language):
            return value
        return cls.from_code(value)


LANGUAGE_FONTS = {
    Language.AUTO: "GoNotoKurrent-Regular.ttf",
    Language.ENGLISH: "GoNotoKurrent-Regular.ttf",
    Language.KOREAN: "SourceHanSerifKR-Regular.otf",
    Language.CHINESE: "SourceHanSerifCN-Regular.otf",
    Language.VIETNAMESE: "GoNotoKurrent-Regular.ttf",
    Language.FILIPINO: "GoNotoKurrent-Regular.ttf",
    Language.THAI: "NotoSansThai-Regular.ttf",
}


@dataclass
class LLMConfig:
    """Configuration for the LLM client."""

    base_url: str
    api_key: str
    model_name: str
    temperature: float = 0.0
    max_retries: int = 3
    timeout: float = 60.0

    def __post_init__(self):
        # Ensure base_url doesn't have trailing slash
        self.base_url = self.base_url.rstrip("/")


@dataclass
class TranslateConfig:
    """Full configuration for translation operations."""

    llm: LLMConfig
    target_lang: Language
    source_lang: Language = Language.AUTO
    fonts_dir: Optional[str] = None
    models_dir: Optional[str] = None

    def __post_init__(self):
        if isinstance(self.source_lang, str):
            self.source_lang = Language.from_string(self.source_lang)
        if isinstance(self.target_lang, str):
            self.target_lang = Language.from_string(self.target_lang)
        if self.source_lang is None:
            self.source_lang = Language.AUTO

    def get_font_path(self, lang: Optional[Language] = None) -> Optional[str]:
        """Get the font file path for a language."""
        if lang is None:
            lang = self.target_lang

        if self.fonts_dir is None:
            return None

        font_name = LANGUAGE_FONTS.get(lang)
        if font_name is None:
            return None

        font_path = os.path.join(self.fonts_dir, font_name)
        if os.path.exists(font_path):
            return font_path
        return None

    def get_target_font(self) -> str:
        """Get the font filename for the target language."""
        return LANGUAGE_FONTS.get(self.target_lang, "GoNotoKurrent-Regular.ttf")


@dataclass
class TranslationResult:
    """Result of a translation operation."""

    success: bool
    input_path: Optional[str] = None
    output_path: Optional[str] = None
    source_lang: Optional[Language] = None
    target_lang: Optional[Language] = None
    error_message: Optional[str] = None
    translated_text: Optional[str] = None  # For text translations
    stats: dict = field(default_factory=dict)  # Additional statistics

    @classmethod
    def success_result(
        cls,
        input_path: Optional[str] = None,
        output_path: Optional[str] = None,
        source_lang: Optional[Language] = None,
        target_lang: Optional[Language] = None,
        translated_text: Optional[str] = None,
        stats: Optional[dict] = None,
    ) -> "TranslationResult":
        """Create a successful translation result."""
        return cls(
            success=True,
            input_path=input_path,
            output_path=output_path,
            source_lang=source_lang,
            target_lang=target_lang,
            translated_text=translated_text,
            stats=stats or {},
        )

    @classmethod
    def failure_result(
        cls,
        error_message: str,
        input_path: Optional[str] = None,
        output_path: Optional[str] = None,
    ) -> "TranslationResult":
        """Create a failed translation result."""
        return cls(
            success=False,
            input_path=input_path,
            output_path=output_path,
            error_message=error_message,
        )

# ------------------------------------------------------------------------------
# tools.py - Tool implementations for Agent Router
#
# To add a new tool:
#   1. Add metadata in TOOL_METADATA
#   2. Add @staticmethod method below
#   3. Add matching elif branch in ToolExecutor.execute() in engine.py
# ------------------------------------------------------------------------------
from __future__ import annotations

from typing import Any, Dict

from .utils import log


class ToolRegistry:
    """
    Central registry of all available tools for the Code V3 router.
    Each tool is a static method that accepts args dict and returns a string result.
    """

    # ==========================================================================
    # TOOL METADATA - Descriptions for LLM planner
    # ==========================================================================

    TOOL_METADATA: Dict[str, Dict[str, Any]] = {
        "rag_query": {
            "description": "Search the knowledge base for relevant documents. Use for questions about uploaded files, documents, or internal knowledge.",
            "args": {
                "query": {"type": "str", "required": True, "description": "Natural language search query"},
                "file_ids": {"type": "list[str]", "required": False, "description": "Restrict search to specific file IDs"},
                "top_k": {"type": "int", "required": False, "default": 5, "description": "Number of results to return"},
            },
        },
        "calculator": {
            "description": "Evaluate mathematical expressions. Use for arithmetic, calculations, or math problems.",
            "args": {
                "expression": {"type": "str", "required": True, "description": "Math expression (e.g., '125 * 48 + 320')"},
            },
        },
    }

    # ==========================================================================
    # METADATA ACCESSORS
    # ==========================================================================

    @staticmethod
    def get_metadata() -> Dict[str, str]:
        """Get simple tool descriptions for LLM planner."""
        return {
            name: info["description"]
            for name, info in ToolRegistry.TOOL_METADATA.items()
        }

    @staticmethod
    def get_full_metadata() -> Dict[str, Dict[str, Any]]:
        """Get full tool metadata including argument specifications."""
        return ToolRegistry.TOOL_METADATA

    @staticmethod
    def get_tool_args(tool_name: str) -> Dict[str, Any]:
        """Get argument specification for a specific tool."""
        tool_info = ToolRegistry.TOOL_METADATA.get(tool_name, {})
        return tool_info.get("args", {})

    @staticmethod
    def list_tools() -> list:
        """Get list of all available tool names."""
        return list(ToolRegistry.TOOL_METADATA.keys())

    # ==========================================================================
    # TOOL IMPLEMENTATIONS
    # ==========================================================================

    @staticmethod
    def rag_query(args: Dict[str, Any]) -> str:
        """
        RAG retrieval from knowledge base.

        Args:
            query (str): Natural-language question (required)
            file_ids (list[str]): Restrict search to specific files (optional)
            top_k (int): Max chunks to return (default: 5)

        Returns:
            Formatted string with ranked chunks and source metadata
        """
        try:
            args = args or {}
            question = str(args.get("query", "") or "").strip()
            file_ids = args.get("file_ids") or None
            top_k = int(args.get("top_k", 5) or 5)

            log("RAG_QUERY", f"question={question!r}  file_ids={file_ids}  top_k={top_k}")

            if not question:
                return "[RAG] No query provided."

            from .rag_store import retrieve
            results = retrieve(question, file_ids=file_ids, top_k=top_k)

            if not results:
                return "[RAG] No relevant documents found."

            blocks = []
            for r in results:
                header = f"[{r['file_name']}] (chunk {r['chunk_id'].rsplit('_', 2)[-1]}, score {r['score']:.3f})"
                blocks.append(f"{header}\n{r['text']}")

            return "\n\n---\n\n".join(blocks)

        except Exception as e:
            log("RAG_ERROR", f"RAG query failed: {e}")
            return "[RAG] Error processing query."

    @staticmethod
    def calculator(args: Dict[str, Any]) -> str:
        """
        Evaluate mathematical expressions.

        Args:
            expression (str): Math expression (e.g., '125 * 48 + 320')

        Returns:
            Calculation result or error message
        """
        expression = str(args.get("expression", "0"))

        # Validate - only allow safe characters
        allowed = set("0123456789+-*/.() ")
        if not all(c in allowed for c in expression):
            return "[CALCULATOR] Error: Invalid characters in expression."

        try:
            result = eval(expression)
            return f"[CALCULATOR] {expression} = {result}"
        except Exception as e:
            return f"[CALCULATOR] Error: {e}"

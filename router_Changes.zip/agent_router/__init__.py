# ------------------------------------------------------------------------------
# __init__.py - Public API for agent_router package
# ------------------------------------------------------------------------------
"""
agent_router package
====================
Usage (from any file outside the package):

    from agent_router import ChatInput, run_chat, UserContext

The five modules inside the package are:
  config.py    - Config constants, UserContext, prompt builders
  utils.py     - Logging, token helpers, LLM factory, classifiers
  tools.py     - ToolRegistry stubs (replace with real implementations)
  engine.py    - ChatInput, TokenManager, ToolExecutor, run_chat
  rag_store.py - ChromaDB-backed RAG utility functions
"""

from .config import Config, UserContext, DEFAULT_USER_CONTEXT, ToolSystemError
from .utils import log, get_llm, count_tokens, sift_tool_output, trim_history_by_tokens, is_trivial_input, smart_truncate_input, chunk_and_summarize, detect_content_strategy
from .tools import ToolRegistry
from .engine import ChatInput, TokenManager, ToolExecutor, run_chat
from .rag_store import retrieve, get_all_file_ids, get_file_info, embed_and_store, chunk_text, METADATA_PATH, CHROMA_PATH

__all__ = [
    # config
    "Config",
    "UserContext",
    "DEFAULT_USER_CONTEXT",
    "ToolSystemError",
    # utils
    "log",
    "get_llm",
    "count_tokens",
    "sift_tool_output",
    "trim_history_by_tokens",
    "is_trivial_input",
    "smart_truncate_input",
    "chunk_and_summarize",
    "detect_content_strategy",
    # tools
    "ToolRegistry",
    # engine
    "ChatInput",
    "TokenManager",
    "ToolExecutor",
    "run_chat",
    # rag_store
    "retrieve",
    "get_all_file_ids",
    "get_file_info",
    "embed_and_store",
    "chunk_text",
    "METADATA_PATH",
    "CHROMA_PATH",
]

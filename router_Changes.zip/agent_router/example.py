# ------------------------------------------------------------------------------
# example.py - Complete usage example for Agent Router
#
# Run:
#   python agent_router/example.py
#
# This file demonstrates:
#   1. All input parameters (mandatory vs optional)
#   2. Chat history format
#   3. Force tool with arguments
#   4. Tool metadata from ToolRegistry
#   5. Streaming response handling
# ------------------------------------------------------------------------------

import asyncio
import sys
from pathlib import Path

# Support both: `python -m agent_router.example` and `python example.py`
try:
    from . import ChatInput, UserContext, run_chat, ToolRegistry
except ImportError:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from agent_router import ChatInput, UserContext, run_chat, ToolRegistry


# ==============================================================================
# CONFIGURATION
# ==============================================================================

MODEL_CONFIG = {
    # MANDATORY FIELDS
    "api_key": "your-api-key-here",       # [MANDATORY] API key for LLM provider
    "model_name": "gpt-4o",               # [MANDATORY] Model name/identifier

    # OPTIONAL FIELDS
    "base_url": "http://localhost:8113/v1",  # [OPTIONAL] Custom LLM server URL (None = OpenAI)
    "total_token_limit": 120000,             # [OPTIONAL] Context window size (default: 128000)
    "output_token_limit": 4096,              # [OPTIONAL] Max output tokens (default: 4096)
}


# ==============================================================================
# CHAT HISTORY FORMAT
# ==============================================================================
# List of dicts with 'role' ("user" or "assistant") and 'content' (string)

EXAMPLE_CHAT_HISTORY = [
    {"role": "user", "content": "Hello, my name is Vijay"},
    {"role": "assistant", "content": "Hello Vijay! How can I help you today?"},
    {"role": "user", "content": "I'm working on a RAG project"},
    {"role": "assistant", "content": "That's great! What specific aspect would you like help with?"},
]


# ==============================================================================
# USER CONTEXT (OPTIONAL)
# ==============================================================================

EXAMPLE_USER_CONTEXT = UserContext(
    username="Vijay",                    # [OPTIONAL] User's name
    response_style="detailed",           # [OPTIONAL] "detailed" | "concise" | "explain_like_im_5"
    language_preference="English",       # [OPTIONAL] Response language
    custom_instructions="",              # [OPTIONAL] Custom instructions for AI
    designation="Developer",             # [OPTIONAL] User's role/designation
    nickname="VJ",                       # [OPTIONAL] Nickname
)


# ==============================================================================
# AVAILABLE TOOLS & THEIR ARGUMENTS
# ==============================================================================

TOOL_EXAMPLES = {
    # rag_query - Search knowledge base
    "rag_query": {
        "query": "What are the Normans?",  # [MANDATORY] Search query
        "file_ids": None,                   # [OPTIONAL] Restrict to specific files (list of IDs)
        "top_k": 5,                         # [OPTIONAL] Number of results (default: 5)
    },

    # calculator - Math calculations
    "calculator": {
        "expression": "125 * 48 + 320",    # [MANDATORY] Math expression
    },
}


# ==============================================================================
# CHATINPUT PARAMETERS REFERENCE
# ==============================================================================
"""
ChatInput(
    # MANDATORY PARAMETERS
    user_input: str,                    # User's message/query
    chat_history: List[Dict],           # Previous conversation [{"role": "user", "content": "..."}]
    model_config: Dict,                 # LLM config {"api_key": "...", "model_name": "..."}

    # OPTIONAL PARAMETERS
    force_tool: str = None,             # Force a specific tool: "rag_query" or "calculator"
    force_tool_args: Dict = None,       # Arguments for the forced tool
    tool_metadata: Dict = None,         # Tool descriptions (use ToolRegistry.get_metadata())
    user_context: UserContext = None,   # User preferences
    long_input_strategy: str = "auto",  # "auto" | "truncate" | "summarize"
    trace_id: str = auto-generated,     # Request tracing ID
)
"""


# ==============================================================================
# EXAMPLE FUNCTIONS
# ==============================================================================

async def simple_chat(message: str):
    """
    Simplest chat - no tools, no history.
    """
    print("\n" + "=" * 60)
    print("SIMPLE CHAT")
    print("=" * 60)
    print(f"User: {message}\n")
    print("Assistant: ", end="", flush=True)

    chat_input = ChatInput(
        user_input=message,
        chat_history=[],
        model_config=MODEL_CONFIG,
    )

    async for chunk in run_chat(chat_input):
        if "[[CONTEXT_END]]" not in chunk:
            print(chunk, end="", flush=True)
    print("\n")


async def chat_with_history(message: str, history: list):
    """
    Chat with conversation history.
    """
    print("\n" + "=" * 60)
    print("CHAT WITH HISTORY")
    print("=" * 60)
    print(f"History: {len(history)} messages")
    print(f"User: {message}\n")
    print("Assistant: ", end="", flush=True)

    chat_input = ChatInput(
        user_input=message,
        chat_history=history,
        model_config=MODEL_CONFIG,
        user_context=EXAMPLE_USER_CONTEXT,
    )

    async for chunk in run_chat(chat_input):
        if "[[CONTEXT_END]]" not in chunk:
            print(chunk, end="", flush=True)
    print("\n")


async def chat_with_rag(query: str, file_ids: list = None, top_k: int = 5):
    """
    Chat with RAG tool - searches knowledge base.
    """
    print("\n" + "=" * 60)
    print("CHAT WITH RAG TOOL")
    print("=" * 60)
    print(f"Query: {query}")
    print(f"File IDs: {file_ids or 'All'} | Top K: {top_k}\n")
    print("Assistant: ", end="", flush=True)

    chat_input = ChatInput(
        user_input=query,
        chat_history=[],
        model_config=MODEL_CONFIG,
        force_tool="rag_query",
        force_tool_args={
            "query": query,
            "file_ids": file_ids,
            "top_k": top_k,
        },
        tool_metadata=ToolRegistry.get_metadata(),
        user_context=EXAMPLE_USER_CONTEXT,
    )

    context_data = None
    async for chunk in run_chat(chat_input):
        if "[[CONTEXT_END]]" in chunk:
            parts = chunk.split("[[CONTEXT_END]]")
            print(parts[0], end="", flush=True)
            if len(parts) > 1:
                import json
                try:
                    context_data = json.loads(parts[1])
                except:
                    pass
        else:
            print(chunk, end="", flush=True)

    print("\n")
    if context_data:
        print(f"[Context] Tool: {context_data.get('tool_used')} | Query: {context_data.get('query_sent')}")


async def chat_with_calculator(expression: str):
    """
    Chat with calculator tool.
    """
    print("\n" + "=" * 60)
    print("CHAT WITH CALCULATOR")
    print("=" * 60)
    print(f"Expression: {expression}\n")
    print("Assistant: ", end="", flush=True)

    chat_input = ChatInput(
        user_input=f"Calculate: {expression}",
        chat_history=[],
        model_config=MODEL_CONFIG,
        force_tool="calculator",
        force_tool_args={"expression": expression},
        tool_metadata=ToolRegistry.get_metadata(),
    )

    async for chunk in run_chat(chat_input):
        if "[[CONTEXT_END]]" not in chunk:
            print(chunk, end="", flush=True)
    print("\n")


async def full_example():
    """
    Complete example with all parameters.
    """
    print("\n" + "=" * 60)
    print("FULL EXAMPLE (All Parameters)")
    print("=" * 60)

    chat_input = ChatInput(
        # === MANDATORY ===
        user_input="What do the documents say about the Norman conquest?",
        chat_history=EXAMPLE_CHAT_HISTORY,
        model_config=MODEL_CONFIG,

        # === OPTIONAL ===
        force_tool="rag_query",
        force_tool_args={
            "query": "Norman conquest 1066 William",
            "file_ids": None,
            "top_k": 5,
        },
        tool_metadata=ToolRegistry.get_metadata(),
        user_context=UserContext(
            username="Vijay",
            response_style="detailed",
            language_preference="English",
        ),
        long_input_strategy="auto",
    )

    print(f"User: {chat_input.user_input}\n")
    print("Assistant: ", end="", flush=True)

    async for chunk in run_chat(chat_input):
        if "[[CONTEXT_END]]" not in chunk:
            print(chunk, end="", flush=True)
    print("\n")


# ==============================================================================
# FASTAPI INTEGRATION EXAMPLE
# ==============================================================================

FASTAPI_EXAMPLE = '''
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Optional
import asyncio

from agent_router import ChatInput, UserContext, run_chat, ToolRegistry

app = FastAPI()


class ChatRequest(BaseModel):
    message: str
    history: List[Dict[str, str]] = []
    username: str = "User"
    force_tool: Optional[str] = None           # "rag_query" or "calculator"
    force_tool_args: Optional[Dict] = None


@app.post("/chat")
async def chat_endpoint(request: Request, data: ChatRequest):
    chat_input = ChatInput(
        user_input=data.message,
        chat_history=data.history,
        model_config={
            "api_key": "your-api-key",
            "model_name": "gpt-4o",
            "base_url": None,
        },
        force_tool=data.force_tool,
        force_tool_args=data.force_tool_args,
        tool_metadata=ToolRegistry.get_metadata(),
        user_context=UserContext(username=data.username),
    )

    async def stream_with_disconnect():
        try:
            async for chunk in run_chat(chat_input):
                if await request.is_disconnected():
                    break
                yield chunk
        except (asyncio.CancelledError, GeneratorExit):
            pass

    return StreamingResponse(stream_with_disconnect(), media_type="text/event-stream")
'''


# ==============================================================================
# MAIN
# ==============================================================================

async def main():
    print("\n" + "=" * 70)
    print("AGENT ROUTER - USAGE EXAMPLES")
    print("=" * 70)

    # Show available tools
    print("\n[AVAILABLE TOOLS]")
    print("-" * 40)
    for tool, desc in ToolRegistry.get_metadata().items():
        print(f"  {tool}: {desc[:60]}...")
    print("-" * 40)

    # Show tool arguments
    print("\n[TOOL ARGUMENTS]")
    print("-" * 40)
    for tool in ToolRegistry.list_tools():
        args = ToolRegistry.get_tool_args(tool)
        print(f"  {tool}:")
        for arg, spec in args.items():
            req = "required" if spec.get("required") else "optional"
            print(f"    - {arg} ({spec['type']}, {req})")
    print("-" * 40)

    # Example calls
    print("\n[EXAMPLE CALLS]")
    print("-" * 40)
    print("  await simple_chat('What is Python?')")
    print("  await chat_with_history('What was I working on?', EXAMPLE_CHAT_HISTORY)")
    print("  await chat_with_rag('Who were the Normans?', top_k=3)")
    print("  await chat_with_calculator('125 * 48 + 320')")
    print("  await full_example()")
    print("-" * 40)

    # Uncomment to run:
    # await simple_chat("What is Python?")
    # await chat_with_rag("Who were the Normans?")
    # await chat_with_calculator("125 * 48 + 320")

    print("\n[FASTAPI INTEGRATION]")
    print(FASTAPI_EXAMPLE)


if __name__ == "__main__":
    asyncio.run(main())

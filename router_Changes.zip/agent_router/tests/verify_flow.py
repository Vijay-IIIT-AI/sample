# ------------------------------------------------------------------------------
# verify_flow.py — Quick verification of the test flows
#
# Tests:
#   1. Generic LLM call (no tool)
#   2. Force tool flow (rag_query called, output used in response)
#   3. Tool executor directly
#
# Run:
#   python -m agent_router.tests.verify_flow
# ------------------------------------------------------------------------------

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

# Path fix
_THIS = Path(__file__).parent          # agent_router/tests
_PARENT = _THIS.parent                  # agent_router
_ROOT = _PARENT.parent                  # AgenticCode
for p in [str(_ROOT), str(_PARENT), str(_THIS)]:
    if p not in sys.path:
        sys.path.insert(0, p)

from agent_router import ChatInput, UserContext, run_chat, ToolExecutor
from agent_router.tools import ToolRegistry as DummyTools
from agent_router.rag_store import retrieve, get_all_file_ids, embed_and_store, METADATA_PATH, CHROMA_PATH

# ══════════════════════════════════════════════════════════════════════════════
# CONFIG - Update this to match your local model
# ══════════════════════════════════════════════════════════════════════════════

MODEL_CONFIG = {
    "api_key": "Key",
    "model_name": "models/",  # Your OSS 120b model
    "base_url": "http://localhost:8113/v1",
    "total_token_limit": 120000,  # 120K context
    "output_token_limit": 4096,
}

W = 70

def sep(label: str = "") -> None:
    if label:
        pad = (W - len(label) - 2) // 2
        print(f"\n{'=' * pad} {label} {'=' * pad}")
    else:
        print("=" * W)


# ══════════════════════════════════════════════════════════════════════════════
# STEP 0: Ensure we have some data in ChromaDB
# ══════════════════════════════════════════════════════════════════════════════

def setup_test_data():
    """Ingest minimal test data if ChromaDB is empty."""
    sep("STEP 0: Setup Test Data")

    # Check if we already have data
    existing_ids = get_all_file_ids()
    if existing_ids:
        print(f"  [OK] ChromaDB has {len(existing_ids)} files already")
        print(f"       File IDs: {existing_ids[:5]}{'...' if len(existing_ids) > 5 else ''}")
        return True

    print("  [INFO] ChromaDB is empty. Ingesting sample data...")

    # Sample documents for testing
    sample_docs = [
        {
            "file_id": "test_normans",
            "file_name": "Normans History",
            "text": """
            The Normans were people who gave their name to Normandy, a region in France.
            They were descended from Vikings who settled in the region in the 10th century.
            The Normans spoke Old Norman, a Romance language. In 1066, William the Conqueror
            led the Norman conquest of England, defeating King Harold II at the Battle of Hastings.
            This event transformed English language, culture, and governance. The Normans
            introduced feudal administration and French vocabulary into English.
            Norman architecture is characterized by rounded arches and massive proportions.
            """
        },
        {
            "file_id": "test_python",
            "file_name": "Python Programming",
            "text": """
            Python is a high-level, interpreted programming language created by Guido van Rossum.
            It was first released in 1991 and emphasizes code readability with significant whitespace.
            Python supports multiple programming paradigms including procedural, object-oriented,
            and functional programming. It has a comprehensive standard library and a large
            ecosystem of third-party packages available through PyPI. Python is widely used
            in web development, data science, machine learning, automation, and scripting.
            """
        },
    ]

    for doc in sample_docs:
        info = embed_and_store(
            file_id=doc["file_id"],
            file_name=doc["file_name"],
            text=doc["text"],
            chunk_size=100,
            overlap=20
        )
        print(f"  [OK] Ingested: {doc['file_name']} -> {info['num_chunks']} chunks")

    print(f"\n  [OK] Metadata saved to: {METADATA_PATH}")
    print(f"  [OK] ChromaDB stored at: {CHROMA_PATH}")
    return True


# ══════════════════════════════════════════════════════════════════════════════
# TEST 1: Direct Tool Execution (rag_query)
# ══════════════════════════════════════════════════════════════════════════════

def test_direct_tool():
    sep("TEST 1: Direct Tool Execution")
    print("  Testing DummyTools.rag_query() directly...\n")

    test_cases = [
        {"query": "Who were the Normans?", "top_k": 2},
        {"query": "What is Python programming?", "top_k": 2},
        {"query": "Nonexistent topic XYZ123", "top_k": 2},  # Should return no results
    ]

    for i, args in enumerate(test_cases, 1):
        print(f"  [{i}] Query: {args['query']}")
        result = DummyTools.rag_query(args)

        # Check if we got chunks back
        has_chunks = "[" in result and "score" in result
        has_no_results = "No relevant" in result

        if has_chunks:
            print(f"      -> PASS: Got chunks with scores")
            # Show first 150 chars of result
            print(f"      -> Preview: {result[:150]}...")
        elif has_no_results:
            print(f"      -> PASS: Correctly returned 'no results' for missing topic")
        else:
            print(f"      -> WARN: Unexpected result: {result[:100]}")
        print()

    return True


# ══════════════════════════════════════════════════════════════════════════════
# TEST 2: ToolExecutor with rag_query
# ══════════════════════════════════════════════════════════════════════════════

def test_tool_executor():
    sep("TEST 2: ToolExecutor.execute()")
    print("  Testing tool routing through ToolExecutor...\n")

    args = {"query": "Norman conquest 1066", "top_k": 3}
    print(f"  Tool: rag_query")
    print(f"  Args: {args}")

    result = ToolExecutor.execute(
        tool_name="rag_query",
        args=args,
        user_input="Tell me about the Norman conquest",
        llm=None,  # No LLM for decomposition
        token_budget=10000
    )

    has_chunks = "[" in result or "---" in result
    print(f"\n  Result length: {len(result)} chars")
    print(f"  Has chunks: {has_chunks}")
    print(f"  Preview:\n{result[:300]}...")

    return has_chunks


# ══════════════════════════════════════════════════════════════════════════════
# TEST 3: Full run_chat with force_tool
# ══════════════════════════════════════════════════════════════════════════════

async def test_force_tool_flow():
    sep("TEST 3: Full run_chat with force_tool")
    print("  Testing complete pipeline: user query -> force_tool -> RAG -> LLM response\n")

    chat_input = ChatInput(
        user_input="What do the documents say about the Normans?",
        chat_history=[],
        model_config=MODEL_CONFIG,
        force_tool="rag_query",
        force_tool_args={"query": "Normans history conquest", "top_k": 3},
        tool_metadata={"rag_query": "Search the knowledge base for relevant documents."},
        user_context=UserContext(username="TestUser", response_style="concise"),
    )

    print(f"  User Input: {chat_input.user_input}")
    print(f"  Force Tool: {chat_input.force_tool}")
    print(f"  Tool Args:  {chat_input.force_tool_args}")
    print("\n  Calling run_chat()...\n")

    response_chunks = []
    try:
        async for chunk in run_chat(chat_input):
            response_chunks.append(chunk)
            # Print streaming indicator
            if len(response_chunks) % 10 == 0:
                print(".", end="", flush=True)

        full_response = "".join(response_chunks)
        print(f"\n\n  Response length: {len(full_response)} chars")

        # Check for context metadata
        has_context_meta = "[[CONTEXT_END]]" in full_response
        print(f"  Has context metadata: {has_context_meta}")

        # Extract just the LLM response (before context metadata)
        if "[[CONTEXT_END]]" in full_response:
            llm_response = full_response.split("[[CONTEXT_END]]")[0]
        else:
            llm_response = full_response

        print(f"\n  LLM Response Preview:\n  {'-'*60}")
        print(f"  {llm_response[:500]}...")
        print(f"  {'-'*60}")

        return len(llm_response) > 50

    except Exception as e:
        print(f"\n  [ERROR] {type(e).__name__}: {e}")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# TEST 4: Generic LLM call (no tool)
# ══════════════════════════════════════════════════════════════════════════════

async def test_generic_llm():
    sep("TEST 4: Generic LLM Call (no tool)")
    print("  Testing LLM response without any tool forcing...\n")

    chat_input = ChatInput(
        user_input="What is 2 + 2?",
        chat_history=[],
        model_config=MODEL_CONFIG,
        force_tool=None,  # No tool
        user_context=UserContext(username="TestUser"),
    )

    print(f"  User Input: {chat_input.user_input}")
    print(f"  Force Tool: None")
    print("\n  Calling run_chat()...\n")

    response_chunks = []
    try:
        async for chunk in run_chat(chat_input):
            response_chunks.append(chunk)

        full_response = "".join(response_chunks)
        print(f"  Response: {full_response[:300]}")

        # Basic check - should mention "4" somewhere
        has_answer = "4" in full_response
        print(f"\n  Contains correct answer: {has_answer}")

        return has_answer

    except Exception as e:
        print(f"\n  [ERROR] {type(e).__name__}: {e}")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# TEST 5: Verify metadata mapping
# ══════════════════════════════════════════════════════════════════════════════

def test_metadata_mapping():
    sep("TEST 5: Metadata Mapping (file_id -> file_name -> chunk_ids)")

    import json

    if not METADATA_PATH.exists():
        print("  [SKIP] No metadata file found")
        return False

    with open(METADATA_PATH, "r", encoding="utf-8") as f:
        metadata = json.load(f)

    print(f"  Metadata file: {METADATA_PATH}")
    print(f"  Total files: {len(metadata.get('files', {}))}")
    print("\n  File ID -> File Name -> Chunk Count:")
    print(f"  {'-'*60}")

    for file_id, info in metadata.get("files", {}).items():
        file_name = info.get("file_name", "?")
        num_chunks = info.get("num_chunks", len(info.get("chunk_ids", [])))
        chunk_ids = info.get("chunk_ids", [])[:3]  # First 3 chunk IDs

        print(f"  {file_id}")
        print(f"    -> file_name: {file_name}")
        print(f"    -> num_chunks: {num_chunks}")
        print(f"    -> chunk_ids (first 3): {chunk_ids}")
        print()

    return True


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

async def main():
    sep("CODE_V3 FLOW VERIFICATION")
    print(f"  Model: {MODEL_CONFIG['model_name']}")
    print(f"  Base URL: {MODEL_CONFIG['base_url']}")
    print(f"  Context: {MODEL_CONFIG['total_token_limit']} tokens")

    results = {}

    # Step 0: Setup data
    results["setup"] = setup_test_data()

    # Test 1: Direct tool
    results["direct_tool"] = test_direct_tool()

    # Test 2: ToolExecutor
    results["tool_executor"] = test_tool_executor()

    # Test 3: Force tool flow
    results["force_tool"] = await test_force_tool_flow()

    # Test 4: Generic LLM
    results["generic_llm"] = await test_generic_llm()

    # Test 5: Metadata
    results["metadata"] = test_metadata_mapping()

    # Summary
    sep("VERIFICATION SUMMARY")
    for name, passed in results.items():
        status = "PASS" if passed else "FAIL"
        icon = "[OK]" if passed else "[X]"
        print(f"  {icon} {name:20s} : {status}")

    total_pass = sum(1 for v in results.values() if v)
    total = len(results)
    print(f"\n  Total: {total_pass}/{total} tests passed")

    if total_pass == total:
        print("\n  All flows working correctly!")
    else:
        print("\n  Some tests failed - check output above for details.")


if __name__ == "__main__":
    asyncio.run(main())
